import { pgTable, text, serial, integer, boolean, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const smtpsTable = pgTable("smtps", {
  id: serial("id").primaryKey(),
  label: text("label"),
  host: text("host").notNull(),
  port: integer("port").notNull(),
  user: text("user").notNull(),
  pass: text("pass").notNull(),
  secure: boolean("secure").default(true),
  status: text("status").default("untested"),
  lastTestedAt: timestamp("last_tested_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const awsConfigsTable = pgTable("aws_configs", {
  id: serial("id").primaryKey(),
  label: text("label"),
  region: text("region").notNull(),
  accessKeyId: text("access_key_id").notNull(),
  secretAccessKey: text("secret_access_key").notNull(),
  fromEmail: text("from_email"),
  fromName: text("from_name"),
  status: text("status").default("untested"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const sendgridConfigsTable = pgTable("sendgrid_configs", {
  id: serial("id").primaryKey(),
  label: text("label"),
  apiKey: text("api_key").notNull(),
  fromEmail: text("from_email"),
  fromName: text("from_name"),
  status: text("status").default("untested"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const resendConfigsTable = pgTable("resend_configs", {
  id: serial("id").primaryKey(),
  label: text("label"),
  domain: text("domain").notNull(),
  fromEmail: text("from_email").notNull(),
  fromName: text("from_name"),
  apiKeyEncrypted: text("api_key_encrypted"),
  status: text("status").default("untested"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const smsConfigsTable = pgTable("sms_configs", {
  id: serial("id").primaryKey(),
  label: text("label"),
  provider: text("provider").notNull(),
  apiKey: text("api_key"),
  accountSid: text("account_sid"),
  authToken: text("auth_token"),
  fromNumber: text("from_number"),
  awsConfigId: integer("aws_config_id"),
  smtpId: integer("smtp_id"),
  gatewayDomain: text("gateway_domain"),
  status: text("status").default("untested"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const leadFoldersTable = pgTable("lead_folders", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull().default("email"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const leadsTable = pgTable("leads", {
  id: serial("id").primaryKey(),
  folderId: integer("folder_id"),
  value: text("value").notNull(),
  type: text("type").notNull(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  extra: text("extra"),
  status: text("status").notNull().default("active"),
  bouncedAt: timestamp("bounced_at"),
  unsubscribedAt: timestamp("unsubscribed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const campaignsTable = pgTable("campaigns", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull().default("email"),
  status: text("status").notNull().default("draft"),
  subject: text("subject"),
  body: text("body"),
  isHtml: boolean("is_html").default(false),
  fromName: text("from_name"),
  fromEmail: text("from_email"),
  senderType: text("sender_type"),
  smtpId: integer("smtp_id"),
  awsConfigId: integer("aws_config_id"),
  sendgridConfigId: integer("sendgrid_config_id"),
  resendConfigId: integer("resend_config_id"),
  smsConfigId: integer("sms_config_id"),
  rotateSmtps: boolean("rotate_smtps").default(false),
  useProxy: boolean("use_proxy").default(false),
  attachments: text("attachments"),
  leadType: text("lead_type").default("email"),
  leadFolderId: integer("lead_folder_id"),
  sendRatePerMinute: integer("send_rate_per_minute").default(0),
  totalSent: integer("total_sent").default(0),
  totalFailed: integer("total_failed").default(0),
  totalLeads: integer("total_leads").default(0),
  scheduledAt: timestamp("scheduled_at"),
  startedAt: timestamp("started_at"),
  finishedAt: timestamp("finished_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const deliveriesTable = pgTable("deliveries", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id"),
  campaignName: text("campaign_name"),
  recipient: text("recipient").notNull(),
  status: text("status").notNull().default("pending"),
  channel: text("channel").notNull().default("email"),
  subject: text("subject"),
  messageId: text("message_id"),
  error: text("error"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const proxiesTable = pgTable("proxies", {
  id: serial("id").primaryKey(),
  host: text("host").notNull(),
  port: integer("port").notNull(),
  username: text("username"),
  password: text("password"),
  protocol: text("protocol").default("http"),
  status: text("status").default("untested"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const warmupPlansTable = pgTable("warmup_plans", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  smtpId: integer("smtp_id"),
  awsConfigId: integer("aws_config_id"),
  sendgridConfigId: integer("sendgrid_config_id"),
  startDate: timestamp("start_date").notNull().defaultNow(),
  durationDays: integer("duration_days").notNull().default(30),
  startVolume: integer("start_volume").notNull().default(50),
  endVolume: integer("end_volume").notNull().default(5000),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const warmupDailyLogsTable = pgTable("warmup_daily_logs", {
  id: serial("id").primaryKey(),
  warmupPlanId: integer("warmup_plan_id").notNull(),
  date: text("date").notNull(),
  sentCount: integer("sent_count").notNull().default(0),
});

export const insertSmtpSchema = createInsertSchema(smtpsTable).omit({ id: true, createdAt: true, status: true, lastTestedAt: true });
export const insertAwsConfigSchema = createInsertSchema(awsConfigsTable).omit({ id: true, createdAt: true, status: true });
export const insertSendgridConfigSchema = createInsertSchema(sendgridConfigsTable).omit({ id: true, createdAt: true, status: true });
export const insertResendConfigSchema = createInsertSchema(resendConfigsTable).omit({ id: true, createdAt: true, status: true });
export const insertSmsConfigSchema = createInsertSchema(smsConfigsTable).omit({ id: true, createdAt: true, status: true });
export const insertLeadFolderSchema = createInsertSchema(leadFoldersTable).omit({ id: true, createdAt: true });
export const insertLeadSchema = createInsertSchema(leadsTable).omit({ id: true, createdAt: true });
export const insertCampaignSchema = createInsertSchema(campaignsTable).omit({ id: true, createdAt: true, updatedAt: true, status: true, totalSent: true, totalFailed: true, totalLeads: true });
export const insertDeliverySchema = createInsertSchema(deliveriesTable).omit({ id: true, createdAt: true });
export const insertProxySchema = createInsertSchema(proxiesTable).omit({ id: true, createdAt: true, status: true });

export type Smtp = typeof smtpsTable.$inferSelect;
export type AwsConfig = typeof awsConfigsTable.$inferSelect;
export type SendgridConfig = typeof sendgridConfigsTable.$inferSelect;
export type ResendConfig = typeof resendConfigsTable.$inferSelect;
export type SmsConfig = typeof smsConfigsTable.$inferSelect;
export type LeadFolder = typeof leadFoldersTable.$inferSelect;
export type Lead = typeof leadsTable.$inferSelect;
export type Campaign = typeof campaignsTable.$inferSelect;
export type Delivery = typeof deliveriesTable.$inferSelect;
export type Proxy = typeof proxiesTable.$inferSelect;
export type WarmupPlan = typeof warmupPlansTable.$inferSelect;
export type WarmupDailyLog = typeof warmupDailyLogsTable.$inferSelect;
export const insertWarmupPlanSchema = createInsertSchema(warmupPlansTable).omit({ id: true, createdAt: true, status: true });
