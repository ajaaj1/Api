import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AppLayout } from "@/components/layout";
import NotFound from "@/pages/not-found";

import Dashboard from "@/pages/dashboard";
import SmtpManager from "@/pages/smtp";
import AwsManager from "@/pages/aws";
import SendgridManager from "@/pages/sendgrid";
import ResendManager from "@/pages/resend";
import DirectEmail from "@/pages/direct-email";
import SmsManager from "@/pages/sms";
import LeadsManager from "@/pages/leads";
import Campaigns from "@/pages/campaigns";
import SmsCampaigns from "@/pages/sms-campaigns";
import HtmlEditor from "@/pages/html-editor";
import Deliveries from "@/pages/deliveries";
import ProxiesManager from "@/pages/proxies";
import WarmupManager from "@/pages/warmup";

const queryClient = new QueryClient();
function EmailCampaigns() {
  return <Campaigns mode="email" />;
}

function Router() {
  return (
    <AppLayout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/smtp" component={SmtpManager} />
        <Route path="/aws" component={AwsManager} />
        <Route path="/sendgrid" component={SendgridManager} />
        <Route path="/resend" component={ResendManager} />
        <Route path="/direct-email" component={DirectEmail} />
        <Route path="/sms" component={SmsManager} />
        <Route path="/leads" component={LeadsManager} />
        <Route path="/campaigns" component={EmailCampaigns} />
        <Route path="/sms-campaigns" component={SmsCampaigns} />
        <Route path="/html-editor" component={HtmlEditor} />
        <Route path="/deliveries" component={Deliveries} />
        <Route path="/proxies" component={ProxiesManager} />
        <Route path="/warmup" component={WarmupManager} />
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
