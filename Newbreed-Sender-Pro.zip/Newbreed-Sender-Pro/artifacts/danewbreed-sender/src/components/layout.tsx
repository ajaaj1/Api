import { Link, useLocation } from "wouter";
import { Mail, Server, Cloud, Smartphone, Users, Megaphone, FileCode2, BarChart2, Globe, Flame, Send, AtSign } from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/", label: "Dashboard", icon: BarChart2 },
  { href: "/campaigns", label: "Email Campaigns", icon: Megaphone },
  { href: "/sms-campaigns", label: "SMS Campaigns", icon: Send },
  { href: "/leads", label: "Leads", icon: Users },
  { href: "/deliveries", label: "Deliveries", icon: BarChart2 },
  { href: "/html-editor", label: "HTML Editor", icon: FileCode2 },
  { href: "/smtp", label: "SMTPs", icon: Server },
  { href: "/aws", label: "AWS SES", icon: Cloud },
  { href: "/sendgrid", label: "SendGrid", icon: Mail },
  { href: "/resend", label: "Resend API", icon: AtSign },
  { href: "/direct-email", label: "Direct Email", icon: Mail },
  { href: "/sms", label: "SMS", icon: Smartphone },
  { href: "/proxies", label: "Proxies", icon: Globe },
  { href: "/warmup", label: "Warm-up", icon: Flame },
];

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <div className="flex min-h-screen w-full bg-background text-foreground dark">
      <div className="w-64 border-r border-border bg-card flex flex-col hidden md:flex">
        <div className="h-16 flex items-center px-6 border-b border-border">
          <span className="font-bold text-lg text-primary tracking-tight">Danewbreed Sender Pro</span>
        </div>
        <div className="flex-1 overflow-y-auto py-4">
          <nav className="space-y-1 px-3">
            {navItems.map((item) => {
              const isActive = location === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors",
                    isActive
                      ? "bg-primary/10 text-primary"
                      : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                  )}
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </div>
      </div>
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="h-16 border-b border-border flex items-center px-6 bg-background shrink-0">
          <h1 className="text-lg font-medium">
            {navItems.find((i) => i.href === location)?.label || "Dashboard"}
          </h1>
        </header>
        <main className="flex-1 overflow-y-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
