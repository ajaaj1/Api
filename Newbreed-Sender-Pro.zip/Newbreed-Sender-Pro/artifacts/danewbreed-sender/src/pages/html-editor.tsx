import { useState, useRef } from "react";
import { useDebugHtml } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const DEFAULT_HTML = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Email</title>
</head>
<body style="margin:0;padding:0;background:#f4f4f4;font-family:Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0">
    <tr>
      <td align="center" style="padding:20px;">
        <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:8px;">
          <tr>
            <td style="padding:40px;text-align:center;">
              <h1 style="color:#333333;font-size:28px;margin:0 0 20px;">Welcome!</h1>
              <p style="color:#666666;font-size:16px;line-height:1.6;">This is your email content.</p>
              <a href="https://example.com" style="display:inline-block;background:#4f7ef7;color:#ffffff;text-decoration:none;padding:12px 24px;border-radius:6px;margin-top:20px;">Click Here</a>
            </td>
          </tr>
          <tr>
            <td style="padding:20px;text-align:center;color:#999999;font-size:12px;border-top:1px solid #eeeeee;">
              <a href="#" style="color:#999999;">Unsubscribe</a>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;

type Finding = {
  severity: "error" | "warning" | "info";
  category: string;
  message: string;
  detail?: string;
};

type DeliverabilityResult = {
  score: number;
  grade: string;
  findings: Finding[];
  stats: Record<string, string | number>;
};

function ScoreGauge({ score, grade }: { score: number; grade: string }) {
  const color =
    score >= 90 ? "#22c55e" :
    score >= 80 ? "#84cc16" :
    score >= 65 ? "#eab308" :
    score >= 50 ? "#f97316" : "#ef4444";

  const gradeColor =
    grade === "A" ? "text-green-400" :
    grade === "B" ? "text-lime-400" :
    grade === "C" ? "text-yellow-400" :
    grade === "D" ? "text-orange-400" : "text-red-400";

  const circumference = 2 * Math.PI * 36;
  const offset = circumference - (score / 100) * circumference;

  return (
    <div className="flex items-center gap-4">
      <div className="relative w-20 h-20 shrink-0">
        <svg className="w-20 h-20 -rotate-90" viewBox="0 0 80 80">
          <circle cx="40" cy="40" r="36" fill="none" stroke="#1e293b" strokeWidth="7" />
          <circle
            cx="40" cy="40" r="36" fill="none"
            stroke={color} strokeWidth="7"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            style={{ transition: "stroke-dashoffset 0.6s ease" }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-xl font-bold text-foreground leading-none">{score}</span>
          <span className="text-[10px] text-muted-foreground">/ 100</span>
        </div>
      </div>
      <div>
        <div className={`text-4xl font-black ${gradeColor}`}>{grade}</div>
        <div className="text-xs text-muted-foreground mt-0.5">
          {score >= 90 ? "Excellent" : score >= 80 ? "Good" : score >= 65 ? "Needs work" : score >= 50 ? "Poor" : "Critical issues"}
        </div>
      </div>
    </div>
  );
}

const SEVERITY_STYLES = {
  error: { pill: "bg-red-500/15 text-red-400 border-red-500/20", icon: "✗", border: "border-red-500/20", bg: "bg-red-500/5" },
  warning: { pill: "bg-yellow-500/15 text-yellow-400 border-yellow-500/20", icon: "⚠", border: "border-yellow-500/20", bg: "bg-yellow-500/5" },
  info: { pill: "bg-blue-500/15 text-blue-400 border-blue-500/20", icon: "ℹ", border: "border-blue-500/20", bg: "bg-blue-500/5" },
};

export default function HtmlEditor() {
  const { toast } = useToast();
  const [html, setHtml] = useState(DEFAULT_HTML);
  const [viewMode, setViewMode] = useState<"split" | "editor" | "preview">("split");
  const [issues, setIssues] = useState<string[]>([]);
  const [warnings, setWarnings] = useState<string[]>([]);
  const [debugged, setDebugged] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const debugHtml = useDebugHtml();

  // Deliverability checker state
  const [showSpamPanel, setShowSpamPanel] = useState(false);
  const [spamSubject, setSpamSubject] = useState("");
  const [spamFrom, setSpamFrom] = useState("");
  const [spamResult, setSpamResult] = useState<DeliverabilityResult | null>(null);
  const [spamChecking, setSpamChecking] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  function handleDebug() {
    debugHtml.mutate({ data: { html } }, {
      onSuccess: (res) => {
        setIssues(res.issues);
        setWarnings(res.warnings ?? []);
        if (res.fixed && res.fixed !== html) {
          setHtml(res.fixed);
          toast({ title: "HTML fixed", description: `${res.issues.length} issues fixed` });
        } else {
          toast({ title: res.issues.length === 0 ? "No issues found" : `${res.issues.length} issues detected`, description: res.warnings?.length ? `${res.warnings.length} warnings` : undefined });
        }
        setDebugged(true);
      },
      onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
    });
  }

  async function handleSpamCheck() {
    setSpamChecking(true);
    setSpamResult(null);
    try {
      const res = await fetch("/api/deliverability/check", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ html, subject: spamSubject, fromEmail: spamFrom }),
      });
      if (!res.ok) throw new Error(await res.text());
      const data: DeliverabilityResult = await res.json();
      setSpamResult(data);
      setActiveCategory(null);
    } catch (e: any) {
      toast({ title: "Check failed", description: e.message, variant: "destructive" });
    } finally {
      setSpamChecking(false);
    }
  }

  function handleFileRead(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const input = e.currentTarget;
    const reader = new FileReader();
    reader.onload = (ev) => {
      input.value = "";
      const imported = ev.target?.result;
      if (typeof imported !== "string" || !imported.trim()) {
        toast({ title: "The selected HTML file is empty or unreadable", description: file.name, variant: "destructive" });
        return;
      }
      setHtml(imported);
      setIssues([]);
      setWarnings([]);
      setDebugged(false);
      toast({ title: `Loaded ${file.name}` });
    };
    reader.onerror = () => {
      input.value = "";
      toast({ title: "Could not read this HTML file", description: file.name, variant: "destructive" });
    };
    reader.readAsText(file);
  }

  function handleDownload() {
    if (!html.trim()) {
      toast({ title: "There is no HTML to export", variant: "destructive" });
      return;
    }
    const blob = new Blob([html], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const title = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]?.trim() || "email";
    const safeFilename = title.replace(/[<>:"/\\|?*\u0000-\u001F]/g, "-").slice(0, 80) || "email";
    a.href = url;
    a.download = `${safeFilename}.html`;
    a.style.display = "none";
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast({ title: `Exported ${safeFilename}.html` });
  }

  function handleCopy() {
    navigator.clipboard.writeText(html);
    toast({ title: "Copied to clipboard" });
  }

  // Group findings by category
  const groupedFindings = spamResult
    ? spamResult.findings.reduce<Record<string, Finding[]>>((acc, f) => {
        (acc[f.category] ??= []).push(f);
        return acc;
      }, {})
    : {};

  const categories = Object.keys(groupedFindings);
  const filteredFindings = activeCategory
    ? groupedFindings[activeCategory] ?? []
    : spamResult?.findings ?? [];

  const errorCount = spamResult?.findings.filter(f => f.severity === "error").length ?? 0;
  const warnCount = spamResult?.findings.filter(f => f.severity === "warning").length ?? 0;

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] space-y-3">
      {/* ── Header ── */}
      <div className="flex items-center justify-between shrink-0">
        <div>
          <h2 className="text-xl font-semibold">HTML Email Editor</h2>
          <p className="text-sm text-muted-foreground mt-0.5">Write, preview, and debug your HTML emails</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex bg-muted rounded-md p-0.5">
            {(["split", "editor", "preview"] as const).map(m => (
              <button key={m} onClick={() => setViewMode(m)} className={`text-xs px-3 py-1.5 rounded font-medium capitalize transition-colors ${viewMode === m ? "bg-background text-foreground shadow-sm" : "text-muted-foreground"}`}>{m}</button>
            ))}
          </div>
          <Button size="sm" variant="outline" onClick={() => fileRef.current?.click()} className="text-xs">Import</Button>
          <input ref={fileRef} type="file" accept=".html,.htm" className="hidden" onChange={handleFileRead} />
          <Button size="sm" variant="outline" onClick={handleCopy} className="text-xs">Copy</Button>
          <Button size="sm" variant="outline" onClick={handleDownload} className="text-xs">Export</Button>
          <Button
            size="sm"
            variant={showSpamPanel ? "default" : "outline"}
            onClick={() => setShowSpamPanel(s => !s)}
            className="text-xs gap-1.5"
          >
            🛡 Spam Check
            {spamResult && (
              <span className={`ml-1 font-bold ${spamResult.score >= 80 ? "text-green-400" : spamResult.score >= 60 ? "text-yellow-400" : "text-red-400"}`}>
                {spamResult.score}/100
              </span>
            )}
          </Button>
          <Button size="sm" onClick={handleDebug} disabled={debugHtml.isPending} className="text-xs">
            {debugHtml.isPending ? "Analyzing..." : "Debug & Fix HTML"}
          </Button>
        </div>
      </div>

      {/* ── HTML debug results ── */}
      {debugged && (issues.length > 0 || warnings.length > 0) && (
        <div className="shrink-0 space-y-2">
          {issues.length > 0 && (
            <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3">
              <p className="text-xs font-medium text-red-400 mb-1">{issues.length} issue(s) found and fixed:</p>
              <ul className="space-y-0.5">{issues.map((i, idx) => <li key={idx} className="text-xs text-red-300">• {i}</li>)}</ul>
            </div>
          )}
          {warnings.length > 0 && (
            <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-3">
              <p className="text-xs font-medium text-yellow-400 mb-1">{warnings.length} warning(s):</p>
              <ul className="space-y-0.5">{warnings.map((w, idx) => <li key={idx} className="text-xs text-yellow-300">• {w}</li>)}</ul>
            </div>
          )}
          {issues.length === 0 && warnings.length === 0 && (
            <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-2 text-xs text-green-400">No issues found - HTML looks good for email delivery.</div>
          )}
        </div>
      )}

      {/* ── Spam Check Panel ── */}
      {showSpamPanel && (
        <div className="shrink-0 border border-border rounded-xl bg-card overflow-hidden">
          {/* Input row */}
          <div className="flex items-end gap-3 p-3 border-b border-border bg-muted/20">
            <div className="flex-1">
              <Label className="text-xs mb-1 block text-muted-foreground">Subject line</Label>
              <Input
                className="h-8 text-xs"
                placeholder="Enter your email subject..."
                value={spamSubject}
                onChange={e => setSpamSubject(e.target.value)}
              />
            </div>
            <div className="w-56">
              <Label className="text-xs mb-1 block text-muted-foreground">From email</Label>
              <Input
                className="h-8 text-xs"
                placeholder="sender@yourdomain.com"
                value={spamFrom}
                onChange={e => setSpamFrom(e.target.value)}
              />
            </div>
            <Button size="sm" onClick={handleSpamCheck} disabled={spamChecking} className="text-xs h-8 px-4 shrink-0">
              {spamChecking ? "Scanning..." : "Run Check"}
            </Button>
          </div>

          {/* Results */}
          {spamResult ? (
            <div className="flex gap-0 divide-x divide-border">
              {/* Score + stats sidebar */}
              <div className="w-52 shrink-0 p-4 space-y-4">
                <ScoreGauge score={spamResult.score} grade={spamResult.grade} />
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">Errors</span>
                    <span className={errorCount > 0 ? "text-red-400 font-semibold" : "text-green-400"}>{errorCount}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">Warnings</span>
                    <span className={warnCount > 0 ? "text-yellow-400 font-semibold" : "text-green-400"}>{warnCount}</span>
                  </div>
                  <div className="border-t border-border pt-1.5 mt-1.5 space-y-1">
                    {Object.entries(spamResult.stats).filter(([k]) => !["errors","warnings"].includes(k)).map(([k, v]) => (
                      <div key={k} className="flex items-center justify-between text-xs">
                        <span className="text-muted-foreground capitalize">{k.replace(/([A-Z])/g, " $1").trim()}</span>
                        <span className="text-foreground font-mono">{v}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Findings panel */}
              <div className="flex-1 flex flex-col min-h-0">
                {/* Category filter pills */}
                <div className="flex flex-wrap gap-1.5 p-3 border-b border-border">
                  <button
                    onClick={() => setActiveCategory(null)}
                    className={`text-xs px-2.5 py-1 rounded-full border font-medium transition-colors ${!activeCategory ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:text-foreground"}`}
                  >
                    All ({spamResult.findings.length})
                  </button>
                  {categories.map(cat => {
                    const catFindings = groupedFindings[cat];
                    const hasError = catFindings.some(f => f.severity === "error");
                    const hasWarn = catFindings.some(f => f.severity === "warning");
                    const pillColor = hasError ? "border-red-500/40 text-red-400" : hasWarn ? "border-yellow-500/40 text-yellow-400" : "border-blue-500/40 text-blue-400";
                    return (
                      <button
                        key={cat}
                        onClick={() => setActiveCategory(c => c === cat ? null : cat)}
                        className={`text-xs px-2.5 py-1 rounded-full border font-medium transition-colors ${activeCategory === cat ? "bg-primary text-primary-foreground border-primary" : `${pillColor} hover:bg-muted`}`}
                      >
                        {cat} ({catFindings.length})
                      </button>
                    );
                  })}
                </div>

                {/* Finding rows */}
                <div className="overflow-y-auto max-h-52 p-3 space-y-2">
                  {filteredFindings.map((f, i) => {
                    const s = SEVERITY_STYLES[f.severity];
                    return (
                      <div key={i} className={`flex gap-3 text-xs p-2.5 rounded-lg border ${s.bg} ${s.border}`}>
                        <span className={`shrink-0 font-bold text-sm leading-tight ${SEVERITY_STYLES[f.severity].pill.split(" ").find(c => c.startsWith("text-"))}`}>{s.icon}</span>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-0.5">
                            <span className={`text-[10px] font-semibold uppercase tracking-wide px-1.5 py-0.5 rounded border ${s.pill}`}>{f.severity}</span>
                            <span className="text-muted-foreground text-[10px]">{f.category}</span>
                          </div>
                          <p className="text-foreground leading-snug">{f.message}</p>
                          {f.detail && <p className="text-muted-foreground mt-0.5 text-[10px]">{f.detail}</p>}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : (
            <div className="p-6 text-center text-sm text-muted-foreground">
              {spamChecking
                ? <><span className="animate-pulse">Scanning your email for deliverability issues…</span></>
                : "Enter your subject line and hit Run Check to score your email against 20+ spam signals"
              }
            </div>
          )}
        </div>
      )}

      {/* ── Editor / Preview panes ── */}
      <div className="flex-1 flex gap-4 min-h-0">
        {(viewMode === "split" || viewMode === "editor") && (
          <div className={`flex flex-col ${viewMode === "split" ? "flex-1" : "w-full"}`}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-muted-foreground font-medium uppercase tracking-wide">HTML Source</span>
              <span className="text-xs text-muted-foreground">{html.length.toLocaleString()} chars</span>
            </div>
            <Textarea
              className="flex-1 font-mono text-xs resize-none bg-[#0d1117] border-border text-green-300 leading-relaxed"
              value={html}
              onChange={e => { setHtml(e.target.value); setDebugged(false); setSpamResult(null); }}
              spellCheck={false}
            />
          </div>
        )}
        {(viewMode === "split" || viewMode === "preview") && (
          <div className={`flex flex-col ${viewMode === "split" ? "flex-1" : "w-full"}`}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Live Preview</span>
              <span className="text-xs text-muted-foreground">Rendered output</span>
            </div>
            <div className="flex-1 border border-border rounded-lg overflow-hidden bg-white">
              <iframe
                srcDoc={html}
                className="w-full h-full"
                sandbox="allow-same-origin"
                title="Email preview"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
