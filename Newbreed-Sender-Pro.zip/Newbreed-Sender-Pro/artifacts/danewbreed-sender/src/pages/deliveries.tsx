import { useState } from "react";
import { useListDeliveries, useGetDeliveryStats, useListCampaigns, getListDeliveriesQueryKey } from "@workspace/api-client-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";

export default function Deliveries() {
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState("");
  const [campaignFilter, setCampaignFilter] = useState("");

  const { data: stats } = useGetDeliveryStats();
  const { data: campaigns } = useListCampaigns();
  const { data: deliveriesPage, isLoading } = useListDeliveries({
    page,
    limit: 50,
    ...(statusFilter ? { status: statusFilter } : {}),
    ...(campaignFilter ? { campaignId: parseInt(campaignFilter) } : {}),
  });

  const channelData = stats?.byChannel
    ? Object.entries(stats.byChannel).map(([channel, data]: [string, any]) => ({
        name: channel.toUpperCase(),
        sent: data.sent || 0,
        failed: data.failed || 0,
      }))
    : [];

  const activityData = (stats?.recentActivity as any[] || []).map((row: any) => ({
    time: new Date(row.hour).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    sent: Number(row.sent || 0),
    failed: Number(row.failed || 0),
  }));

  const totalPages = deliveriesPage ? Math.ceil(deliveriesPage.total / 50) : 1;

  const statCards = [
    { label: "Total Sent", value: stats?.totalSent?.toLocaleString() ?? "0", color: "text-green-400" },
    { label: "Total Failed", value: stats?.totalFailed?.toLocaleString() ?? "0", color: "text-red-400" },
    { label: "Pending", value: stats?.totalPending?.toLocaleString() ?? "0", color: "text-yellow-400" },
    { label: "Delivery Rate", value: stats?.deliveryRate ? `${(stats.deliveryRate * 100).toFixed(1)}%` : "0%", color: "text-blue-400" },
  ];

  const statusColors: Record<string, string> = {
    sent: "status-badge-sent", failed: "status-badge-failed", pending: "status-badge-pending",
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">Delivery Insights</h2>
        <p className="text-sm text-muted-foreground mt-1">Real-time delivery tracking and analytics</p>
      </div>

      <div className="grid grid-cols-4 gap-4">
        {statCards.map((card) => (
          <div key={card.label} className="bg-card border border-border rounded-lg p-4">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">{card.label}</p>
            <p className={`text-2xl font-bold mt-1 ${card.color}`}>{card.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-card border border-border rounded-lg p-4">
          <h3 className="text-sm font-medium mb-4">Sent vs Failed by Channel</h3>
          {channelData.length > 0 ? (
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={channelData}>
                <XAxis dataKey="name" tick={{ fill: "#9ca3af", fontSize: 11 }} />
                <YAxis tick={{ fill: "#9ca3af", fontSize: 11 }} />
                <Tooltip contentStyle={{ background: "#1e2030", border: "1px solid #2d3148", color: "#e2e8f0", fontSize: 12 }} />
                <Bar dataKey="sent" name="Sent" fill="hsl(142, 71%, 45%)" radius={[3, 3, 0, 0]} />
                <Bar dataKey="failed" name="Failed" fill="hsl(0, 72%, 51%)" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-40 flex items-center justify-center text-muted-foreground text-sm">No data yet</div>
          )}
        </div>

        <div className="bg-card border border-border rounded-lg p-4">
          <h3 className="text-sm font-medium mb-4">Activity (Last 24 Hours)</h3>
          {activityData.length > 0 ? (
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={activityData}>
                <XAxis dataKey="time" tick={{ fill: "#9ca3af", fontSize: 10 }} />
                <YAxis tick={{ fill: "#9ca3af", fontSize: 11 }} />
                <Tooltip contentStyle={{ background: "#1e2030", border: "1px solid #2d3148", color: "#e2e8f0", fontSize: 12 }} />
                <Line type="monotone" dataKey="sent" name="Sent" stroke="hsl(142, 71%, 45%)" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="failed" name="Failed" stroke="hsl(0, 72%, 51%)" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-40 flex items-center justify-center text-muted-foreground text-sm">No activity yet</div>
          )}
        </div>
      </div>

      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <h3 className="text-sm font-medium">Delivery Log</h3>
          <div className="flex gap-2">
            <select
              className="text-xs bg-muted border border-border rounded px-2 py-1.5 text-foreground"
              value={campaignFilter}
              onChange={e => { setCampaignFilter(e.target.value); setPage(1); }}
            >
              <option value="">All Campaigns</option>
              {(campaigns || []).map(c => <option key={c.id} value={String(c.id)}>{c.name}</option>)}
            </select>
            <select
              className="text-xs bg-muted border border-border rounded px-2 py-1.5 text-foreground"
              value={statusFilter}
              onChange={e => { setStatusFilter(e.target.value); setPage(1); }}
            >
              <option value="">All Statuses</option>
              <option value="sent">Sent</option>
              <option value="failed">Failed</option>
              <option value="pending">Pending</option>
            </select>
          </div>
        </div>

        {isLoading ? (
          <div className="p-8 text-center text-muted-foreground">Loading...</div>
        ) : deliveriesPage && deliveriesPage.data.length > 0 ? (
          <>
            <table className="w-full text-sm">
              <thead className="border-b border-border bg-muted/30">
                <tr>
                  <th className="text-left px-4 py-3 text-muted-foreground font-medium">Recipient</th>
                  <th className="text-left px-4 py-3 text-muted-foreground font-medium">Campaign</th>
                  <th className="text-left px-4 py-3 text-muted-foreground font-medium">Status</th>
                  <th className="text-left px-4 py-3 text-muted-foreground font-medium">Channel</th>
                  <th className="text-left px-4 py-3 text-muted-foreground font-medium">Subject</th>
                  <th className="text-left px-4 py-3 text-muted-foreground font-medium">Time</th>
                </tr>
              </thead>
              <tbody>
                {deliveriesPage.data.map((d) => (
                  <tr key={d.id} className="border-b border-border/50 last:border-0 hover:bg-muted/20">
                    <td className="px-4 py-2.5 font-mono text-xs text-foreground">{d.recipient}</td>
                    <td className="px-4 py-2.5 text-muted-foreground text-xs truncate max-w-[140px]">{d.campaignName || "-"}</td>
                    <td className="px-4 py-2.5">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColors[d.status] ?? "status-badge-pending"}`}>{d.status}</span>
                    </td>
                    <td className="px-4 py-2.5 text-muted-foreground uppercase text-xs">{d.channel}</td>
                    <td className="px-4 py-2.5 text-muted-foreground text-xs truncate max-w-[180px]">{d.subject || "-"}</td>
                    <td className="px-4 py-2.5 text-muted-foreground text-xs">{new Date(d.createdAt).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {totalPages > 1 && (
              <div className="flex items-center justify-between px-4 py-3 border-t border-border">
                <span className="text-xs text-muted-foreground">Page {page} of {totalPages} — {deliveriesPage.total.toLocaleString()} total</span>
                <div className="flex gap-2">
                  <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="text-xs px-3 py-1.5 bg-muted border border-border rounded disabled:opacity-50 hover:bg-accent">Previous</button>
                  <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="text-xs px-3 py-1.5 bg-muted border border-border rounded disabled:opacity-50 hover:bg-accent">Next</button>
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="p-12 text-center text-muted-foreground">
            <p className="text-base font-medium">No deliveries yet</p>
            <p className="text-sm mt-1">Send a campaign to see delivery logs here</p>
          </div>
        )}
      </div>
    </div>
  );
}
