import { useState, useEffect, useRef, useCallback } from "react";
import {
  useListCampaigns, useCreateCampaign, useUpdateCampaign, useDeleteCampaign,
  useSendCampaign, usePauseCampaign, useRestartCampaign, useListSmtps, useListAwsConfigs,
  useListSendgridConfigs, useListResendConfigs, useListSmsConfigs, useListLeadFolders,
  getListCampaignsQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from "recharts";

// ─── Searchable SMTP combobox ─────────────────────────────────────────────────
function SmtpSearchSelect({
  smtps,
  value,
  placeholder,
  onChange,
}: {
  smtps: any[];
  value: string;
  placeholder?: string;
  onChange: (id: string, smtp: any | null) => void;
}) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const ref = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const selected = smtps.find(s => String(s.id) === value);
  const filtered = smtps.filter(s => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      (s.label || "").toLowerCase().includes(q) ||
      (s.host || "").toLowerCase().includes(q) ||
      (s.user || "").toLowerCase().includes(q)
    );
  });

  // Close on outside click
  useEffect(() => {
    function onDown(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false); setSearch("");
      }
    }
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, []);

  function pick(smtp: any) {
    onChange(String(smtp.id), smtp);
    setOpen(false);
    setSearch("");
  }

  return (
    <div ref={ref} className="relative mt-1">
      <button
        type="button"
        onClick={() => { setOpen(o => !o); setTimeout(() => inputRef.current?.focus(), 50); }}
        className="w-full flex items-center justify-between h-10 px-3 py-2 text-sm border border-input bg-background rounded-md hover:bg-accent/40 transition-colors text-left"
      >
        <span className={selected ? "text-foreground" : "text-muted-foreground"}>
          {selected
            ? <span>{selected.label || selected.host} <span className={`text-xs ml-1 ${selected.status === "verified" ? "text-green-400" : selected.status === "failed" ? "text-red-400" : "text-muted-foreground"}`}>({selected.status})</span></span>
            : (placeholder || "Select SMTP…")}
        </span>
        <svg className="h-4 w-4 text-muted-foreground shrink-0 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
      </button>
      {open && (
        <div className="absolute z-50 mt-1 w-full bg-popover border border-border rounded-md shadow-xl">
          <div className="p-2 border-b border-border">
            <input
              ref={inputRef}
              type="text"
              className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
              placeholder="Search by host, label, user…"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
          <div className="max-h-52 overflow-y-auto">
            {filtered.length === 0 ? (
              <div className="p-3 text-sm text-muted-foreground text-center">No results</div>
            ) : filtered.map(s => (
              <button
                key={s.id}
                type="button"
                className={`w-full text-left px-3 py-2 text-sm hover:bg-accent transition-colors ${String(s.id) === value ? "bg-primary/10" : ""}`}
                onClick={() => pick(s)}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-medium truncate">{s.label || s.host}</span>
                  <span className={`text-xs shrink-0 ${s.status === "verified" ? "text-green-400" : s.status === "failed" ? "text-red-400" : "text-muted-foreground"}`}>{s.status}</span>
                </div>
                <div className="text-xs text-muted-foreground font-mono truncate">{s.user}</div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

type CampaignFormData = {
  name: string; type: string; subject: string; body: string; isHtml: boolean;
  fromName: string; fromEmail: string; senderType: string;
  smtpId: string; awsConfigId: string; sendgridConfigId: string; resendConfigId: string; smsConfigId: string;
  rotateSmtps: boolean; useProxy: boolean; leadType: string;
  leadFolderId: string;
  sendRatePerMinute: string;
  scheduledAt: string;
};

const defaultForm: CampaignFormData = {
  name: "", type: "email", subject: "", body: "", isHtml: false,
  fromName: "Newbreed Pro Sender", fromEmail: "", senderType: "smtp",
  smtpId: "", awsConfigId: "", sendgridConfigId: "", resendConfigId: "", smsConfigId: "",
  rotateSmtps: false, useProxy: false, leadType: "email",
  leadFolderId: "",
  sendRatePerMinute: "0",
  scheduledAt: "",
};

function CampaignAnalyticsModal({ campaignId, onClose }: { campaignId: number; onClose: () => void }) {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchAnalytics = useCallback(async () => {
    try {
      const res = await fetch(`/api/campaigns/${campaignId}/analytics`);
      if (res.ok) setData(await res.json());
    } catch {}
    setLoading(false);
  }, [campaignId]);

  useEffect(() => {
    fetchAnalytics();
    intervalRef.current = setInterval(fetchAnalytics, 4000);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [fetchAnalytics]);

  // Stop polling once campaign is no longer actively sending
  useEffect(() => {
    const status = data?.campaign?.status;
    if (status && status !== "sending") {
      if (intervalRef.current) { clearInterval(intervalRef.current); intervalRef.current = null; }
    }
  }, [data?.campaign?.status]);

  const fmt = (ts: string) => new Date(ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  const chartData = data?.timeline?.map((p: any) => ({ time: fmt(p.ts), Sent: p.sent, Failed: p.failed })) ?? [];
  const s = data?.summary;
  const isSending = data?.campaign?.status === "sending";

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <span>Campaign Analytics</span>
            {data?.campaign?.name && <span className="text-sm font-normal text-muted-foreground">— {data.campaign.name}</span>}
            {isSending && (
              <span className="flex items-center gap-1.5 text-xs bg-green-500/15 text-green-400 border border-green-500/30 px-2 py-0.5 rounded-full">
                <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse inline-block" />Live
              </span>
            )}
          </DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">Loading analytics...</div>
        ) : (
          <div className="space-y-5 pt-1">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { label: "Sent", value: s?.totalSent?.toLocaleString() ?? "0", color: "text-green-400" },
                { label: "Failed", value: s?.totalFailed?.toLocaleString() ?? "0", color: "text-red-400" },
                { label: "Delivery Rate", value: `${s?.deliveryRate ?? 0}%`, color: s?.deliveryRate >= 90 ? "text-green-400" : s?.deliveryRate >= 70 ? "text-yellow-400" : "text-red-400" },
                { label: "Avg / min", value: s?.avgPerMinute ? `${s.avgPerMinute}` : "—", color: "text-blue-400" },
              ].map(card => (
                <div key={card.label} className="bg-muted/30 border border-border rounded-lg px-4 py-3">
                  <div className="text-xs text-muted-foreground">{card.label}</div>
                  <div className={`text-xl font-bold mt-1 ${card.color}`}>{card.value}</div>
                </div>
              ))}
            </div>
            {data?.campaign?.sendRatePerMinute > 0 && (
              <div className="text-xs bg-orange-500/10 border border-orange-500/30 text-orange-400 rounded px-3 py-2">
                Throttle active: {data.campaign.sendRatePerMinute}/min · {(60000 / data.campaign.sendRatePerMinute).toFixed(0)}ms between sends
              </div>
            )}
            <div>
              <div className="text-sm font-medium mb-2">Delivery Timeline</div>
              {chartData.length === 0 ? (
                <div className="h-48 flex items-center justify-center border border-border rounded-lg bg-muted/10">
                  <span className="text-sm text-muted-foreground">{s?.totalSent === 0 && s?.totalFailed === 0 ? "No deliveries recorded yet" : "Waiting for data..."}</span>
                </div>
              ) : (
                <div className="h-52 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={chartData} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
                      <defs>
                        <linearGradient id="sentGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                        </linearGradient>
                        <linearGradient id="failedGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                      <XAxis dataKey="time" tick={{ fontSize: 10, fill: "#888" }} />
                      <YAxis tick={{ fontSize: 10, fill: "#888" }} allowDecimals={false} />
                      <Tooltip contentStyle={{ background: "#1a1a2e", border: "1px solid #333", borderRadius: 6, fontSize: 12 }} labelStyle={{ color: "#aaa" }} />
                      <Legend wrapperStyle={{ fontSize: 12 }} />
                      <Area type="monotone" dataKey="Sent" stroke="#22c55e" fill="url(#sentGrad)" strokeWidth={2} dot={false} />
                      <Area type="monotone" dataKey="Failed" stroke="#ef4444" fill="url(#failedGrad)" strokeWidth={2} dot={false} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>
            {data?.recentFailures?.length > 0 && (
              <div>
                <div className="text-sm font-medium mb-2 text-red-400">Recent Failures</div>
                <div className="border border-border rounded-lg overflow-hidden">
                  <table className="w-full text-xs">
                    <thead className="bg-muted/30 border-b border-border">
                      <tr>
                        <th className="text-left px-3 py-2 text-muted-foreground font-medium">Recipient</th>
                        <th className="text-left px-3 py-2 text-muted-foreground font-medium">Error</th>
                        <th className="text-left px-3 py-2 text-muted-foreground font-medium">Time</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.recentFailures.map((f: any, i: number) => (
                        <tr key={i} className="border-b border-border/40 last:border-0">
                          <td className="px-3 py-2 font-mono text-foreground/80">{f.recipient}</td>
                          <td className="px-3 py-2 text-red-400 max-w-[240px] truncate">{f.error || "Unknown error"}</td>
                          <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">{new Date(f.created_at).toLocaleTimeString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
            {(s?.firstSent || s?.lastSent) && (
              <div className="text-xs text-muted-foreground flex gap-4">
                {s.firstSent && <span>First sent: {new Date(s.firstSent).toLocaleString()}</span>}
                {s.lastSent && <span>Last sent: {new Date(s.lastSent).toLocaleString()}</span>}
              </div>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function toLocalDatetimeValue(isoStr: string | null | undefined) {
  if (!isoStr) return "";
  const d = new Date(isoStr);
  if (isNaN(d.getTime())) return "";
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export default function Campaigns({ mode = "email" }: { mode?: "email" | "sms" }) {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: campaigns, isLoading } = useListCampaigns();
  const { data: smtps } = useListSmtps();
  const { data: awsConfigs } = useListAwsConfigs();
  const { data: sgConfigs } = useListSendgridConfigs();
  const { data: resendConfigs } = useListResendConfigs();
  const { data: smsConfigs } = useListSmsConfigs();
  const { data: folders } = useListLeadFolders();
  const createCampaign = useCreateCampaign();
  const updateCampaign = useUpdateCampaign();
  const deleteCampaign = useDeleteCampaign();
  const sendCampaign = useSendCampaign();
  const pauseCampaign = usePauseCampaign();
  const restartCampaign = useRestartCampaign();

  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState<CampaignFormData>({ ...defaultForm, type: mode, leadType: mode, senderType: mode === "sms" ? "sms" : "smtp" });
  const [sending, setSending] = useState<number | null>(null);
  const [scheduleOpen, setScheduleOpen] = useState<number | null>(null);
  const [scheduleDate, setScheduleDate] = useState("");
  const [analyticsId, setAnalyticsId] = useState<number | null>(null);

  const refresh = () => qc.invalidateQueries({ queryKey: getListCampaignsQueryKey() });

  function openCreate() { setEditId(null); setForm({ ...defaultForm, type: mode, leadType: mode, senderType: mode === "sms" ? "sms" : "smtp" }); setOpen(true); }
  function openEdit(c: any) {
    setEditId(c.id);
    setForm({
      name: c.name || "", type: c.type || "email", subject: c.subject || "", body: c.body || "",
      isHtml: c.isHtml || false, fromName: c.fromName || "Newbreed Pro Sender",
      fromEmail: c.fromEmail || "", senderType: c.senderType || "smtp",
      smtpId: c.smtpId ? String(c.smtpId) : "", awsConfigId: c.awsConfigId ? String(c.awsConfigId) : "",
      sendgridConfigId: c.sendgridConfigId ? String(c.sendgridConfigId) : "",
      resendConfigId: c.resendConfigId ? String(c.resendConfigId) : "",
      smsConfigId: c.smsConfigId ? String(c.smsConfigId) : "",
      rotateSmtps: c.rotateSmtps || false, useProxy: c.useProxy || false,
      leadType: c.leadType || "email",
      leadFolderId: c.leadFolderId ? String(c.leadFolderId) : "",
      sendRatePerMinute: c.sendRatePerMinute != null ? String(c.sendRatePerMinute) : "0",
      scheduledAt: toLocalDatetimeValue(c.scheduledAt),
    });
    setOpen(true);
  }

  function buildPayload() {
    const payload: any = {
      name: form.name, type: form.type, subject: form.subject || undefined, body: form.body,
      isHtml: form.isHtml, fromName: form.fromName || undefined, fromEmail: form.fromEmail || undefined,
      senderType: form.senderType || undefined,
      smtpId: form.smtpId ? parseInt(form.smtpId) : undefined,
      awsConfigId: form.awsConfigId ? parseInt(form.awsConfigId) : undefined,
      sendgridConfigId: form.sendgridConfigId ? parseInt(form.sendgridConfigId) : undefined,
      resendConfigId: form.resendConfigId ? parseInt(form.resendConfigId) : undefined,
      smsConfigId: form.smsConfigId ? parseInt(form.smsConfigId) : undefined,
      rotateSmtps: form.rotateSmtps, useProxy: form.useProxy,
      leadType: form.leadType,
      sendRatePerMinute: parseInt(form.sendRatePerMinute) || 0,
      scheduledAt: form.scheduledAt ? new Date(form.scheduledAt).toISOString() : undefined,
    };
    if (form.leadFolderId) payload.leadFolderId = parseInt(form.leadFolderId);
    else payload.leadFolderId = null;
    return payload;
  }

  function handleSave() {
    if (!form.name || !form.body) return toast({ title: "Name and body required", variant: "destructive" });
    if (editId) {
      updateCampaign.mutate({ id: editId, data: buildPayload() }, {
        onSuccess: () => { refresh(); setOpen(false); toast({ title: "Campaign updated" }); },
        onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
      });
    } else {
      createCampaign.mutate({ data: buildPayload() }, {
        onSuccess: () => { refresh(); setOpen(false); toast({ title: "Campaign created" }); },
        onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
      });
    }
    return;
  }

  function handleSend(id: number) {
    setSending(id);
    sendCampaign.mutate({ id }, {
      onSuccess: () => { refresh(); setSending(null); toast({ title: "Campaign started" }); },
      onError: (e: any) => { setSending(null); toast({ title: "Error", description: e.message, variant: "destructive" }); },
    });
  }

  function handlePause(id: number) {
    pauseCampaign.mutate({ id }, { onSuccess: () => { refresh(); toast({ title: "Campaign paused" }); } });
  }

  function handleRestart(id: number) {
    setSending(id);
    restartCampaign.mutate({ id }, {
      onSuccess: () => { refresh(); setSending(null); toast({ title: "Campaign restarted" }); },
      onError: (e: any) => { setSending(null); toast({ title: "Error", description: e.message, variant: "destructive" }); },
    });
  }

  function handleDelete(id: number) {
    if (!confirm("Delete this campaign?")) return;
    deleteCampaign.mutate({ id }, { onSuccess: () => { refresh(); toast({ title: "Deleted" }); } });
  }

  async function handleSchedule() {
    if (!scheduleOpen || !scheduleDate) return;
    const dt = new Date(scheduleDate);
    if (dt <= new Date()) return toast({ title: "Choose a future date", variant: "destructive" });
    try {
      const res = await fetch(`/api/campaigns/${scheduleOpen}/schedule`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scheduledAt: dt.toISOString() }),
      });
      if (!res.ok) { const err = await res.json(); throw new Error(err.error || "Failed"); }
      refresh(); setScheduleOpen(null); setScheduleDate("");
      toast({ title: "Campaign scheduled", description: `Will send at ${dt.toLocaleString()}` });
    } catch (e: any) { toast({ title: "Error", description: e.message, variant: "destructive" }); }
    return;
  }

  async function handleUnschedule(id: number) {
    await fetch(`/api/campaigns/${id}/unschedule`, { method: "POST" });
    refresh(); toast({ title: "Schedule removed" });
  }

  const statusColor: Record<string, string> = {
    draft: "status-badge-draft", sending: "status-badge-sending",
    completed: "status-badge-completed", paused: "status-badge-paused",
    failed: "status-badge-failed", scheduled: "status-badge-pending",
  };

  const visibleCampaigns = campaigns?.filter(c => c.type === mode) ?? [];
  const scheduledCount = visibleCampaigns.filter(c => c.status === "scheduled").length;
  const emailFolders = folders?.filter(f => f.type === "email") ?? [];
  const smsFolders = folders?.filter(f => f.type === "sms") ?? [];
  const relevantFolders = form.type === "sms" ? smsFolders : emailFolders;
  const smtpList = smtps ?? [];

  function getFolderName(id: number | null | undefined) {
    if (!id) return null;
    return folders?.find(f => f.id === id)?.name ?? null;
  }

  // Auto-fill fromEmail from selected SMTP
  function onSmtpSelect(id: string, smtp: any | null) {
    setForm(f => ({
      ...f,
      smtpId: id,
      fromEmail: smtp?.user ?? f.fromEmail,
    }));
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">Campaigns</h2>
          <p className="text-sm text-muted-foreground mt-1">
            {visibleCampaigns.length} campaigns
            {scheduledCount > 0 && <span className="ml-2 text-yellow-400">{scheduledCount} scheduled</span>}
          </p>
        </div>
        <Button onClick={openCreate}>New Campaign</Button>
      </div>

      {scheduledCount > 0 && (
        <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-3 flex items-center gap-3">
          <span className="text-yellow-400 text-sm font-medium">Scheduled campaigns</span>
          <span className="text-yellow-300 text-xs">The scheduler checks every minute and auto-triggers campaigns when their time arrives.</span>
        </div>
      )}

      <div className="bg-card border border-border rounded-lg overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-muted-foreground">Loading...</div>
        ) : visibleCampaigns.length > 0 ? (
          <table className="w-full text-sm">
            <thead className="border-b border-border bg-muted/30">
              <tr>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">Name</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">Status</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">Audience</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">Scheduled</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">Progress</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">Rate</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">Sender</th>
                <th className="text-right px-4 py-3 text-muted-foreground font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {visibleCampaigns.map((c) => {
                const total = c.totalLeads || 0;
                const sent = c.totalSent || 0;
                const pct = total > 0 ? Math.round((sent / total) * 100) : 0;
                const folderName = getFolderName(c.leadFolderId);
                return (
                  <tr key={c.id} className="border-b border-border/50 last:border-0 hover:bg-muted/20">
                    <td className="px-4 py-3">
                      <div className="font-medium text-foreground">{c.name}</div>
                      {c.subject && <div className="text-xs text-muted-foreground truncate max-w-[160px]">{c.subject}</div>}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColor[c.status] ?? "status-badge-draft"}`}>{c.status}</span>
                    </td>
                    <td className="px-4 py-3">
                      {folderName ? (
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs">📁</span>
                          <span className="text-xs text-blue-400 font-medium truncate max-w-[100px]">{folderName}</span>
                        </div>
                      ) : (
                        <span className="text-xs text-muted-foreground capitalize">{c.leadType || "all email"}</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">
                      {c.scheduledAt ? (
                        <div>
                          <div className="text-yellow-400 font-medium">{new Date(c.scheduledAt).toLocaleDateString()}</div>
                          <div>{new Date(c.scheduledAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</div>
                        </div>
                      ) : "—"}
                    </td>
                    <td className="px-4 py-3">
                      <div className="text-xs text-muted-foreground">{sent.toLocaleString()} / {total.toLocaleString()} ({pct}%)</div>
                      <div className="w-20 h-1.5 bg-border rounded-full mt-1 overflow-hidden">
                        <div className="h-full bg-primary rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                      {(c.totalFailed ?? 0) > 0 && <div className="text-xs text-red-400 mt-0.5">{c.totalFailed} failed</div>}
                    </td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">
                      {(c.sendRatePerMinute ?? 0) > 0
                        ? <span className="text-orange-400 font-medium">{c.sendRatePerMinute}/min</span>
                        : <span className="text-muted-foreground">∞</span>}
                    </td>
                    <td className="px-4 py-3 text-xs text-muted-foreground uppercase">{c.senderType || "—"}</td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex gap-1.5 justify-end flex-wrap">
                        <Button size="sm" variant="outline" onClick={() => setAnalyticsId(c.id)} className="text-xs text-blue-400 border-blue-500/40 hover:bg-blue-500/10">Analytics</Button>
                        <Button size="sm" variant="outline" onClick={() => openEdit(c)} className="text-xs">Edit</Button>
                        {c.status === "sending" ? (
                          <Button size="sm" variant="outline" onClick={() => handlePause(c.id)} className="text-xs">Pause</Button>
                        ) : (c.status === "draft" || c.status === "paused") ? (
                          <>
                            <Button size="sm" onClick={() => c.status === "paused" ? handleRestart(c.id) : handleSend(c.id)} disabled={sending === c.id} className="text-xs bg-green-600 hover:bg-green-700">
                              {sending === c.id ? "Starting..." : c.status === "paused" ? "Resume" : "Send Now"}
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => { setScheduleOpen(c.id); setScheduleDate(""); }} className="text-xs text-yellow-400 border-yellow-500/40 hover:bg-yellow-500/10">
                              Schedule
                            </Button>
                          </>
                        ) : c.status === "scheduled" ? (
                          <>
                            <Button size="sm" onClick={() => handleSend(c.id)} disabled={sending === c.id} className="text-xs bg-green-600 hover:bg-green-700">
                              {sending === c.id ? "Starting..." : "Send Now"}
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => handleUnschedule(c.id)} className="text-xs text-muted-foreground">
                              Unschedule
                            </Button>
                          </>
                        ) : (c.status === "completed" || c.status === "failed") ? (
                          <Button size="sm" variant="outline" onClick={() => handleRestart(c.id)} disabled={sending === c.id} className="text-xs text-purple-400 border-purple-500/40 hover:bg-purple-500/10">
                            {sending === c.id ? "Restarting..." : "↺ Restart"}
                          </Button>
                        ) : null}
                        <Button size="sm" variant="destructive" onClick={() => handleDelete(c.id)} className="text-xs">Delete</Button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        ) : (
          <div className="p-12 text-center text-muted-foreground">
            <p className="text-base font-medium">No campaigns yet</p>
            <p className="text-sm mt-1">Create your first campaign to start sending</p>
          </div>
        )}
      </div>

      {/* Schedule Dialog */}
      <Dialog open={scheduleOpen !== null} onOpenChange={() => setScheduleOpen(null)}>
        <DialogContent className="bg-card border-border max-w-sm">
          <DialogHeader><DialogTitle>Schedule Campaign</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <p className="text-sm text-muted-foreground">The campaign will automatically start sending at the specified date and time.</p>
            <div>
              <Label>Date & Time *</Label>
              <Input className="mt-1" type="datetime-local" value={scheduleDate} onChange={e => setScheduleDate(e.target.value)} min={new Date(Date.now() + 60000).toISOString().slice(0, 16)} />
            </div>
            {scheduleDate && (
              <div className="bg-yellow-500/10 border border-yellow-500/30 rounded p-2 text-xs text-yellow-400">
                Will send at: {new Date(scheduleDate).toLocaleString()}
              </div>
            )}
            <Button className="w-full bg-yellow-600 hover:bg-yellow-700 text-white" onClick={handleSchedule} disabled={!scheduleDate}>
              Schedule Campaign
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Create / Edit Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-card border-border max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editId ? "Edit Campaign" : "New Campaign"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">

            <div className="grid grid-cols-2 gap-3">
              <div><Label>Campaign Name *</Label><Input className="mt-1" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="My Campaign" /></div>
              <div><Label>Type</Label>
                <Select value={form.type} onValueChange={v => setForm(f => ({ ...f, type: v, leadType: v === "sms" ? "sms" : "email", leadFolderId: "" }))}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="email">Email</SelectItem><SelectItem value="sms">SMS</SelectItem></SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div><Label>From Name <span className="text-xs text-muted-foreground">(spoofs sender)</span></Label><Input className="mt-1" value={form.fromName} onChange={e => setForm(f => ({ ...f, fromName: e.target.value }))} /></div>
              <div>
                <Label>From Email <span className="text-xs text-muted-foreground">(auto-filled from SMTP)</span></Label>
                <Input className="mt-1" value={form.fromEmail} onChange={e => setForm(f => ({ ...f, fromEmail: e.target.value }))} placeholder="auto-filled when SMTP selected" />
              </div>
            </div>

            {form.type === "email" && (
              <div><Label>Subject</Label><Input className="mt-1" value={form.subject} onChange={e => setForm(f => ({ ...f, subject: e.target.value }))} placeholder="Your subject line..." /></div>
            )}

            <div>
              <div className="flex items-center justify-between mb-1">
                <Label>Body *</Label>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">HTML</span>
                  <Switch checked={form.isHtml} onCheckedChange={v => setForm(f => ({ ...f, isHtml: v }))} />
                </div>
              </div>
              <Textarea className={`mt-1 h-32 resize-none ${form.isHtml ? "font-mono text-xs" : ""}`} value={form.body} onChange={e => setForm(f => ({ ...f, body: e.target.value }))} placeholder={form.isHtml ? "<html>...</html>" : "Write your message..."} />
            </div>

            {/* Audience */}
            <div className="bg-muted/20 border border-border rounded-lg p-3 space-y-3">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">Target Audience</span>
                <span className="text-xs text-muted-foreground">— choose a folder for precise targeting</span>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Lead Pool</Label>
                  <Select value={form.leadType} onValueChange={v => setForm(f => ({ ...f, leadType: v, leadFolderId: "" }))}>
                    <SelectTrigger className="mt-1 h-9 text-xs"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="email">All Email Leads</SelectItem>
                      <SelectItem value="sms">All SMS Leads</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Specific Folder <span className="ml-1 text-muted-foreground font-normal">(overrides pool)</span></Label>
                  <Select value={form.leadFolderId || "__none"} onValueChange={v => setForm(f => ({ ...f, leadFolderId: v === "__none" ? "" : v }))}>
                    <SelectTrigger className="mt-1 h-9 text-xs"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__none">— No folder (use pool) —</SelectItem>
                      {relevantFolders.length > 0
                        ? relevantFolders.map(folder => <SelectItem key={folder.id} value={String(folder.id)}>📁 {folder.name} ({folder.leadCount?.toLocaleString() ?? 0} leads)</SelectItem>)
                        : <SelectItem value="__empty" disabled>No {form.type} folders yet</SelectItem>
                      }
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className={`text-xs rounded px-2 py-1.5 border ${form.leadFolderId ? "bg-blue-500/10 border-blue-500/30 text-blue-400" : "bg-muted/30 border-border text-muted-foreground"}`}>
                {form.leadFolderId
                  ? <><span className="font-medium">Folder targeting: </span>{getFolderName(parseInt(form.leadFolderId)) ?? "Selected folder"} — only leads in this folder will be contacted</>
                  : <><span className="font-medium">Pool targeting: </span>All {form.leadType} leads will be contacted</>
                }
              </div>
            </div>

            {/* Sender */}
            <div>
              <Label>Sender</Label>
              <Select value={form.senderType} onValueChange={v => setForm(f => ({ ...f, senderType: v }))}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {mode === "email" ? (
                    <>
                      <SelectItem value="smtp">SMTP / direct mailbox</SelectItem>
                      <SelectItem value="resend">Resend API</SelectItem>
                      <SelectItem value="aws">AWS SES</SelectItem>
                      <SelectItem value="sendgrid">SendGrid</SelectItem>
                    </>
                  ) : <SelectItem value="sms">Twilio / SMS provider</SelectItem>}
                </SelectContent>
              </Select>
            </div>

            {form.senderType === "smtp" && (
              <div className="space-y-2">
                <div>
                  <Label>SMTP Server</Label>
                  {/* Searchable combobox — handles unlimited SMTPs */}
                  <SmtpSearchSelect
                    smtps={smtpList}
                    value={form.smtpId}
                    placeholder="Search and select SMTP…"
                    onChange={onSmtpSelect}
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={form.rotateSmtps}
                    onCheckedChange={v => {
                      const firstVerified = smtpList.find(s => s.status === "verified");
                      setForm(f => ({
                        ...f,
                        rotateSmtps: v,
                        fromEmail: v && firstVerified ? firstVerified.user : f.fromEmail,
                      }));
                    }}
                  />
                  <Label className="text-sm">Rotate through all verified SMTPs</Label>
                </div>
                {form.rotateSmtps && (
                  <div className="text-xs bg-green-500/10 border border-green-500/20 rounded p-2 text-green-400">
                    Will rotate across {smtpList.filter(s => s.status === "verified").length} verified SMTP(s). From email auto-set to first verified sender.
                  </div>
                )}
              </div>
            )}
            {form.senderType === "aws" && (
              <div><Label>AWS Config</Label>
                <Select value={form.awsConfigId} onValueChange={v => setForm(f => ({ ...f, awsConfigId: v }))}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Select AWS config" /></SelectTrigger>
                  <SelectContent className="max-h-60 overflow-y-auto">{(awsConfigs || []).map(a => <SelectItem key={a.id} value={String(a.id)}>{a.label || a.region}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            )}
            {form.senderType === "sendgrid" && (
              <div><Label>SendGrid Config</Label>
                <Select value={form.sendgridConfigId} onValueChange={v => setForm(f => ({ ...f, sendgridConfigId: v }))}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Select SendGrid config" /></SelectTrigger>
                  <SelectContent className="max-h-60 overflow-y-auto">{(sgConfigs || []).map(s => <SelectItem key={s.id} value={String(s.id)}>{s.label || "SendGrid"}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            )}
            {form.senderType === "resend" && (
              <div>
                <Label>Resend sender</Label>
                <Select value={form.resendConfigId} onValueChange={v => {
                  const selected = (resendConfigs || []).find(config => String(config.id) === v);
                  setForm(f => ({ ...f, resendConfigId: v, fromEmail: selected?.fromEmail || f.fromEmail, fromName: selected?.fromName || f.fromName }));
                }}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Select verified Resend sender" /></SelectTrigger>
                  <SelectContent className="max-h-60 overflow-y-auto">{(resendConfigs || []).filter(config => config.status === "verified").map(config => <SelectItem key={config.id} value={String(config.id)}>{config.label || config.fromEmail}</SelectItem>)}</SelectContent>
                </Select>
                <p className="mt-1 text-xs text-muted-foreground">
                  {(resendConfigs || []).some(config => config.status === "verified")
                    ? "Choose any verified identity. Add and verify more identities from the Resend API page."
                    : "No verified identities yet. Add and verify one from the Resend API page."}
                </p>
              </div>
            )}
            {form.senderType === "sms" && (
              <div><Label>SMS Config</Label>
                <Select value={form.smsConfigId} onValueChange={v => setForm(f => ({ ...f, smsConfigId: v }))}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Select SMS config" /></SelectTrigger>
                  <SelectContent className="max-h-60 overflow-y-auto">{(smsConfigs || []).map(s => <SelectItem key={s.id} value={String(s.id)}>{s.label || s.provider}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            )}

            <div className="flex items-center gap-2">
              <Switch checked={form.useProxy} onCheckedChange={v => setForm(f => ({ ...f, useProxy: v }))} />
              <Label className="text-sm">Use proxy rotation</Label>
            </div>

            {/* Send Rate */}
            <div className="bg-muted/20 border border-border rounded-lg p-3 space-y-2">
              <div>
                <Label className="text-sm font-medium">Send Rate Throttle</Label>
                <p className="text-xs text-muted-foreground mt-0.5">Limit sends per minute. 0 = unlimited.</p>
              </div>
              <div className="flex items-center gap-3">
                <Input type="number" min="0" max="3600" className="w-28 h-9 text-sm" value={form.sendRatePerMinute} onChange={e => setForm(f => ({ ...f, sendRatePerMinute: e.target.value }))} placeholder="0" />
                <span className="text-sm text-muted-foreground">msgs / minute</span>
                {parseInt(form.sendRatePerMinute) > 0 && (
                  <span className="text-xs text-orange-400 font-medium">≈ {(60000 / parseInt(form.sendRatePerMinute)).toFixed(0)}ms delay</span>
                )}
              </div>
              <div className="flex gap-2 flex-wrap">
                {[0, 30, 60, 120, 300, 600].map(r => (
                  <button key={r} type="button" onClick={() => setForm(f => ({ ...f, sendRatePerMinute: String(r) }))}
                    className={`text-xs px-2 py-1 rounded border transition-colors ${form.sendRatePerMinute === String(r) ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:border-foreground/40"}`}>
                    {r === 0 ? "Unlimited" : `${r}/min`}
                  </button>
                ))}
              </div>
            </div>

            {/* Schedule */}
            <div>
              <Label>Schedule Send (optional)</Label>
              <div className="mt-1 flex items-center gap-2">
                <Input type="datetime-local" value={form.scheduledAt} onChange={e => setForm(f => ({ ...f, scheduledAt: e.target.value }))} min={new Date(Date.now() + 60000).toISOString().slice(0, 16)} className="flex-1" />
                {form.scheduledAt && <Button variant="ghost" size="sm" onClick={() => setForm(f => ({ ...f, scheduledAt: "" }))} className="text-xs text-muted-foreground">Clear</Button>}
              </div>
              {form.scheduledAt && <p className="text-xs text-yellow-400 mt-1">Will send at: {new Date(form.scheduledAt).toLocaleString()}</p>}
            </div>

            <Button className="w-full" onClick={handleSave} disabled={createCampaign.isPending || updateCampaign.isPending}>
              {(createCampaign.isPending || updateCampaign.isPending) ? "Saving..." : editId ? "Update Campaign" : "Create Campaign"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {analyticsId !== null && (
        <CampaignAnalyticsModal campaignId={analyticsId} onClose={() => setAnalyticsId(null)} />
      )}
    </div>
  );
}
