import { useState } from "react";
import { useListSmsConfigs, useCreateSmsConfig, useUpdateSmsConfig, useDeleteSmsConfig, useTestSmsConfig, useSendSms, useListAwsConfigs, useListSmtps, getListSmsConfigsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";

const CARRIER_GATEWAYS = [
  { label: "🔍 Auto-detect carrier (area code lookup)", domain: "auto" },
  { label: "AT&T", domain: "txt.att.net" },
  { label: "Verizon", domain: "vtext.com" },
  { label: "T-Mobile", domain: "tmomail.net" },
  { label: "Sprint / T-Mobile", domain: "messaging.sprintpcs.com" },
  { label: "US Cellular", domain: "email.uscc.net" },
  { label: "Cricket", domain: "mms.cricketwireless.net" },
  { label: "Boost Mobile", domain: "sms.myboostmobile.com" },
  { label: "Metro PCS", domain: "mymetropcs.com" },
  { label: "Google Fi", domain: "msg.fi.google.com" },
  { label: "Republic Wireless", domain: "text.republicwireless.com" },
];

const DEFAULT_FORM = { label: "", provider: "twilio", apiKey: "", accountSid: "", authToken: "", fromNumber: "", awsConfigId: "", smtpId: "", gatewayDomain: "auto", autoVerify: false };

export default function SmsManager() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: configs, isLoading } = useListSmsConfigs();
  const { data: awsConfigs } = useListAwsConfigs();
  const { data: smtps } = useListSmtps();
  const createConfig = useCreateSmsConfig();
  const updateConfig = useUpdateSmsConfig();
  const deleteConfig = useDeleteSmsConfig();
  const testConfig = useTestSmsConfig();
  const sendSms = useSendSms();

  const [addOpen, setAddOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [testOpen, setTestOpen] = useState<number | null>(null);
  const [sendOpen, setSendOpen] = useState<number | null>(null);
  const [testing, setTesting] = useState<number | null>(null);
  const [form, setForm] = useState({ ...DEFAULT_FORM });
  const [testPhone, setTestPhone] = useState("");
  const [sendForm, setSendForm] = useState({ to: "", message: "Test SMS from Danewbreed Sender Pro" });

  // Auto-verify dialog after adding a config
  const [autoVerifyId, setAutoVerifyId] = useState<number | null>(null);
  const [autoVerifyPhone, setAutoVerifyPhone] = useState("");

  const refresh = () => qc.invalidateQueries({ queryKey: getListSmsConfigsQueryKey() });

  function openCreate() {
    setEditId(null);
    setForm({ ...DEFAULT_FORM });
    setAddOpen(true);
  }

  function openEdit(cfg: any) {
    setEditId(cfg.id);
    setForm({
      ...DEFAULT_FORM,
      label: cfg.label || "",
      provider: cfg.provider || "twilio",
      accountSid: cfg.accountSid || "",
      fromNumber: cfg.fromNumber || "",
      awsConfigId: cfg.awsConfigId ? String(cfg.awsConfigId) : "",
      smtpId: cfg.smtpId ? String(cfg.smtpId) : "",
      gatewayDomain: cfg.gatewayDomain || "auto",
    });
    setAddOpen(true);
  }

  function handleAdd() {
    const payload: any = {
      label: form.label || undefined,
      provider: form.provider,
      apiKey: form.apiKey || undefined,
      accountSid: form.accountSid || undefined,
      authToken: form.authToken || undefined,
      fromNumber: form.fromNumber || undefined,
      awsConfigId: form.awsConfigId ? parseInt(form.awsConfigId) : undefined,
      smtpId: form.smtpId ? parseInt(form.smtpId) : undefined,
      gatewayDomain: form.provider === "smtp_sms" ? form.gatewayDomain : undefined,
    };
    if (editId) {
      const { provider: _provider, ...updatePayload } = payload;
      updateConfig.mutate(
        { id: editId, data: updatePayload },
        {
          onSuccess: (res: any) => {
            refresh();
            setAddOpen(false);
            setEditId(null);
            setForm({ ...DEFAULT_FORM });
            toast({ title: res?.verification?.success ? "SMS account verified" : "SMS config updated", description: res?.verification?.message });
          },
          onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
        },
      );
      return;
    }

    createConfig.mutate(
      { data: payload },
      {
        onSuccess: (newCfg: any) => {
          refresh();
          setAddOpen(false);
          const shouldAutoVerify = form.autoVerify && form.provider !== "smtp_sms";
          setForm({ ...DEFAULT_FORM });
          toast({ title: newCfg?.verification?.success ? "SMS account verified" : "SMS config added", description: newCfg?.verification?.message });
          if (shouldAutoVerify) {
            setAutoVerifyId(newCfg.id);
            setAutoVerifyPhone("");
          }
        },
        onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
      }
    );
  }

  function handleAutoVerify() {
    if (!autoVerifyId || !autoVerifyPhone) return;
    setTesting(autoVerifyId);
    testConfig.mutate(
      { id: autoVerifyId, data: { toNumber: autoVerifyPhone, message: "Test SMS from Danewbreed Sender Pro" } },
      {
        onSuccess: (res) => {
          refresh();
          setTesting(null);
          setAutoVerifyId(null);
          setAutoVerifyPhone("");
          toast({
            title: res.success ? "✓ Verified!" : "Verification failed",
            description: res.message,
            variant: res.success ? "default" : "destructive",
          });
        },
        onError: (e: any) => { setTesting(null); toast({ title: "Error", description: e.message, variant: "destructive" }); },
      }
    );
  }

  function handleTest() {
    if (!testOpen || !testPhone) return;
    setTesting(testOpen);
    testConfig.mutate({ id: testOpen, data: { toNumber: testPhone, message: "Test SMS from Danewbreed Sender Pro" } }, {
      onSuccess: (res) => { refresh(); setTesting(null); setTestOpen(null); setTestPhone(""); toast({ title: res.success ? "Test passed" : "Test failed", description: res.message, variant: res.success ? "default" : "destructive" }); },
      onError: (e: any) => { setTesting(null); toast({ title: "Error", description: e.message, variant: "destructive" }); },
    });
  }

  function handleSend() {
    if (!sendOpen) return;
    sendSms.mutate({ data: { configId: sendOpen, toNumber: sendForm.to, message: sendForm.message } }, {
      onSuccess: (res) => { setSendOpen(null); toast({ title: res.success ? "SMS sent" : "Send failed", description: res.message, variant: res.success ? "default" : "destructive" }); },
      onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
    });
  }

  function handleDelete(id: number) {
    if (!confirm("Delete this SMS config?")) return;
    deleteConfig.mutate({ id }, { onSuccess: () => { refresh(); toast({ title: "Deleted" }); } });
  }

  const statusColors: Record<string, string> = {
    verified: "bg-green-500/15 text-green-400 border border-green-500/30",
    failed: "bg-red-500/15 text-red-400 border border-red-500/30",
    untested: "bg-yellow-500/15 text-yellow-400 border border-yellow-500/30",
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">SMS</h2>
          <p className="text-sm text-muted-foreground mt-1">{configs?.length ?? 0} configured — Twilio, AWS SNS, SMTP-to-SMS gateway</p>
        </div>
        <Button onClick={openCreate}>Add SMS Config</Button>
      </div>

      <div className="bg-card border border-border rounded-lg overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-muted-foreground">Loading...</div>
        ) : configs && configs.length > 0 ? (
          <table className="w-full text-sm">
            <thead className="border-b border-border bg-muted/30">
              <tr>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">Label</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">Provider</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">From / Gateway</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">Status</th>
                <th className="text-right px-4 py-3 text-muted-foreground font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {configs.map((cfg) => (
                <tr key={cfg.id} className="border-b border-border/50 last:border-0 hover:bg-muted/20">
                  <td className="px-4 py-3 font-medium text-foreground">{cfg.label || cfg.provider}</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2 py-0.5 rounded font-medium uppercase ${cfg.provider === "smtp_sms" ? "bg-indigo-500/15 text-indigo-400" : "bg-muted text-foreground"}`}>
                      {cfg.provider === "smtp_sms" ? "SMTP→SMS" : cfg.provider}
                    </span>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-muted-foreground">
                    {cfg.provider === "smtp_sms" ? (cfg.gatewayDomain || "-") : (cfg.fromNumber || "-")}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColors[cfg.status ?? "untested"] ?? statusColors.untested}`}>
                      {cfg.status ?? "untested"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex gap-2 justify-end">
                      <Button size="sm" variant="outline" onClick={() => setTestOpen(cfg.id)} className="text-xs">Test</Button>
                      <Button size="sm" variant="outline" onClick={() => setSendOpen(cfg.id)} className="text-xs">Send</Button>
                      <Button size="sm" variant="outline" onClick={() => openEdit(cfg)} className="text-xs">Edit</Button>
                      <Button size="sm" variant="destructive" onClick={() => handleDelete(cfg.id)} className="text-xs">Delete</Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="p-12 text-center text-muted-foreground">
            <p className="text-base font-medium">No SMS configs</p>
            <p className="text-sm mt-1">Add Twilio, AWS SNS, or an SMTP-to-SMS gateway to send SMS</p>
          </div>
        )}
      </div>

      {/* ─── Add Config Dialog ───────────────────────────────── */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="bg-card border-border max-w-lg">
          <DialogHeader><DialogTitle>{editId ? "Edit SMS Config" : "Add SMS Config"}</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div><Label>Label (optional)</Label><Input className="mt-1" value={form.label} onChange={e => setForm(f => ({ ...f, label: e.target.value }))} /></div>

            <div><Label>Provider *</Label>
              <Select value={form.provider} onValueChange={v => setForm(f => ({ ...f, provider: v }))}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="twilio">Twilio</SelectItem>
                  <SelectItem value="aws_sns">AWS SNS</SelectItem>
                  <SelectItem value="smtp_sms">SMTP-to-SMS (carrier gateway)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {form.provider === "twilio" && (
              <>
                <div><Label>Account SID *</Label><Input className="mt-1 font-mono text-sm" value={form.accountSid} onChange={e => setForm(f => ({ ...f, accountSid: e.target.value }))} placeholder="ACxxxxxxxxxxxxxxxxxx" /></div>
                <div>
                  <Label>Auth Token (optional)</Label>
                  <Input className="mt-1 font-mono text-sm" type="password" value={form.authToken} onChange={e => setForm(f => ({ ...f, authToken: e.target.value }))} />
                  <p className="text-xs text-muted-foreground mt-1">You can save the Account SID first and add the Auth Token later to verify and send.</p>
                </div>
                <div>
                  <Label>From Number (optional)</Label>
                  <Input className="mt-1" value={form.fromNumber} onChange={e => setForm(f => ({ ...f, fromNumber: e.target.value }))} placeholder="Auto-select an owned Twilio number" />
                  <p className="text-xs text-muted-foreground mt-1">If left blank, the first owned number or verified caller ID is selected automatically after verification.</p>
                </div>
                <div className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg border border-border">
                  <Switch checked={form.autoVerify} onCheckedChange={v => setForm(f => ({ ...f, autoVerify: v }))} />
                  <div>
                    <Label className="text-sm font-medium">Auto-verify after saving</Label>
                    <p className="text-xs text-muted-foreground">Send a test SMS immediately to confirm the config works</p>
                  </div>
                </div>
              </>
            )}

            {form.provider === "aws_sns" && (
              <>
                <div><Label>AWS Config *</Label>
                  <Select value={form.awsConfigId} onValueChange={v => setForm(f => ({ ...f, awsConfigId: v }))}>
                    <SelectTrigger className="mt-1"><SelectValue placeholder="Select AWS config" /></SelectTrigger>
                    <SelectContent>{(awsConfigs || []).map(a => <SelectItem key={a.id} value={String(a.id)}>{a.label || a.region}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg border border-border">
                  <Switch checked={form.autoVerify} onCheckedChange={v => setForm(f => ({ ...f, autoVerify: v }))} />
                  <div>
                    <Label className="text-sm font-medium">Auto-verify after saving</Label>
                    <p className="text-xs text-muted-foreground">Send a test SMS immediately to confirm the config works</p>
                  </div>
                </div>
              </>
            )}

            {form.provider === "smtp_sms" && (
              <>
                <div>
                  <Label>SMTP Server *</Label>
                  <p className="text-xs text-muted-foreground mb-1">Select a verified SMTP to send the gateway emails through</p>
                  <Select value={form.smtpId} onValueChange={v => setForm(f => ({ ...f, smtpId: v }))}>
                    <SelectTrigger className="mt-1"><SelectValue placeholder="Select SMTP" /></SelectTrigger>
                    <SelectContent>
                      {(smtps || []).map(s => (
                        <SelectItem key={s.id} value={String(s.id)}>
                          {s.label || s.host} — {s.user} ({s.status})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Carrier Gateway *</Label>
                  <p className="text-xs text-muted-foreground mb-1">Numbers are sent to <code className="text-foreground">{"<number>@<gateway>"}</code> as email</p>
                  <Select value={form.gatewayDomain} onValueChange={v => setForm(f => ({ ...f, gatewayDomain: v }))}>
                    <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {CARRIER_GATEWAYS.map(g => (
                        <SelectItem key={g.domain} value={g.domain}>{g.label}{g.domain !== "auto" ? ` — ${g.domain}` : ""}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {form.gatewayDomain !== "auto" && (
                    <Input className="mt-2 font-mono text-xs" value={form.gatewayDomain} onChange={e => setForm(f => ({ ...f, gatewayDomain: e.target.value }))} placeholder="custom.gateway.com" />
                  )}
                </div>
                <div className={`text-xs text-muted-foreground rounded-lg p-3 border ${form.gatewayDomain === "auto" ? "bg-blue-500/5 border-blue-500/20" : "bg-indigo-500/5 border-indigo-500/20"}`}>
                  {form.gatewayDomain === "auto" ? (
                    <>
                      <p className="font-medium text-blue-400 mb-1">🔍 Auto-detect mode</p>
                      <p>Each phone number's area code is looked up in a built-in US carrier table (AT&T, Verizon, T-Mobile, Sprint) covering 300+ area codes. The right gateway is selected per number automatically — no manual carrier guessing needed.</p>
                      <p className="mt-1 text-muted-foreground/70">Unrecognized area codes fall back to AT&T gateway.</p>
                    </>
                  ) : (
                    <>
                      <p className="font-medium text-indigo-400 mb-1">How SMTP-to-SMS works</p>
                      <p>Each phone number in your lead list gets formatted as <strong>{form.gatewayDomain ? `1234567890@${form.gatewayDomain}` : "number@gateway.com"}</strong> and sent as an email via your SMTP server. The carrier delivers it as an SMS — no Twilio fees.</p>
                    </>
                  )}
                </div>
              </>
            )}

            <Button className="w-full" onClick={handleAdd} disabled={createConfig.isPending || updateConfig.isPending}>
              {createConfig.isPending || updateConfig.isPending ? "Saving..." : editId ? "Save & Verify" : "Add Config"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* ─── Auto-Verify Dialog ──────────────────────────────── */}
      <Dialog open={autoVerifyId !== null} onOpenChange={() => { setAutoVerifyId(null); setAutoVerifyPhone(""); }}>
        <DialogContent className="bg-card border-border">
          <DialogHeader><DialogTitle>Auto-Verify — Send Test SMS</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <p className="text-sm text-muted-foreground">Enter a phone number to send a test SMS and auto-verify this config.</p>
            <div><Label>Your phone number *</Label><Input className="mt-1" value={autoVerifyPhone} onChange={e => setAutoVerifyPhone(e.target.value)} placeholder="+15005550006" /></div>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => { setAutoVerifyId(null); setAutoVerifyPhone(""); }}>Skip</Button>
              <Button className="flex-1" onClick={handleAutoVerify} disabled={!autoVerifyPhone || testing !== null}>
                {testing !== null ? "Sending..." : "Send & Verify"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ─── Test Dialog ────────────────────────────────────── */}
      <Dialog open={testOpen !== null} onOpenChange={() => setTestOpen(null)}>
        <DialogContent className="bg-card border-border">
          <DialogHeader><DialogTitle>Test SMS Config</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <div><Label>Phone Number *</Label><Input className="mt-1" value={testPhone} onChange={e => setTestPhone(e.target.value)} placeholder="+15005550006" /></div>
            <Button className="w-full" onClick={handleTest} disabled={!testPhone || testing !== null}>{testing !== null ? "Sending..." : "Send Test SMS"}</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* ─── Send Dialog ────────────────────────────────────── */}
      <Dialog open={sendOpen !== null} onOpenChange={() => setSendOpen(null)}>
        <DialogContent className="bg-card border-border">
          <DialogHeader><DialogTitle>Send SMS</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <div><Label>To Number *</Label><Input className="mt-1" value={sendForm.to} onChange={e => setSendForm(f => ({ ...f, to: e.target.value }))} placeholder="+15005550006" /></div>
            <div><Label>Message</Label><Textarea className="mt-1" value={sendForm.message} onChange={e => setSendForm(f => ({ ...f, message: e.target.value }))} rows={3} /></div>
            <Button className="w-full" onClick={handleSend} disabled={sendSms.isPending || !sendForm.to}>{sendSms.isPending ? "Sending..." : "Send SMS"}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
