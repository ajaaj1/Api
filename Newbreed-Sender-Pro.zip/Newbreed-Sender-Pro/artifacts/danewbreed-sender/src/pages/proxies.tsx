import { useState, useRef } from "react";
import { useListProxies, useImportProxies, useDeleteProxy, useTestProxy, getListProxiesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";

type ProxyTestResult = { id: number; host: string; port: number; success: boolean; ms?: number; error?: string };
type ProxyJob = { total: number; done: boolean; passed: number; failed: number; results: ProxyTestResult[]; fatalError?: string };

export default function ProxiesManager() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: proxies, isLoading } = useListProxies();
  const importProxies = useImportProxies();
  const deleteProxy = useDeleteProxy();
  const testProxy = useTestProxy();

  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const importFileRef = useRef<HTMLInputElement>(null);

  const [importOpen, setImportOpen] = useState(false);
  const [importRaw, setImportRaw] = useState("");
  const [importProgress, setImportProgress] = useState<{ current: number; total: number; imported: number; failed: number } | null>(null);
  const [testing, setTesting] = useState<number | null>(null);
  const [testAllOpen, setTestAllOpen] = useState(false);
  const [testingAll, setTestingAll] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [job, setJob] = useState<ProxyJob | null>(null);

  const refresh = () => qc.invalidateQueries({ queryKey: getListProxiesQueryKey() });

  function stopPolling() {
    if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null; }
  }

  async function handleImport() {
    const rows = importRaw.replace(/^\uFEFF/, "").split(/\r?\n/).filter(line => line.trim());
    if (rows.length === 0 || importProgress) return;

    const CHUNK_SIZE = 500;
    const totalChunks = Math.ceil(rows.length / CHUNK_SIZE);
    let imported = 0;
    let failed = 0;
    const errors: string[] = [];
    setImportProgress({ current: 0, total: totalChunks, imported: 0, failed: 0 });

    for (let index = 0; index < totalChunks; index++) {
      const chunk = rows.slice(index * CHUNK_SIZE, (index + 1) * CHUNK_SIZE);
      try {
        const result = await importProxies.mutateAsync({ data: { raw: chunk.join("\n") } });
        imported += result.imported;
        failed += result.failed;
        for (const error of result.errors ?? []) {
          if (errors.length < 12) errors.push(`Batch ${index + 1}: ${error}`);
        }
      } catch (error) {
        const data = (error as { data?: { imported?: number; failed?: number; total?: number; errors?: string[] } })?.data;
        const batchImported = Number(data?.imported) || 0;
        const batchTotal = Number(data?.total);
        const batchFailed = Number.isFinite(data?.failed)
          ? Number(data?.failed)
          : Math.max(0, chunk.length - batchImported);
        imported += batchImported;
        failed += batchFailed + (Number.isFinite(batchTotal) ? Math.max(0, chunk.length - batchTotal) : 0);
        failed += Math.max(0, rows.length - (index + 1) * CHUNK_SIZE);
        const message = error instanceof Error ? error.message : "The server could not process this upload.";
        if (errors.length < 12) errors.push(`Batch ${index + 1}: ${message}`);
        for (const detail of data?.errors ?? []) {
          if (errors.length < 12) errors.push(`Batch ${index + 1}: ${detail}`);
        }
        break;
      }
      setImportProgress({ current: index + 1, total: totalChunks, imported, failed });
    }

    setImportProgress(null);
    refresh();
    if (failed === 0) {
      setImportOpen(false);
      setImportRaw("");
    }
    toast({
      title: failed > 0 ? `Imported ${imported} proxies; ${failed} rows failed` : `Imported ${imported} proxies`,
      description: errors.length
        ? `${errors.slice(0, 3).join(" ")} The import text is still available so you can correct and retry it.`
        : undefined,
      variant: failed > 0 ? "destructive" : "default",
    });
  }

  function handleImportFileRead(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const input = e.currentTarget;
    const reader = new FileReader();
    reader.onload = (event) => {
      input.value = "";
      const raw = event.target?.result as string ?? "";
      if (!raw.trim()) {
        toast({ title: "The selected file is empty", description: file.name, variant: "destructive" });
        return;
      }
      setImportRaw(raw);
      setImportOpen(true);
      toast({ title: `File loaded: ${file.name}`, description: "Review the contents, then choose Import Proxies." });
    };
    reader.onerror = () => {
      input.value = "";
      toast({ title: "Could not read this file", description: file.name, variant: "destructive" });
    };
    reader.readAsText(file);
  }

  function handleTest(id: number) {
    setTesting(id);
    testProxy.mutate({ id }, {
      onSuccess: (res) => {
        refresh();
        setTesting(null);
        toast({ title: res.success ? "Proxy reachable" : "Proxy unreachable", description: res.message, variant: res.success ? "default" : "destructive" });
      },
      onError: (e: any) => { setTesting(null); toast({ title: "Error", description: e.message, variant: "destructive" }); },
    });
  }

  function handleDelete(id: number) {
    if (!confirm("Delete this proxy?")) return;
    deleteProxy.mutate({ id }, { onSuccess: () => { refresh(); toast({ title: "Deleted" }); } });
  }

  async function handleDeleteFailed() {
    const count = failedCount;
    if (count === 0) {
      toast({ title: "No failed proxies to delete" });
      return;
    }
    if (!confirm(`Permanently delete ${count} failed proxy/proxies? This cannot be undone.`)) return;
    setDeleting(true);
    try {
      const res = await fetch("/api/proxies/clear-failed", { method: "DELETE" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const { deleted } = await res.json();
      setJob(null);
      refresh();
      toast({ title: `Deleted ${deleted} failed proxies` });
    } catch (e: any) {
      toast({ title: "Delete error", description: e.message, variant: "destructive" });
    }
    setDeleting(false);
  }

  async function handleTestAll(retryIds?: number[]) {
    stopPolling();
    setTestingAll(true);
    setJob(null);

    try {
      const startRes = await fetch("/api/proxies/test-all", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(retryIds ? { ids: retryIds } : {}),
      });

      if (!startRes.ok) {
        const errText = await startRes.text();
        throw new Error(errText || `HTTP ${startRes.status}`);
      }

      const { jobId } = await startRes.json();
      setJob({ total: -1, done: false, passed: 0, failed: 0, results: [] });

      pollRef.current = setInterval(async () => {
        try {
          const pollRes = await fetch(`/api/proxies/test-all/job/${jobId}`);
          if (!pollRes.ok) return;
          const state: ProxyJob = await pollRes.json();
          setJob({ ...state });

          if (state.fatalError) {
            stopPolling();
            setTestingAll(false);
            toast({ title: "Test error", description: state.fatalError, variant: "destructive" });
            return;
          }

          if (state.done) {
            stopPolling();
            setTestingAll(false);
            refresh();
            toast({
              title: `Test complete: ${state.passed}/${state.total} reachable`,
              description: state.failed > 0 ? `${state.failed} unreachable` : "All proxies reachable!",
            });
          }
        } catch {}
      }, 1500);
    } catch (e: any) {
      stopPolling();
      setTestingAll(false);
      toast({ title: "Test error", description: e.message, variant: "destructive" });
    }
  }

  const activeCount = proxies?.filter(p => p.status === "active").length ?? 0;
  const failedCount = proxies?.filter(p => p.status === "failed").length ?? 0;
  const total = proxies?.length ?? 0;
  const progressPct = job && job.total > 0 ? Math.round((job.results.length / job.total) * 100) : 0;
  const failedResults = job?.results.filter(r => !r.success) ?? [];

  const IMPORT_HINT = `Supported formats:\n• host:port:user:pass\n• host:port (no auth)\n• socks5://user:pass@host:port\n• http://user:pass@host:port`;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">Proxies</h2>
          <p className="text-sm text-muted-foreground mt-1">
            {total} total
            {activeCount > 0 && <span className="ml-2 text-green-400">{activeCount} active</span>}
            {failedCount > 0 && <span className="ml-2 text-red-400">{failedCount} failed</span>}
            <span className="ml-2 text-muted-foreground">— used for IP rotation in campaigns</span>
          </p>
        </div>
        <div className="flex gap-2">
          {total > 0 && (
            <Button variant="outline" onClick={() => { setJob(null); setTestAllOpen(true); }} className="text-xs">
              Test All ({total})
            </Button>
          )}
          {failedCount > 0 && (
            <Button
              variant="outline"
              onClick={handleDeleteFailed}
              disabled={deleting || testingAll}
              className="text-xs text-red-400 border-red-500/40 hover:bg-red-500/10"
            >
              {deleting ? "Deleting…" : `Delete Failed (${failedCount})`}
            </Button>
          )}
          <Button onClick={() => setImportOpen(true)}>Import Proxies</Button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="bg-card border border-border rounded-lg p-4">
          <p className="text-xs text-muted-foreground uppercase tracking-wide">Total</p>
          <p className="text-3xl font-bold text-foreground mt-1">{total.toLocaleString()}</p>
        </div>
        <div className="bg-card border border-border rounded-lg p-4">
          <p className="text-xs text-muted-foreground uppercase tracking-wide">Active</p>
          <p className="text-3xl font-bold text-green-400 mt-1">{activeCount.toLocaleString()}</p>
        </div>
        <div className="bg-card border border-border rounded-lg p-4">
          <p className="text-xs text-muted-foreground uppercase tracking-wide">Failed</p>
          <p className="text-3xl font-bold text-red-400 mt-1">{failedCount.toLocaleString()}</p>
        </div>
      </div>

      <div className="bg-card border border-border rounded-lg overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-muted-foreground">Loading...</div>
        ) : proxies && proxies.length > 0 ? (
          <table className="w-full text-sm">
            <thead className="border-b border-border bg-muted/30">
              <tr>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">Host</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">Port</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">Type</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">Auth</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">Status</th>
                <th className="text-right px-4 py-3 text-muted-foreground font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {proxies.map((proxy) => (
                <tr key={proxy.id} className="border-b border-border/50 last:border-0 hover:bg-muted/20">
                  <td className="px-4 py-2.5 font-mono text-xs text-foreground">{proxy.host}</td>
                  <td className="px-4 py-2.5 text-muted-foreground">{proxy.port}</td>
                  <td className="px-4 py-2.5"><span className="text-xs bg-muted px-2 py-0.5 rounded font-medium text-foreground uppercase">{proxy.protocol || "http"}</span></td>
                  <td className="px-4 py-2.5 text-muted-foreground text-xs">{proxy.username ? `${proxy.username}:***` : "None"}</td>
                  <td className="px-4 py-2.5">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium status-badge-${proxy.status ?? "untested"}`}>{proxy.status ?? "untested"}</span>
                  </td>
                  <td className="px-4 py-2.5 text-right">
                    <div className="flex gap-2 justify-end">
                      <Button size="sm" variant="outline" onClick={() => handleTest(proxy.id)} disabled={testing === proxy.id} className="text-xs">
                        {testing === proxy.id ? "Testing..." : "Test"}
                      </Button>
                      <Button size="sm" variant="destructive" onClick={() => handleDelete(proxy.id)} className="text-xs">Delete</Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="p-12 text-center text-muted-foreground">
            <p className="text-base font-medium">No proxies</p>
            <p className="text-sm mt-1">Import proxies to enable IP rotation for campaigns</p>
          </div>
        )}
      </div>

      {/* Import Dialog */}
      <Dialog open={importOpen} onOpenChange={setImportOpen}>
        <DialogContent className="bg-card border-border max-w-2xl">
          <DialogHeader><DialogTitle>Import Proxies</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <p className="text-xs text-muted-foreground whitespace-pre-line bg-muted/30 rounded p-2">{IMPORT_HINT}</p>
            <input ref={importFileRef} type="file" accept=".txt,.csv,.conf,.text" className="hidden" onChange={handleImportFileRead} />
            <Button variant="outline" className="w-full" onClick={() => importFileRef.current?.click()} disabled={importProxies.isPending}>
              Choose Proxy File
            </Button>
            <Textarea
              className="font-mono text-xs h-48 resize-none"
              value={importRaw}
              onChange={e => setImportRaw(e.target.value)}
              placeholder="192.168.1.1:8080:user:pass&#10;10.0.0.1:3128&#10;socks5://user:pass@proxy.example.com:1080"
            />
            {importProgress && (
              <p className="text-xs text-muted-foreground">
                Batch {importProgress.current}/{importProgress.total} — {importProgress.imported.toLocaleString()} imported, {importProgress.failed.toLocaleString()} failed
              </p>
            )}
            <Button className="w-full" onClick={handleImport} disabled={!!importProgress || importProxies.isPending || !importRaw.trim()}>
              {importProgress ? `Importing ${importProgress.current}/${importProgress.total}...` : importProxies.isPending ? "Importing..." : "Import Proxies"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Test All Dialog */}
      <Dialog
        open={testAllOpen}
        onOpenChange={v => {
          if (!v && testingAll) return;
          setTestAllOpen(v);
          if (!v) { stopPolling(); setJob(null); }
        }}
      >
        <DialogContent className="bg-card border-border max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Test All Proxies ({total})</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <p className="text-xs text-muted-foreground">
              Tests TCP connectivity to each proxy host:port in batches of 10 simultaneously. Status is updated to Active or Failed in real time.
            </p>

            <div className="flex gap-2 flex-wrap">
              <Button
                onClick={() => handleTestAll()}
                disabled={testingAll}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                {testingAll ? "Testing…" : "Start Test"}
              </Button>
              {job?.done && failedResults.length > 0 && (
                <Button
                  variant="outline"
                  onClick={() => handleTestAll(failedResults.map(r => r.id))}
                  disabled={testingAll}
                  className="text-orange-400 border-orange-500/40 hover:bg-orange-500/10"
                >
                  Retry Failed ({failedResults.length})
                </Button>
              )}
            </div>

            {/* Progress while running */}
            {job && !job.done && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  {job.total < 0
                    ? <span>Initializing… <span className="animate-pulse">●</span></span>
                    : <span>Testing {job.results.length} / {job.total}… <span className="animate-pulse">●</span></span>
                  }
                  {job.total > 0 && <span className="font-mono font-medium">{progressPct}%</span>}
                </div>
                <div className="h-2.5 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-green-500 rounded-full transition-all duration-700"
                    style={{ width: `${progressPct}%` }}
                  />
                </div>
                <div className="flex gap-4 text-xs">
                  <span className="text-green-400 font-medium">✓ {job.passed} reachable</span>
                  <span className="text-red-400 font-medium">✗ {job.failed} failed</span>
                  {job.total > 0 && <span className="text-muted-foreground">{job.total - job.results.length} remaining</span>}
                </div>
              </div>
            )}

            {/* Summary cards + actions once done */}
            {job?.done && (
              <div className="space-y-3">
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-muted/30 rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-foreground">{job.total}</div>
                    <div className="text-xs text-muted-foreground mt-1">Tested</div>
                  </div>
                  <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-green-400">{job.passed}</div>
                    <div className="text-xs text-muted-foreground mt-1">Reachable</div>
                  </div>
                  <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-red-400">{job.failed}</div>
                    <div className="text-xs text-muted-foreground mt-1">Failed</div>
                  </div>
                </div>
                {job.failed > 0 && (
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      onClick={() => handleTestAll(failedResults.map(r => r.id))}
                      disabled={testingAll || deleting}
                      className="flex-1 text-orange-400 border-orange-500/40 hover:bg-orange-500/10"
                    >
                      Retry Failed ({job.failed})
                    </Button>
                    <Button
                      variant="outline"
                      onClick={handleDeleteFailed}
                      disabled={testingAll || deleting}
                      className="flex-1 text-red-400 border-red-500/40 hover:bg-red-500/10"
                    >
                      {deleting ? "Deleting…" : `Delete Failed (${job.failed})`}
                    </Button>
                  </div>
                )}
              </div>
            )}

            {/* Live results table */}
            {job && job.results.length > 0 && (
              <div className="border border-border rounded-lg overflow-hidden">
                <div className="max-h-64 overflow-y-auto">
                  <table className="w-full text-xs">
                    <thead className="bg-muted/30 border-b border-border sticky top-0">
                      <tr>
                        <th className="text-left px-3 py-2 text-muted-foreground font-medium">Host</th>
                        <th className="text-left px-3 py-2 text-muted-foreground font-medium">Port</th>
                        <th className="text-left px-3 py-2 text-muted-foreground font-medium">Latency</th>
                        <th className="text-left px-3 py-2 text-muted-foreground font-medium">Result</th>
                      </tr>
                    </thead>
                    <tbody>
                      {job.results.map((r) => (
                        <tr key={r.id} className="border-b border-border/50 last:border-0">
                          <td className="px-3 py-2 text-foreground font-mono">{r.host}</td>
                          <td className="px-3 py-2 text-muted-foreground">{r.port}</td>
                          <td className="px-3 py-2 text-muted-foreground">{r.ms != null ? `${r.ms}ms` : "—"}</td>
                          <td className="px-3 py-2">
                            {r.success
                              ? <span className="text-green-400 font-medium">✓ Reachable</span>
                              : <span className="text-red-400" title={r.error}>✗ Failed</span>
                            }
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
