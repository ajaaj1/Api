import Campaigns from "@/pages/campaigns";

export default function SmsCampaigns() {
  return <Campaigns mode="sms" />;
}