import { useState } from "react";
import { CheckCircle2, CircleAlert, KeyRound, Mail, Pencil, Plus, Send, ShieldCheck, Trash2 } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import {
  getListResendConfigsQueryKey,
  useCreateResendConfig,
  useDeleteResendConfig,
  useListResendConfigs,
  useSendResendEmail,
  useUpdateResendConfig,
  useVerifyResendConfig,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

type ConfigForm = { label: string; domain: string; fromEmail: string; fromName: string; apiKey: string };
type EmailForm = { to: string; subject: string; body: string; isHtml: boolean };
const emptyConfig: ConfigForm = { label: "", domain: "", fromEmail: "", fromName: "Danewbreed Sender Pro", apiKey: "" };
const emptyEmail: EmailForm = { to: "", subject: "A delivery check from Danewbreed", body: "This is a delivery check from Danewbreed Sender Pro.", isHtml: false };

export default function ResendManager() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: configs, isLoading, isError, refetch } = useListResendConfigs();
  const createConfig = useCreateResendConfig();
  const updateConfig = useUpdateResendConfig();
  const deleteConfig = useDeleteResendConfig();
  const verifyConfig = useVerifyResendConfig();
  const sendEmail = useSendResendEmail();
  const [configOpen, setConfigOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [configForm, setConfigForm] = useState<ConfigForm>(emptyConfig);
  const [testId, setTestId] = useState<number | null>(null);
  const [testForm, setTestForm] = useState<EmailForm>(emptyEmail);
  const [verifyId, setVerifyId] = useState<number | null>(null);
  const [verifyTo, setVerifyTo] = useState("");
  const [lastResult, setLastResult] = useState<{ title: string; message: string; id?: string | null; ok: boolean } | null>(null);

  const refresh = () => qc.invalidateQueries({ queryKey: getListResendConfigsQueryKey() });
  const setConfig = (key: keyof ConfigForm, value: string) => setConfigForm((current) => ({ ...current, [key]: value }));

  function openCreate() {
    setEditingId(null);
    setConfigForm(emptyConfig);
    setConfigOpen(true);
  }

  function openEdit(config: any) {
    setEditingId(config.id);
    setConfigForm({ label: config.label ?? "", domain: config.domain ?? "", fromEmail: config.fromEmail ?? "", fromName: config.fromName ?? "", apiKey: "" });
    setConfigOpen(true);
  }

  function saveConfig() {
    if (!configForm.domain.trim() || !configForm.fromEmail.trim()) {
      toast({ title: "Domain and sender email are required", variant: "destructive" });
      return;
    }
    const data = {
      label: configForm.label || undefined,
      domain: configForm.domain,
      fromEmail: configForm.fromEmail,
      fromName: configForm.fromName || undefined,
      ...(configForm.apiKey ? { apiKey: configForm.apiKey } : {}),
    };
    const onSuccess = (result: any) => {
      refresh();
      setConfigOpen(false);
      const verification = result?.verification;
      toast({
        title: verification?.senderVerified ? "Resend API key and domain verified" : "Resend sender saved",
        description: verification?.message,
        variant: verification?.success && verification?.senderVerified ? "default" : "destructive",
      });
    };
    const onError = (error: any) => toast({ title: "Could not save sender", description: error.message, variant: "destructive" });
    if (editingId) updateConfig.mutate({ id: editingId, data }, { onSuccess, onError });
    else createConfig.mutate({ data: { ...data, apiKey: configForm.apiKey } }, { onSuccess, onError });
  }

  function removeConfig(id: number) {
    if (!confirm("Delete this Resend sender?")) return;
    deleteConfig.mutate({ id }, { onSuccess: () => { refresh(); toast({ title: "Resend sender deleted" }); }, onError: (error: any) => toast({ title: "Could not delete sender", description: error.message, variant: "destructive" }) });
  }

  function verify() {
    if (!verifyId || !verifyTo.trim()) return;
    verifyConfig.mutate({ id: verifyId, data: { to: verifyTo } }, {
      onSuccess: (result) => {
        const response = result as any;
        setLastResult({ title: response.success ? "Verification accepted" : "Verification failed", message: response.message, id: response.messageId, ok: response.success });
        setVerifyId(null);
        setVerifyTo("");
        refresh();
      },
      onError: (error: any) => setLastResult({ title: "Verification failed", message: error.message, ok: false }),
    });
  }

  function sendTest() {
    if (!testId || !testForm.to.trim()) return;
    sendEmail.mutate({ id: testId, data: testForm }, {
      onSuccess: (result) => {
        const response = result as any;
        setLastResult({ title: response.success ? "Test email sent" : "Test email failed", message: response.message, id: response.messageId, ok: response.success });
        setTestId(null);
        refresh();
      },
      onError: (error: any) => setLastResult({ title: "Send failed", message: error.message, ok: false }),
    });
  }

  return (
    <div className="mx-auto max-w-6xl space-y-7" data-testid="page-resend">
      <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <div className="mb-3 flex items-center gap-2 text-xs font-medium uppercase tracking-[0.18em] text-primary">
            <span className="h-2 w-2 rounded-full bg-primary" /> Provider control
          </div>
          <h2 className="text-3xl font-semibold tracking-tight">Resend senders</h2>
          <p className="mt-2 max-w-xl text-sm leading-6 text-muted-foreground">Connect a verified sending domain, then prove the route with a real test email before it reaches a campaign.</p>
        </div>
        <Button onClick={openCreate} data-testid="button-add-resend"><Plus className="mr-2 h-4 w-4" /> Add Resend sender</Button>
      </div>

      <div className="grid gap-3 md:grid-cols-3">
        <div className="rounded-xl border border-border bg-card p-4"><div className="text-xs uppercase tracking-wider text-muted-foreground">Configured</div><div className="mt-2 text-2xl font-semibold" data-testid="text-resend-count">{configs?.length ?? 0}</div></div>
        <div className="rounded-xl border border-border bg-card p-4"><div className="text-xs uppercase tracking-wider text-muted-foreground">Verified</div><div className="mt-2 text-2xl font-semibold text-primary">{configs?.filter((config) => config.status === "verified").length ?? 0}</div></div>
        <div className="rounded-xl border border-border bg-[#f4ead3] p-4 text-[#5f4930]"><div className="text-xs uppercase tracking-wider opacity-70">Route rule</div><div className="mt-2 text-sm font-medium">Use only after the sender test passes.</div></div>
      </div>

      {lastResult && (
        <div className={`flex items-start gap-3 rounded-xl border p-4 ${lastResult.ok ? "border-primary/30 bg-primary/5" : "border-destructive/30 bg-destructive/5"}`} data-testid="status-resend-result">
          {lastResult.ok ? <CheckCircle2 className="mt-0.5 h-5 w-5 text-primary" /> : <CircleAlert className="mt-0.5 h-5 w-5 text-destructive" />}
          <div className="min-w-0 flex-1"><div className="font-medium">{lastResult.title}</div><div className="mt-1 text-sm text-muted-foreground">{lastResult.message}</div>{lastResult.id && <div className="mt-2 break-all font-mono text-xs text-primary">Provider ID: {lastResult.id}</div>}</div>
          <button className="text-xs text-muted-foreground underline" onClick={() => setLastResult(null)} data-testid="button-dismiss-resend-result">Dismiss</button>
        </div>
      )}

      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        <div className="flex items-center gap-3 border-b border-border bg-muted/40 px-5 py-4"><ShieldCheck className="h-5 w-5 text-primary" /><div><div className="font-medium">Sender identities</div><div className="text-xs text-muted-foreground">Domain and from address are kept together for predictable routing.</div></div></div>
        {isLoading ? <div className="space-y-3 p-5"><div className="h-12 animate-pulse rounded-lg bg-muted" /><div className="h-12 animate-pulse rounded-lg bg-muted" /></div>
          : isError ? <div className="p-10 text-center"><CircleAlert className="mx-auto h-8 w-8 text-destructive" /><p className="mt-3 font-medium">Could not load Resend senders</p><Button variant="outline" className="mt-4" onClick={() => refetch()} data-testid="button-retry-resend">Retry</Button></div>
          : configs && configs.length > 0 ? <div className="divide-y divide-border">{configs.map((config) => (
            <div className="flex flex-col gap-4 px-5 py-5 md:flex-row md:items-center md:justify-between" key={config.id} data-testid={`row-resend-${config.id}`}>
             <div className="flex min-w-0 items-start gap-4"><div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary"><Mail className="h-5 w-5" /></div><div className="min-w-0"><div className="font-medium">{config.label || config.fromEmail}</div><div className="mt-1 truncate font-mono text-xs text-muted-foreground">{config.fromEmail} · {config.domain}</div><div className="mt-2 flex flex-wrap items-center gap-2"><span className={`inline-flex rounded-full border px-2 py-0.5 text-xs font-medium ${config.status === "verified" ? "status-badge-verified" : "status-badge-untested"}`} data-testid={`status-resend-${config.id}`}>{config.status ?? "untested"}</span><span className="text-xs text-muted-foreground">{config.apiKeyConfigured ? "API key configured" : "Managed connection"}</span></div></div></div>
              <div className="flex flex-wrap gap-2 md:justify-end"><Button size="sm" variant="outline" onClick={() => setVerifyId(config.id)} data-testid={`button-verify-resend-${config.id}`}><ShieldCheck className="mr-1.5 h-3.5 w-3.5" /> Verify</Button><Button size="sm" variant="outline" onClick={() => { setTestId(config.id); setTestForm(emptyEmail); }} data-testid={`button-test-resend-${config.id}`}><Send className="mr-1.5 h-3.5 w-3.5" /> Send test</Button><Button size="sm" variant="ghost" onClick={() => openEdit(config)} data-testid={`button-edit-resend-${config.id}`}><Pencil className="mr-1.5 h-3.5 w-3.5" /> Edit</Button><Button size="sm" variant="ghost" className="text-destructive hover:text-destructive" onClick={() => removeConfig(config.id)} data-testid={`button-delete-resend-${config.id}`}><Trash2 className="h-3.5 w-3.5" /></Button></div>
            </div>
          ))}</div>
          : <div className="p-12 text-center"><KeyRound className="mx-auto h-8 w-8 text-muted-foreground" /><p className="mt-3 font-medium">No Resend senders yet</p><p className="mt-1 text-sm text-muted-foreground">Add your first domain-backed sender to make Resend available in campaigns.</p><Button className="mt-5" onClick={openCreate} data-testid="button-empty-add-resend">Add sender</Button></div>}
      </div>

       <Dialog open={configOpen} onOpenChange={setConfigOpen}><DialogContent className="max-w-lg"><DialogHeader><DialogTitle>{editingId ? "Edit Resend API sender" : "Add Resend API sender"}</DialogTitle></DialogHeader><div className="space-y-4 pt-2"><div><Label>Label</Label><Input className="mt-1" value={configForm.label} onChange={(event) => setConfig("label", event.target.value)} placeholder="Transactional account" data-testid="input-resend-label" /></div><div><Label>Resend API key *</Label><Input className="mt-1 font-mono text-sm" type="password" value={configForm.apiKey} onChange={(event) => setConfig("apiKey", event.target.value)} placeholder={editingId ? "Leave blank to keep the current key" : "re_..."} data-testid="input-resend-api-key" /><p className="mt-1 text-xs text-muted-foreground">{editingId ? "Enter a new key only when replacing the current key." : "Each sender can use a different Resend API key."}</p></div><div><Label>Sending domain *</Label><Input className="mt-1 font-mono text-sm" value={configForm.domain} onChange={(event) => setConfig("domain", event.target.value)} placeholder="mail.example.com" data-testid="input-resend-domain" /></div><div><Label>From email *</Label><Input className="mt-1" type="email" value={configForm.fromEmail} onChange={(event) => setConfig("fromEmail", event.target.value)} placeholder="hello@mail.example.com" data-testid="input-resend-from-email" /></div><div><Label>From name</Label><Input className="mt-1" value={configForm.fromName} onChange={(event) => setConfig("fromName", event.target.value)} data-testid="input-resend-from-name" /></div><p className="rounded-lg border border-border bg-muted/40 p-3 text-xs leading-5 text-muted-foreground">The API key is encrypted before it is stored. Saving checks domain-list access and the domain’s verification status; it does not send an email. Use the separate delivery test to send a real message.</p><Button className="w-full" onClick={saveConfig} disabled={createConfig.isPending || updateConfig.isPending || (!editingId && !configForm.apiKey.trim())} data-testid="button-save-resend">{createConfig.isPending || updateConfig.isPending ? "Saving sender..." : editingId ? "Save changes" : "Add sender"}</Button></div></DialogContent></Dialog>
      <Dialog open={verifyId !== null} onOpenChange={() => setVerifyId(null)}><DialogContent className="max-w-md"><DialogHeader><DialogTitle>Verify Resend route</DialogTitle></DialogHeader><div className="space-y-4 pt-2"><p className="text-sm leading-6 text-muted-foreground">A real verification email will be delivered through this sender. Use an inbox you can check now.</p><div><Label>Test recipient *</Label><Input className="mt-1" type="email" value={verifyTo} onChange={(event) => setVerifyTo(event.target.value)} placeholder="operator@example.com" data-testid="input-resend-verify-to" /></div><Button className="w-full" onClick={verify} disabled={!verifyTo || verifyConfig.isPending} data-testid="button-submit-resend-verify">{verifyConfig.isPending ? "Verifying route..." : "Send verification email"}</Button></div></DialogContent></Dialog>
      <Dialog open={testId !== null} onOpenChange={() => setTestId(null)}><DialogContent className="max-w-lg"><DialogHeader><DialogTitle>Send a Resend test</DialogTitle></DialogHeader><div className="space-y-4 pt-2"><div><Label>Recipient *</Label><Input className="mt-1" type="email" value={testForm.to} onChange={(event) => setTestForm((form) => ({ ...form, to: event.target.value }))} placeholder="operator@example.com" data-testid="input-resend-test-to" /></div><div><Label>Subject</Label><Input className="mt-1" value={testForm.subject} onChange={(event) => setTestForm((form) => ({ ...form, subject: event.target.value }))} data-testid="input-resend-test-subject" /></div><div><Label>Body</Label><Textarea className="mt-1" rows={5} value={testForm.body} onChange={(event) => setTestForm((form) => ({ ...form, body: event.target.value }))} data-testid="input-resend-test-body" /></div><Button className="w-full" onClick={sendTest} disabled={!testForm.to || sendEmail.isPending} data-testid="button-submit-resend-test">{sendEmail.isPending ? "Sending through Resend..." : "Send test email"}</Button></div></DialogContent></Dialog>
    </div>
  );
}