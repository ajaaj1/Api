import { useState } from "react";
import {
  useListWarmupPlans, useCreateWarmupPlan, useUpdateWarmupPlan, useDeleteWarmupPlan, useGetWarmupHistory,
  getListWarmupPlansQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from "recharts";
import { useListSmtps } from "@workspace/api-client-react";

const PRESETS = [
  { label: "Conservative (30d)", durationDays: 30, startVolume: 25, endVolume: 2000 },
  { label: "Standard (21d)", durationDays: 21, startVolume: 50, endVolume: 3500 },
  { label: "Aggressive (14d)", durationDays: 14, startVolume: 100, endVolume: 5000 },
];

function WarmupProgressBar({ used, limit }: { used: number; limit: number }) {
  const pct = limit > 0 ? Math.min(100, Math.round((used / limit) * 100)) : 0;
  const color = pct >= 100 ? "bg-red-500" : pct >= 80 ? "bg-orange-400" : "bg-blue-500";
  return (
    <div className="w-full">
      <div className="flex justify-between text-xs text-muted-foreground mb-1">
        <span>{used.toLocaleString()} sent today</span>
        <span>{limit.toLocaleString()} limit</span>
      </div>
      <div className="h-2 bg-muted rounded-full overflow-hidden">
        <div className={`h-full ${color} rounded-full transition-all`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

function buildProjection(plan: { startVolume: number; endVolume: number; durationDays: number; startDate: string }) {
  const days: { day: number; limit: number }[] = [];
  for (let i = 1; i <= plan.durationDays; i++) {
    const limit = plan.durationDays <= 1
      ? plan.endVolume
      : Math.round(plan.startVolume + (plan.endVolume - plan.startVolume) * (i - 1) / (plan.durationDays - 1));
    days.push({ day: i, limit });
  }
  return days;
}

export default function WarmupManager() {
  const qc = useQueryClient();
  const { toast } = useToast();

  const { data: plans = [], isLoading } = useListWarmupPlans();
  const { data: smtps = [] } = useListSmtps();
  const createPlan = useCreateWarmupPlan();
  const updatePlan = useUpdateWarmupPlan();
  const deletePlan = useDeleteWarmupPlan();

  const [createOpen, setCreateOpen] = useState(false);
  const [historyPlanId, setHistoryPlanId] = useState<number | null>(null);
  const { data: history = [] } = useGetWarmupHistory(historyPlanId!, { query: { enabled: !!historyPlanId } });

  const [form, setForm] = useState({
    name: "",
    smtpId: "",
    startDate: new Date().toISOString().slice(0, 10),
    durationDays: "30",
    startVolume: "50",
    endVolume: "5000",
  });

  function applyPreset(p: typeof PRESETS[0]) {
    setForm(f => ({ ...f, durationDays: String(p.durationDays), startVolume: String(p.startVolume), endVolume: String(p.endVolume) }));
  }

  function refresh() {
    qc.invalidateQueries({ queryKey: getListWarmupPlansQueryKey() });
  }

  async function handleCreate() {
    if (!form.name.trim()) return toast({ title: "Name required", variant: "destructive" });
    createPlan.mutate({
      data: {
        name: form.name,
        smtpId: form.smtpId ? parseInt(form.smtpId) : undefined,
        startDate: form.startDate,
        durationDays: parseInt(form.durationDays),
        startVolume: parseInt(form.startVolume),
        endVolume: parseInt(form.endVolume),
      }
    }, {
      onSuccess: () => { refresh(); setCreateOpen(false); toast({ title: "Warmup plan created" }); },
      onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
    });
  }

  function handleToggle(plan: any) {
    const newStatus = plan.status === "active" ? "paused" : "active";
    updatePlan.mutate({ id: plan.id, data: { status: newStatus } }, {
      onSuccess: () => { refresh(); toast({ title: `Plan ${newStatus}` }); },
    });
  }

  function handleDelete(id: number) {
    if (!confirm("Delete this warmup plan?")) return;
    deletePlan.mutate({ id }, { onSuccess: () => { refresh(); toast({ title: "Plan deleted" }); } });
  }

  const projection = buildProjection({
    startVolume: parseInt(form.startVolume) || 50,
    endVolume: parseInt(form.endVolume) || 5000,
    durationDays: parseInt(form.durationDays) || 30,
    startDate: form.startDate,
  });

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-xl font-semibold">Sender Warm-up</h2>
          <p className="text-sm text-muted-foreground mt-1">Gradually ramp up daily send volume to build domain/IP reputation and avoid spam filters</p>
        </div>
        <Button onClick={() => setCreateOpen(true)} size="sm">+ New Plan</Button>
      </div>

      {isLoading ? (
        <div className="text-center py-16 text-muted-foreground">Loading...</div>
      ) : plans.length === 0 ? (
        <div className="border border-dashed border-border rounded-lg p-12 text-center">
          <p className="text-muted-foreground text-sm">No warmup plans yet.</p>
          <p className="text-muted-foreground text-xs mt-1">Create a plan to automatically cap and ramp your SMTP send volume per day.</p>
          <Button className="mt-4" size="sm" onClick={() => setCreateOpen(true)}>Create First Plan</Button>
        </div>
      ) : (
        <div className="space-y-4">
          {(plans as any[]).map((plan) => {
            const smtpLabel = smtps.find((s: any) => s.id === plan.smtpId)?.label || (plan.smtpId ? `SMTP #${plan.smtpId}` : "—");
            const totalDays = plan.durationDays;
            const currentDay = plan.currentDay;
            const phasePct = Math.round((currentDay / totalDays) * 100);
            return (
              <div key={plan.id} className={`bg-card border rounded-xl p-5 space-y-4 ${plan.status === "paused" ? "opacity-60" : ""}`}>
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-semibold text-base truncate">{plan.name}</h3>
                      <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${plan.status === "active" ? "bg-green-500/15 text-green-400 border-green-500/30" : "bg-muted text-muted-foreground border-border"}`}>
                        {plan.status}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      SMTP: {smtpLabel} · Day {currentDay} of {totalDays} · {plan.startVolume.toLocaleString()}→{plan.endVolume.toLocaleString()} emails/day
                    </p>
                  </div>
                  <div className="flex gap-2 shrink-0">
                    <Button size="sm" variant="outline" onClick={() => setHistoryPlanId(plan.id === historyPlanId ? null : plan.id)}>
                      {plan.id === historyPlanId ? "Hide" : "History"}
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleToggle(plan)}>
                      {plan.status === "active" ? "Pause" : "Resume"}
                    </Button>
                    <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive" onClick={() => handleDelete(plan.id)}>
                      Delete
                    </Button>
                  </div>
                </div>

                {/* Phase progress */}
                <div>
                  <div className="flex justify-between text-xs text-muted-foreground mb-1">
                    <span>Warmup progress</span>
                    <span>Day {currentDay}/{totalDays} ({phasePct}%)</span>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 rounded-full" style={{ width: `${phasePct}%` }} />
                  </div>
                </div>

                {/* Today's cap */}
                <WarmupProgressBar used={plan.usedToday} limit={plan.dailyLimit} />

                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-background border border-border rounded-lg p-3 text-center">
                    <p className="text-xs text-muted-foreground">Today's Limit</p>
                    <p className="text-xl font-bold text-blue-400">{plan.dailyLimit.toLocaleString()}</p>
                  </div>
                  <div className="bg-background border border-border rounded-lg p-3 text-center">
                    <p className="text-xs text-muted-foreground">Sent Today</p>
                    <p className="text-xl font-bold text-green-400">{plan.usedToday.toLocaleString()}</p>
                  </div>
                  <div className="bg-background border border-border rounded-lg p-3 text-center">
                    <p className="text-xs text-muted-foreground">Max Volume</p>
                    <p className="text-xl font-bold text-purple-400">{plan.endVolume.toLocaleString()}</p>
                  </div>
                </div>

                {/* History chart */}
                {historyPlanId === plan.id && (
                  <div className="pt-2">
                    <p className="text-xs text-muted-foreground mb-2 font-medium">Daily Send History</p>
                    {(history as any[]).length === 0 ? (
                      <p className="text-xs text-muted-foreground italic">No sends recorded yet</p>
                    ) : (
                      <ResponsiveContainer width="100%" height={140}>
                        <AreaChart data={(history as any[]).map(h => ({ date: h.date, sent: h.sentCount }))} margin={{ top: 4, right: 4, bottom: 0, left: 0 }}>
                          <defs>
                            <linearGradient id={`grd-${plan.id}`} x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                              <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                            </linearGradient>
                          </defs>
                          <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#6b7280" }} tickLine={false} />
                          <YAxis tick={{ fontSize: 10, fill: "#6b7280" }} tickLine={false} axisLine={false} />
                          <Tooltip contentStyle={{ background: "#1f2937", border: "1px solid #374151", borderRadius: 6, fontSize: 11 }} />
                          <ReferenceLine y={plan.dailyLimit} stroke="#f59e0b" strokeDasharray="4 2" label={{ value: "limit", fill: "#f59e0b", fontSize: 9 }} />
                          <Area type="monotone" dataKey="sent" stroke="#3b82f6" fill={`url(#grd-${plan.id})`} strokeWidth={2} dot={false} />
                        </AreaChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Create plan dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-lg bg-card border-border">
          <DialogHeader>
            <DialogTitle>New Warmup Plan</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            {/* Presets */}
            <div>
              <Label className="text-xs text-muted-foreground mb-2 block">Quick Presets</Label>
              <div className="flex gap-2 flex-wrap">
                {PRESETS.map(p => (
                  <button key={p.label} onClick={() => applyPreset(p)}
                    className="px-3 py-1.5 text-xs bg-muted hover:bg-accent rounded-lg border border-border transition-colors">
                    {p.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <Label className="text-xs">Plan Name</Label>
                <Input className="mt-1" placeholder="My Domain Warmup" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
              </div>
              <div className="col-span-2">
                <Label className="text-xs">SMTP Server (optional)</Label>
                <Select value={form.smtpId} onValueChange={v => setForm(f => ({ ...f, smtpId: v }))}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select SMTP or leave blank" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">None</SelectItem>
                    {(smtps as any[]).map((s: any) => (
                      <SelectItem key={s.id} value={String(s.id)}>{s.label || s.host}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Start Date</Label>
                <Input type="date" className="mt-1" value={form.startDate} onChange={e => setForm(f => ({ ...f, startDate: e.target.value }))} />
              </div>
              <div>
                <Label className="text-xs">Duration (days)</Label>
                <Input type="number" min={1} max={90} className="mt-1" value={form.durationDays} onChange={e => setForm(f => ({ ...f, durationDays: e.target.value }))} />
              </div>
              <div>
                <Label className="text-xs">Start Volume (Day 1)</Label>
                <Input type="number" min={1} className="mt-1" value={form.startVolume} onChange={e => setForm(f => ({ ...f, startVolume: e.target.value }))} />
              </div>
              <div>
                <Label className="text-xs">End Volume (Final Day)</Label>
                <Input type="number" min={1} className="mt-1" value={form.endVolume} onChange={e => setForm(f => ({ ...f, endVolume: e.target.value }))} />
              </div>
            </div>

            {/* Live projection chart */}
            <div>
              <Label className="text-xs text-muted-foreground">Volume Ramp Preview</Label>
              <div className="mt-2 bg-background border border-border rounded-lg p-2">
                <ResponsiveContainer width="100%" height={100}>
                  <AreaChart data={projection} margin={{ top: 4, right: 4, bottom: 0, left: 0 }}>
                    <defs>
                      <linearGradient id="previewGrd" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="day" tick={{ fontSize: 9, fill: "#6b7280" }} tickLine={false} />
                    <YAxis tick={{ fontSize: 9, fill: "#6b7280" }} tickLine={false} axisLine={false} />
                    <Tooltip contentStyle={{ background: "#1f2937", border: "1px solid #374151", borderRadius: 6, fontSize: 10 }} formatter={(v: any) => [v.toLocaleString(), "daily limit"]} />
                    <Area type="monotone" dataKey="limit" stroke="#8b5cf6" fill="url(#previewGrd)" strokeWidth={2} dot={false} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="flex gap-2 justify-end pt-1">
              <Button variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
              <Button onClick={handleCreate} disabled={createPlan.isPending}>
                {createPlan.isPending ? "Creating..." : "Create Plan"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* History dialog */}
      {historyPlanId && !plans.find((p: any) => p.id === historyPlanId) && (
        <Dialog open onOpenChange={() => setHistoryPlanId(null)}>
          <DialogContent className="bg-card border-border">
            <DialogHeader><DialogTitle>Send History</DialogTitle></DialogHeader>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
