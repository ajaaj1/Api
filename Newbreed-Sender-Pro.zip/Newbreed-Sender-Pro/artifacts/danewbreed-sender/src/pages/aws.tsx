import { useState } from "react";
import { useListAwsConfigs, useCreateAwsConfig, useDeleteAwsConfig, useVerifyAwsConfig, useSendAwsEmail, getListAwsConfigsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

const AWS_REGIONS = ["auto","us-east-1","us-east-2","us-west-1","us-west-2","eu-west-1","eu-west-2","eu-central-1","ap-southeast-1","ap-southeast-2","ap-northeast-1","sa-east-1","ca-central-1"];

export default function AwsManager() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: configs, isLoading } = useListAwsConfigs();
  const createConfig = useCreateAwsConfig();
  const deleteConfig = useDeleteAwsConfig();
  const verifyConfig = useVerifyAwsConfig();
  const sendEmail = useSendAwsEmail();

  const [addOpen, setAddOpen] = useState(false);
  const [testOpen, setTestOpen] = useState<number | null>(null);
  const [verifying, setVerifying] = useState<number | null>(null);
  const [form, setForm] = useState({ label: "", region: "auto", accessKeyId: "", secretAccessKey: "", fromEmail: "", fromName: "Newbreed Pro Sender" });
  const [testForm, setTestForm] = useState({ to: "", subject: "Test Email - Danewbreed Sender Pro", body: "This is a test email from Danewbreed Sender Pro.", isHtml: false });

  const refresh = () => qc.invalidateQueries({ queryKey: getListAwsConfigsQueryKey() });

  function handleAdd() {
    createConfig.mutate(
      { data: { label: form.label || undefined, region: form.region, accessKeyId: form.accessKeyId, secretAccessKey: form.secretAccessKey, fromEmail: form.fromEmail || undefined, fromName: form.fromName || undefined } },
      {
        onSuccess: (res: any) => { refresh(); setAddOpen(false); setForm({ label: "", region: "auto", accessKeyId: "", secretAccessKey: "", fromEmail: "", fromName: "Newbreed Pro Sender" }); toast({ title: res?.verification?.success ? "AWS config verified" : "AWS config added", description: res?.verification?.message }); },
        onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
      }
    );
  }

  function handleVerify(id: number) {
    setVerifying(id);
    verifyConfig.mutate({ id }, {
      onSuccess: (res) => { refresh(); setVerifying(null); toast({ title: res.success ? "Verified" : "Verification failed", description: res.message, variant: res.success ? "default" : "destructive" }); },
      onError: (e: any) => { setVerifying(null); toast({ title: "Error", description: e.message, variant: "destructive" }); },
    });
  }

  function handleDelete(id: number) {
    if (!confirm("Delete this AWS config?")) return;
    deleteConfig.mutate({ id }, { onSuccess: () => { refresh(); toast({ title: "Deleted" }); } });
  }

  function handleSendTest() {
    if (!testOpen) return;
    sendEmail.mutate({ id: testOpen, data: { to: testForm.to, subject: testForm.subject, body: testForm.body, isHtml: testForm.isHtml } }, {
      onSuccess: (res) => { setTestOpen(null); toast({ title: res.success ? "Email sent" : "Send failed", description: res.message, variant: res.success ? "default" : "destructive" }); },
      onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
    });
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">AWS SES</h2>
          <p className="text-sm text-muted-foreground mt-1">{configs?.length ?? 0} configured — credentials auto-verified via IP</p>
        </div>
        <Button onClick={() => setAddOpen(true)}>Add AWS Config</Button>
      </div>

      <div className="bg-card border border-border rounded-lg overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-muted-foreground">Loading...</div>
        ) : configs && configs.length > 0 ? (
          <table className="w-full text-sm">
            <thead className="border-b border-border bg-muted/30">
              <tr>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">Label</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">Region</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">Access Key</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">From Email</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">Status</th>
                <th className="text-right px-4 py-3 text-muted-foreground font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {configs.map((cfg) => (
                <tr key={cfg.id} className="border-b border-border/50 last:border-0 hover:bg-muted/20">
                  <td className="px-4 py-3 font-medium text-foreground">{cfg.label || "AWS SES"}</td>
                  <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{cfg.region}</td>
                  <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{cfg.accessKeyId?.substring(0, 8)}...</td>
                  <td className="px-4 py-3 text-muted-foreground">{cfg.fromEmail || "-"}</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium status-badge-${cfg.status ?? "untested"}`}>{cfg.status ?? "untested"}</span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex gap-2 justify-end">
                      <Button size="sm" variant="outline" onClick={() => handleVerify(cfg.id)} disabled={verifying === cfg.id}>{verifying === cfg.id ? "Verifying..." : "Verify"}</Button>
                      <Button size="sm" variant="outline" onClick={() => setTestOpen(cfg.id)}>Send Test</Button>
                      <Button size="sm" variant="destructive" onClick={() => handleDelete(cfg.id)}>Delete</Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="p-12 text-center text-muted-foreground">
            <p className="text-base font-medium">No AWS configs</p>
            <p className="text-sm mt-1">Add your Access Key ID and Secret Access Key to connect AWS SES</p>
          </div>
        )}
      </div>

      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="bg-card border-border max-w-lg">
          <DialogHeader><DialogTitle>Add AWS SES Config</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div><Label>Label (optional)</Label><Input className="mt-1" value={form.label} onChange={e => setForm(f => ({ ...f, label: e.target.value }))} placeholder="My AWS Account" /></div>
            <div><Label>Region *</Label>
              <Select value={form.region} onValueChange={v => setForm(f => ({ ...f, region: v }))}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>{AWS_REGIONS.map(r => <SelectItem key={r} value={r}>{r === "auto" ? "Auto-detect region" : r}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Access Key ID *</Label><Input className="mt-1 font-mono text-sm" value={form.accessKeyId} onChange={e => setForm(f => ({ ...f, accessKeyId: e.target.value }))} placeholder="AKIAIOSFODNN7EXAMPLE" /></div>
            <div><Label>Secret Access Key *</Label><Input className="mt-1 font-mono text-sm" type="password" value={form.secretAccessKey} onChange={e => setForm(f => ({ ...f, secretAccessKey: e.target.value }))} placeholder="wJalrXUtnFEMI/K7MDENG..." /></div>
            <div><Label>From Email</Label><Input className="mt-1" value={form.fromEmail} onChange={e => setForm(f => ({ ...f, fromEmail: e.target.value }))} placeholder="sender@yourdomain.com" /></div>
            <div><Label>From Name</Label><Input className="mt-1" value={form.fromName} onChange={e => setForm(f => ({ ...f, fromName: e.target.value }))} /></div>
            <p className="text-xs text-muted-foreground bg-muted/30 rounded p-2">Credentials are verified automatically when added. Auto-detect tests supported SES regions and saves the first region that responds. The From Email must still be verified in AWS SES before sending.</p>
            <Button className="w-full" onClick={handleAdd} disabled={createConfig.isPending || !form.accessKeyId || !form.secretAccessKey}>{createConfig.isPending ? "Adding..." : "Add AWS Config"}</Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={testOpen !== null} onOpenChange={() => setTestOpen(null)}>
        <DialogContent className="bg-card border-border">
          <DialogHeader><DialogTitle>Send Test Email via AWS SES</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <div><Label>To *</Label><Input className="mt-1" value={testForm.to} onChange={e => setTestForm(f => ({ ...f, to: e.target.value }))} placeholder="test@example.com" /></div>
            <div><Label>Subject</Label><Input className="mt-1" value={testForm.subject} onChange={e => setTestForm(f => ({ ...f, subject: e.target.value }))} /></div>
            <div><Label>Body</Label><Textarea className="mt-1" value={testForm.body} onChange={e => setTestForm(f => ({ ...f, body: e.target.value }))} rows={4} /></div>
            <Button className="w-full" onClick={handleSendTest} disabled={sendEmail.isPending || !testForm.to}>{sendEmail.isPending ? "Sending..." : "Send Test"}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
