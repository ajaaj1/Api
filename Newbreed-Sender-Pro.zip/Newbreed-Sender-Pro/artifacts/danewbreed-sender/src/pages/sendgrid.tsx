import { useState } from "react";
import { useListSendgridConfigs, useCreateSendgridConfig, useDeleteSendgridConfig, useVerifySendgridConfig, useSendSendgridEmail, getListSendgridConfigsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export default function SendgridManager() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: configs, isLoading } = useListSendgridConfigs();
  const createConfig = useCreateSendgridConfig();
  const deleteConfig = useDeleteSendgridConfig();
  const verifyConfig = useVerifySendgridConfig();
  const sendEmail = useSendSendgridEmail();

  const [addOpen, setAddOpen] = useState(false);
  const [testOpen, setTestOpen] = useState<number | null>(null);
  const [verifying, setVerifying] = useState<number | null>(null);
  const [form, setForm] = useState({ label: "", apiKey: "", fromEmail: "", fromName: "Newbreed Pro Sender" });
  const [testForm, setTestForm] = useState({ to: "", subject: "Test Email - Danewbreed Sender Pro", body: "This is a test email from Danewbreed Sender Pro.", isHtml: false });

  const refresh = () => qc.invalidateQueries({ queryKey: getListSendgridConfigsQueryKey() });

  function handleAdd() {
    createConfig.mutate(
      { data: { label: form.label || undefined, apiKey: form.apiKey, fromEmail: form.fromEmail || undefined, fromName: form.fromName || undefined } },
      {
        onSuccess: (res: any) => { refresh(); setAddOpen(false); setForm({ label: "", apiKey: "", fromEmail: "", fromName: "Newbreed Pro Sender" }); toast({ title: res?.verification?.success ? "SendGrid key verified" : "SendGrid config added", description: res?.verification?.message }); },
        onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
      }
    );
  }

  function handleVerify(id: number) {
    setVerifying(id);
    verifyConfig.mutate({ id }, {
      onSuccess: (res) => { refresh(); setVerifying(null); toast({ title: res.success ? "Verified" : "Verification failed", description: res.message, variant: res.success ? "default" : "destructive" }); },
      onError: (e: any) => { setVerifying(null); toast({ title: "Error", description: e.message, variant: "destructive" }); },
    });
  }

  function handleDelete(id: number) {
    if (!confirm("Delete this SendGrid config?")) return;
    deleteConfig.mutate({ id }, { onSuccess: () => { refresh(); toast({ title: "Deleted" }); } });
  }

  function handleSendTest() {
    if (!testOpen) return;
    sendEmail.mutate({ id: testOpen, data: { to: testForm.to, subject: testForm.subject, body: testForm.body, isHtml: testForm.isHtml } }, {
      onSuccess: (res) => { setTestOpen(null); toast({ title: res.success ? "Email sent" : "Send failed", description: res.message, variant: res.success ? "default" : "destructive" }); },
      onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
    });
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">SendGrid</h2>
          <p className="text-sm text-muted-foreground mt-1">{configs?.length ?? 0} configured</p>
        </div>
        <Button onClick={() => setAddOpen(true)}>Add SendGrid Config</Button>
      </div>

      <div className="bg-card border border-border rounded-lg overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-muted-foreground">Loading...</div>
        ) : configs && configs.length > 0 ? (
          <table className="w-full text-sm">
            <thead className="border-b border-border bg-muted/30">
              <tr>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">Label</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">API Key</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">From Email</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">From Name</th>
                <th className="text-left px-4 py-3 text-muted-foreground font-medium">Status</th>
                <th className="text-right px-4 py-3 text-muted-foreground font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {configs.map((cfg) => (
                <tr key={cfg.id} className="border-b border-border/50 last:border-0 hover:bg-muted/20">
                  <td className="px-4 py-3 font-medium text-foreground">{cfg.label || "SendGrid"}</td>
                  <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{cfg.apiKey}</td>
                  <td className="px-4 py-3 text-muted-foreground">{cfg.fromEmail || "-"}</td>
                  <td className="px-4 py-3 text-muted-foreground">{cfg.fromName || "-"}</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium status-badge-${cfg.status ?? "untested"}`}>{cfg.status ?? "untested"}</span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex gap-2 justify-end">
                      <Button size="sm" variant="outline" onClick={() => handleVerify(cfg.id)} disabled={verifying === cfg.id}>{verifying === cfg.id ? "Verifying..." : "Verify"}</Button>
                      <Button size="sm" variant="outline" onClick={() => setTestOpen(cfg.id)}>Send Test</Button>
                      <Button size="sm" variant="destructive" onClick={() => handleDelete(cfg.id)}>Delete</Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="p-12 text-center text-muted-foreground">
            <p className="text-base font-medium">No SendGrid configs</p>
            <p className="text-sm mt-1">Add your SendGrid API key to start sending via SendGrid</p>
          </div>
        )}
      </div>

      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="bg-card border-border max-w-lg">
          <DialogHeader><DialogTitle>Add SendGrid Config</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div><Label>Label (optional)</Label><Input className="mt-1" value={form.label} onChange={e => setForm(f => ({ ...f, label: e.target.value }))} placeholder="My SendGrid" /></div>
            <div><Label>API Key *</Label><Input className="mt-1 font-mono text-sm" type="password" value={form.apiKey} onChange={e => setForm(f => ({ ...f, apiKey: e.target.value }))} placeholder="SG.xxxxxxxxxxxxxxxxxxxx" /></div>
            <div><Label>From Email</Label><Input className="mt-1" value={form.fromEmail} onChange={e => setForm(f => ({ ...f, fromEmail: e.target.value }))} placeholder="sender@yourdomain.com" /></div>
            <div><Label>From Name</Label><Input className="mt-1" value={form.fromName} onChange={e => setForm(f => ({ ...f, fromName: e.target.value }))} /></div>
            <p className="text-xs text-muted-foreground bg-muted/30 rounded p-2">The API key is verified automatically when added. If you provide a From Email, SendGrid also checks whether that sender identity is verified.</p>
            <Button className="w-full" onClick={handleAdd} disabled={createConfig.isPending || !form.apiKey}>{createConfig.isPending ? "Adding..." : "Add Config"}</Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={testOpen !== null} onOpenChange={() => setTestOpen(null)}>
        <DialogContent className="bg-card border-border">
          <DialogHeader><DialogTitle>Send Test Email via SendGrid</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <div><Label>To *</Label><Input className="mt-1" value={testForm.to} onChange={e => setTestForm(f => ({ ...f, to: e.target.value }))} placeholder="test@example.com" /></div>
            <div><Label>Subject</Label><Input className="mt-1" value={testForm.subject} onChange={e => setTestForm(f => ({ ...f, subject: e.target.value }))} /></div>
            <div><Label>Body</Label><Textarea className="mt-1" value={testForm.body} onChange={e => setTestForm(f => ({ ...f, body: e.target.value }))} rows={4} /></div>
            <Button className="w-full" onClick={handleSendTest} disabled={sendEmail.isPending || !testForm.to}>{sendEmail.isPending ? "Sending..." : "Send Test"}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
