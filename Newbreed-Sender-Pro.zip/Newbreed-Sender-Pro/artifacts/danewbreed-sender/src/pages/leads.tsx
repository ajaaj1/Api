import { useState, useRef, useCallback, useEffect } from "react";
import {
  useListLeads, useGetLeadsStats, useUploadLeads, useDeleteLead, useClearLeads,
  useListLeadFolders, useCreateLeadFolder, useUpdateLeadFolder, useDeleteLeadFolder,
  useUnsubscribeLead, useReactivateLead,
  getListLeadsQueryKey, getGetLeadsStatsQueryKey, getListLeadFoldersQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

function splitUploadRecords(input: string, format: string): string[] {
  const text = input.replace(/^\uFEFF/, "");
  const firstLine = text.split(/\r?\n/).find(line => line.trim()) ?? "";
  const isCsv = format === "csv" || (format === "auto" && firstLine.includes(","));
  if (!isCsv) return text.split(/\r?\n/).filter(line => line.trim());

  const records: string[] = [];
  let current = "";
  let inQuotedField = false;
  for (let index = 0; index < text.length; index++) {
    const character = text[index];
    if (character === '"') {
      if (inQuotedField && text[index + 1] === '"') {
        current += '""';
        index++;
        continue;
      }
      inQuotedField = !inQuotedField;
      current += character;
      continue;
    }
    if (character === "\n" && !inQuotedField) {
      const record = current.replace(/\r$/, "");
      if (record.trim()) records.push(record);
      current = "";
      continue;
    }
    current += character;
  }
  if (current.trim()) records.push(current);
  return records;
}

export default function LeadsManager() {
  const qc = useQueryClient();
  const { toast } = useToast();

  const [selectedFolderId, setSelectedFolderId] = useState<number | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [uploadType, setUploadType] = useState<"email" | "sms">("email");
  const [uploadContent, setUploadContent] = useState("");
  const [page, setPage] = useState(1);
  const fileRef = useRef<HTMLInputElement>(null);

  const [newFolderOpen, setNewFolderOpen] = useState(false);
  const [newFolderName, setNewFolderName] = useState("");
  const [newFolderType, setNewFolderType] = useState<"email" | "sms">("email");

  const [renameFolderId, setRenameFolderId] = useState<number | null>(null);
  const [renameValue, setRenameValue] = useState("");

  const { data: stats } = useGetLeadsStats();
  const { data: folders, isLoading: foldersLoading } = useListLeadFolders();
  const { data: leadsPage, isLoading } = useListLeads({
    folderId: selectedFolderId ?? undefined,
    status: statusFilter !== "all" ? statusFilter : undefined,
    page,
    limit: 100,
  });
  const uploadLeads = useUploadLeads();
  const deleteLead = useDeleteLead();
  const clearLeads = useClearLeads();
  const createFolder = useCreateLeadFolder();
  const updateFolder = useUpdateLeadFolder();
  const deleteFolder = useDeleteLeadFolder();
  const unsubscribeLead = useUnsubscribeLead();
  const reactivateLead = useReactivateLead();

  const refresh = useCallback(() => {
    qc.invalidateQueries({ queryKey: getListLeadsQueryKey() });
    qc.invalidateQueries({ queryKey: getGetLeadsStatsQueryKey() });
    qc.invalidateQueries({ queryKey: getListLeadFoldersQueryKey() });
  }, [qc]);

  const [uploadProgress, setUploadProgress] = useState<{
    current: number;
    total: number;
    imported: number;
    duplicates: number;
    failed: number;
  } | null>(null);
  const uploadAbortRef = useRef(false);

  // Cancel in-progress chunked upload
  useEffect(() => { return () => { uploadAbortRef.current = true; }; }, []);

  // Direct chunked upload from file — skips React state to avoid memory issues with huge files
  function handleFileRead(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const input = e.target;
    const reader = new FileReader();
    reader.onload = async (ev) => {
      const text = (ev.target?.result as string) ?? "";
      input.value = "";
      if (!text.trim()) {
        toast({ title: "The selected file is empty", description: file.name, variant: "destructive" });
        return;
      }
      const format = file.name.toLowerCase().endsWith(".csv") ? "csv" : "txt";
      await runChunkedUpload(text, file.name, format);
    };
    reader.onerror = () => {
      input.value = "";
      toast({ title: "Could not read this file", description: file.name, variant: "destructive" });
    };
    reader.readAsText(file);
  }

  async function runChunkedUpload(text: string, sourceName?: string, format = "auto") {
    const CHUNK_LINES = 500;
    const records = splitUploadRecords(text, format);
    if (records.length === 0) {
      toast({ title: "No leads found", description: "The file is empty or contains no readable rows.", variant: "destructive" });
      return;
    }

    const totalChunks = Math.ceil(records.length / CHUNK_LINES);
    let totalImported = 0;
    let totalDuplicates = 0;
    let totalFailed = 0;
    const uploadErrors: string[] = [];
    uploadAbortRef.current = false;
    setUploadProgress({ current: 0, total: totalChunks, imported: 0, duplicates: 0, failed: 0 });

    for (let i = 0; i < totalChunks; i++) {
      if (uploadAbortRef.current) break;
      const chunkRecords = records.slice(i * CHUNK_LINES, (i + 1) * CHUNK_LINES);
      const chunk = chunkRecords.join("\n");
      const payload: any = { content: chunk, type: uploadType, format };
      if (selectedFolderId !== null) payload.folderId = selectedFolderId;

      try {
        const res = await uploadLeads.mutateAsync({ data: payload });
        totalImported += res.imported;
        totalDuplicates += res.duplicates;
        totalFailed += res.failed ?? 0;
        for (const error of res.errors ?? []) {
          if (uploadErrors.length < 12) uploadErrors.push(`Batch ${i + 1}: ${error}`);
        }
      } catch (error) {
        const data = (error as { data?: { imported?: number; duplicates?: number; failed?: number; total?: number; errors?: string[] } })?.data;
        const batchImported = Number(data?.imported) || 0;
        const batchDuplicates = Number(data?.duplicates) || 0;
        const batchTotal = Number(data?.total);
        const batchFailed = Number.isFinite(data?.failed)
          ? Number(data?.failed)
          : Math.max(0, chunkRecords.length - batchImported - batchDuplicates);
        totalImported += batchImported;
        totalDuplicates += batchDuplicates;
        totalFailed += batchFailed + (Number.isFinite(batchTotal) ? Math.max(0, chunkRecords.length - batchTotal) : 0);
        totalFailed += Math.max(0, records.length - (i + 1) * CHUNK_LINES);
        const message = error instanceof Error ? error.message : "The server rejected this batch.";
        if (uploadErrors.length < 12) uploadErrors.push(`Batch ${i + 1}: ${message}`);
        for (const detail of data?.errors ?? []) {
          if (uploadErrors.length < 12) uploadErrors.push(`Batch ${i + 1}: ${detail}`);
        }
        setUploadProgress({
          current: i + 1,
          total: totalChunks,
          imported: totalImported,
          duplicates: totalDuplicates,
          failed: totalFailed,
        });
        break;
      }
      setUploadProgress({
        current: i + 1,
        total: totalChunks,
        imported: totalImported,
        duplicates: totalDuplicates,
        failed: totalFailed,
      });
    }

    setUploadProgress(null);
    refresh();
    if (!sourceName && totalFailed === 0) setUploadContent("");
    const summary = `${totalImported.toLocaleString()} imported, ${totalDuplicates.toLocaleString()} duplicates skipped, ${totalFailed.toLocaleString()} failed${sourceName ? ` (${sourceName})` : ""}`;
    toast({
      title: totalFailed > 0 ? "Upload finished with errors" : "Upload complete",
      description: uploadErrors.length ? `${summary}. ${uploadErrors.slice(0, 3).join(" ")}` : summary,
      variant: totalFailed > 0 ? "destructive" : "default",
    });
  }

  function handleUpload() {
    if (!uploadContent.trim()) return;
    runChunkedUpload(uploadContent);
  }

  function handleDelete(id: number) {
    deleteLead.mutate({ id }, { onSuccess: () => refresh() });
  }

  function handleUnsubscribe(id: number) {
    unsubscribeLead.mutate({ id }, {
      onSuccess: () => { refresh(); toast({ title: "Lead unsubscribed" }); },
      onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
    });
  }

  function handleReactivate(id: number) {
    reactivateLead.mutate({ id }, {
      onSuccess: () => { refresh(); toast({ title: "Lead reactivated" }); },
      onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
    });
  }

  const statusBadge: Record<string, string> = {
    active: "bg-green-500/15 text-green-400 border border-green-500/30",
    bounced: "bg-red-500/15 text-red-400 border border-red-500/30",
    unsubscribed: "bg-orange-500/15 text-orange-400 border border-orange-500/30",
  };

  function handleClear() {
    const label = selectedFolderId ? `leads in this folder` : `ALL leads`;
    if (!confirm(`Clear ${label}? This cannot be undone.`)) return;
    clearLeads.mutate(undefined, { onSuccess: () => { refresh(); toast({ title: "Leads cleared" }); } });
  }

  function handleCreateFolder() {
    if (!newFolderName.trim()) return;
    createFolder.mutate({ data: { name: newFolderName.trim(), type: newFolderType } }, {
      onSuccess: (res) => {
        refresh();
        setNewFolderOpen(false);
        setNewFolderName("");
        setSelectedFolderId(res.id);
        toast({ title: `Folder "${res.name}" created` });
      },
      onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
    });
  }

  function startRename(id: number, name: string) {
    setRenameFolderId(id);
    setRenameValue(name);
  }

  function handleRename() {
    if (!renameFolderId || !renameValue.trim()) return;
    updateFolder.mutate({ id: renameFolderId, data: { name: renameValue.trim() } }, {
      onSuccess: () => { refresh(); setRenameFolderId(null); toast({ title: "Folder renamed" }); },
      onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
    });
  }

  function handleDeleteFolder(id: number, name: string) {
    if (!confirm(`Delete folder "${name}" and ALL its leads? This cannot be undone.`)) return;
    deleteFolder.mutate({ id }, {
      onSuccess: () => {
        refresh();
        if (selectedFolderId === id) setSelectedFolderId(null);
        toast({ title: `Folder deleted` });
      },
    });
  }

  const totalPages = leadsPage ? Math.ceil(leadsPage.total / 100) : 1;
  const activeFolder = folders?.find(f => f.id === selectedFolderId);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">Leads</h2>
        <p className="text-sm text-muted-foreground mt-1">Organize contacts into folders and import TXT/CSV files in batches</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="bg-card border border-border rounded-lg p-4">
          <p className="text-xs text-muted-foreground uppercase tracking-wide">Email</p>
          <p className="text-2xl font-bold text-blue-400 mt-1">{stats?.totalEmail?.toLocaleString() ?? "0"}</p>
        </div>
        <div className="bg-card border border-border rounded-lg p-4">
          <p className="text-xs text-muted-foreground uppercase tracking-wide">SMS</p>
          <p className="text-2xl font-bold text-purple-400 mt-1">{stats?.totalSms?.toLocaleString() ?? "0"}</p>
        </div>
        <div className="bg-card border border-border rounded-lg p-4">
          <p className="text-xs text-muted-foreground uppercase tracking-wide">Total</p>
          <p className="text-2xl font-bold text-green-400 mt-1">{stats?.total?.toLocaleString() ?? "0"}</p>
        </div>
        <div
          className={`bg-card border rounded-lg p-4 cursor-pointer transition-colors ${statusFilter === "bounced" ? "border-red-500/50 bg-red-500/5" : "border-border hover:border-red-500/30"}`}
          onClick={() => { setStatusFilter(statusFilter === "bounced" ? "all" : "bounced"); setPage(1); }}
        >
          <p className="text-xs text-muted-foreground uppercase tracking-wide">Bounced</p>
          <p className="text-2xl font-bold text-red-400 mt-1">{(stats as any)?.totalBounced?.toLocaleString() ?? "0"}</p>
        </div>
        <div
          className={`bg-card border rounded-lg p-4 cursor-pointer transition-colors ${statusFilter === "unsubscribed" ? "border-orange-500/50 bg-orange-500/5" : "border-border hover:border-orange-500/30"}`}
          onClick={() => { setStatusFilter(statusFilter === "unsubscribed" ? "all" : "unsubscribed"); setPage(1); }}
        >
          <p className="text-xs text-muted-foreground uppercase tracking-wide">Unsubscribed</p>
          <p className="text-2xl font-bold text-orange-400 mt-1">{(stats as any)?.totalUnsubscribed?.toLocaleString() ?? "0"}</p>
        </div>
      </div>

      {statusFilter !== "all" && (
        <div className={`flex items-center gap-3 px-3 py-2 rounded-lg border text-sm ${statusFilter === "bounced" ? "bg-red-500/10 border-red-500/30 text-red-400" : "bg-orange-500/10 border-orange-500/30 text-orange-400"}`}>
          <span>Filtering by: <strong className="capitalize">{statusFilter}</strong></span>
          <button onClick={() => { setStatusFilter("all"); setPage(1); }} className="ml-auto text-xs underline opacity-70 hover:opacity-100">Clear filter</button>
        </div>
      )}

      <div className="flex gap-4">
        {/* Folder Sidebar */}
        <div className="w-56 shrink-0">
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <div className="flex items-center justify-between px-3 py-2.5 border-b border-border">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Folders</span>
              <button
                onClick={() => setNewFolderOpen(true)}
                className="text-xs text-primary hover:text-primary/80 font-medium"
              >+ New</button>
            </div>

            {/* All Leads option */}
            <button
              onClick={() => { setSelectedFolderId(null); setPage(1); }}
              className={`w-full text-left px-3 py-2.5 text-sm flex items-center justify-between hover:bg-muted/30 transition-colors ${selectedFolderId === null ? "bg-primary/10 text-primary" : "text-foreground"}`}
            >
              <div className="flex items-center gap-2">
                <span>📁</span>
                <span className="font-medium">All Leads</span>
              </div>
              <span className="text-xs text-muted-foreground">{stats?.total?.toLocaleString() ?? 0}</span>
            </button>

            {/* Folder list */}
            {foldersLoading ? (
              <div className="p-4 text-center text-xs text-muted-foreground">Loading...</div>
            ) : folders && folders.length > 0 ? (
              folders.map((folder) => (
                <div
                  key={folder.id}
                  className={`group relative flex items-center justify-between px-3 py-2.5 hover:bg-muted/30 transition-colors cursor-pointer ${selectedFolderId === folder.id ? "bg-primary/10" : ""}`}
                  onClick={() => { setSelectedFolderId(folder.id); setPage(1); }}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-sm">{folder.type === "sms" ? "📱" : "✉️"}</span>
                    {renameFolderId === folder.id ? (
                      <Input
                        autoFocus
                        className="h-6 text-xs px-1 py-0"
                        value={renameValue}
                        onChange={e => setRenameValue(e.target.value)}
                        onKeyDown={e => { if (e.key === "Enter") handleRename(); if (e.key === "Escape") setRenameFolderId(null); }}
                        onBlur={() => setRenameFolderId(null)}
                        onClick={e => e.stopPropagation()}
                      />
                    ) : (
                      <span className={`text-sm truncate ${selectedFolderId === folder.id ? "text-primary font-medium" : "text-foreground"}`}>
                        {folder.name}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="text-xs text-muted-foreground">{folder.leadCount?.toLocaleString() ?? 0}</span>
                    <div className="hidden group-hover:flex gap-0.5" onClick={e => e.stopPropagation()}>
                      <button onClick={() => startRename(folder.id, folder.name)} className="text-muted-foreground hover:text-foreground p-0.5 text-xs" title="Rename">✏️</button>
                      <button onClick={() => handleDeleteFolder(folder.id, folder.name)} className="text-muted-foreground hover:text-red-400 p-0.5 text-xs" title="Delete">🗑️</button>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-3 text-center text-xs text-muted-foreground">No folders yet</div>
            )}
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 min-w-0 space-y-4">
          {/* Upload panel */}
          <div className="bg-card border border-border rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-medium">Upload Leads</h3>
                {selectedFolderId && activeFolder && (
                  <p className="text-xs text-primary mt-0.5">Uploading to: <strong>{activeFolder.name}</strong></p>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Label className="text-xs text-muted-foreground">Type:</Label>
                <Select value={uploadType} onValueChange={(v) => setUploadType(v as "email" | "sms")}>
                  <SelectTrigger className="w-28 h-8 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="email">Email</SelectItem>
                    <SelectItem value="sms">SMS</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              Paste leads or upload a TXT/CSV file. Large files are sent in smaller batches so failures are easier to isolate.
            </p>
            <Textarea
              className="font-mono text-xs h-28 resize-none"
              value={uploadContent}
              onChange={e => setUploadContent(e.target.value)}
              placeholder="user@example.com&#10;another@example.com&#10;&#10;Or CSV:&#10;user@example.com,John,Doe"
            />
            {uploadProgress && (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">
                    Batch {uploadProgress.current}/{uploadProgress.total} — {uploadProgress.imported.toLocaleString()} imported, {uploadProgress.duplicates.toLocaleString()} duplicates, {uploadProgress.failed.toLocaleString()} failed
                  </span>
                  <span className="text-primary font-medium">{Math.round((uploadProgress.current / uploadProgress.total) * 100)}%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-1.5 overflow-hidden">
                  <div
                    className="h-full bg-primary transition-all duration-300 rounded-full"
                    style={{ width: `${Math.round((uploadProgress.current / uploadProgress.total) * 100)}%` }}
                  />
                </div>
              </div>
            )}
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => fileRef.current?.click()} disabled={!!uploadProgress} className="text-xs">
                {uploadProgress ? "Uploading..." : "Choose TXT or CSV"}
              </Button>
              <input ref={fileRef} type="file" accept=".txt,.csv" className="hidden" onChange={handleFileRead} />
              <Button onClick={handleUpload} disabled={!!uploadProgress || !uploadContent.trim()} className="text-xs">
                {uploadProgress ? `Uploading ${uploadProgress.current}/${uploadProgress.total}...` : selectedFolderId ? `Upload to Folder` : "Upload Leads"}
              </Button>
            </div>
          </div>

          {/* Leads Table */}
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-foreground">
                  {activeFolder ? activeFolder.name : "All Leads"}
                </span>
                {selectedFolderId && activeFolder && (
                  <span className={`text-xs px-2 py-0.5 rounded-full ${activeFolder.type === "sms" ? "bg-purple-500/20 text-purple-400" : "bg-blue-500/20 text-blue-400"}`}>
                    {activeFolder.type}
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">{leadsPage?.total?.toLocaleString() ?? 0} leads</span>
                <Button size="sm" variant="destructive" onClick={handleClear} className="text-xs">Clear</Button>
              </div>
            </div>

            {isLoading ? (
              <div className="p-8 text-center text-muted-foreground">Loading...</div>
            ) : leadsPage && leadsPage.data.length > 0 ? (
              <>
                <table className="w-full text-sm">
                  <thead className="border-b border-border bg-muted/30">
                    <tr>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium">Email / Phone</th>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium">First Name</th>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium">Last Name</th>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium">Status</th>
                      <th className="text-left px-4 py-3 text-muted-foreground font-medium">Added</th>
                      <th className="text-right px-4 py-3 text-muted-foreground font-medium"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {leadsPage.data.map((lead: any) => (
                      <tr key={lead.id} className={`border-b border-border/50 last:border-0 hover:bg-muted/20 ${lead.status !== "active" ? "opacity-60" : ""}`}>
                        <td className="px-4 py-2.5 font-mono text-xs text-foreground">{lead.value}</td>
                        <td className="px-4 py-2.5 text-muted-foreground text-sm">{lead.firstName || "—"}</td>
                        <td className="px-4 py-2.5 text-muted-foreground text-sm">{lead.lastName || "—"}</td>
                        <td className="px-4 py-2.5">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusBadge[lead.status ?? "active"] ?? statusBadge.active}`}>
                            {lead.status ?? "active"}
                          </span>
                          {lead.bouncedAt && (
                            <div className="text-xs text-muted-foreground mt-0.5">{new Date(lead.bouncedAt).toLocaleDateString()}</div>
                          )}
                        </td>
                        <td className="px-4 py-2.5 text-muted-foreground text-xs">{new Date(lead.createdAt).toLocaleDateString()}</td>
                        <td className="px-4 py-2.5 text-right">
                          <div className="flex gap-1 justify-end">
                            {(lead.status === "bounced" || lead.status === "unsubscribed") ? (
                              <Button size="sm" variant="outline" className="text-xs text-green-400 border-green-500/30 hover:bg-green-500/10" onClick={() => handleReactivate(lead.id)}>Reactivate</Button>
                            ) : (
                              <Button size="sm" variant="ghost" className="text-xs text-orange-400 hover:text-orange-300" onClick={() => handleUnsubscribe(lead.id)}>Unsub</Button>
                            )}
                            <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive text-xs" onClick={() => handleDelete(lead.id)}>Remove</Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {totalPages > 1 && (
                  <div className="flex items-center justify-between px-4 py-3 border-t border-border">
                    <span className="text-xs text-muted-foreground">Page {page} of {totalPages}</span>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="text-xs">Previous</Button>
                      <Button size="sm" variant="outline" onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="text-xs">Next</Button>
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="p-12 text-center text-muted-foreground">
                <p className="text-base font-medium">No leads yet</p>
                <p className="text-sm mt-1">
                  {selectedFolderId ? "Upload leads to this folder above" : "Upload a TXT or CSV file to get started"}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* New Folder Dialog */}
      <Dialog open={newFolderOpen} onOpenChange={setNewFolderOpen}>
        <DialogContent className="bg-card border-border max-w-sm">
          <DialogHeader><DialogTitle>New Lead Folder</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div>
              <Label>Folder Name *</Label>
              <Input
                className="mt-1"
                value={newFolderName}
                onChange={e => setNewFolderName(e.target.value)}
                placeholder="e.g. Newsletter List Q1"
                onKeyDown={e => e.key === "Enter" && handleCreateFolder()}
                autoFocus
              />
            </div>
            <div>
              <Label>Lead Type</Label>
              <Select value={newFolderType} onValueChange={v => setNewFolderType(v as "email" | "sms")}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="email">Email Leads</SelectItem>
                  <SelectItem value="sms">SMS Leads</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button
              className="w-full"
              onClick={handleCreateFolder}
              disabled={!newFolderName.trim() || createFolder.isPending}
            >
              {createFolder.isPending ? "Creating..." : "Create Folder"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
