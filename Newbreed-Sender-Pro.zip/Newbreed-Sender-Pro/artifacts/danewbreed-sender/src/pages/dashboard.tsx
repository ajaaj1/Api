import { useGetLeadsStats, useGetDeliveryStats, useListCampaigns } from "@workspace/api-client-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";

export default function Dashboard() {
  const { data: leadsStats } = useGetLeadsStats();
  const { data: deliveryStats } = useGetDeliveryStats();
  const { data: campaigns } = useListCampaigns();

  const activeCampaigns = campaigns?.filter(c => c.status === "sending").length ?? 0;
  const totalCampaigns = campaigns?.length ?? 0;

  const channelData = deliveryStats?.byChannel
    ? Object.entries(deliveryStats.byChannel).map(([channel, data]: [string, any]) => ({
        name: channel.toUpperCase(),
        sent: data.sent || 0,
        failed: data.failed || 0,
      }))
    : [];

  const statCards = [
    { label: "Total Email Leads", value: leadsStats?.totalEmail?.toLocaleString() ?? "0", color: "text-blue-400" },
    { label: "Total SMS Leads", value: leadsStats?.totalSms?.toLocaleString() ?? "0", color: "text-purple-400" },
    { label: "Emails Sent", value: deliveryStats?.totalSent?.toLocaleString() ?? "0", color: "text-green-400" },
    { label: "Failed", value: deliveryStats?.totalFailed?.toLocaleString() ?? "0", color: "text-red-400" },
    { label: "Delivery Rate", value: deliveryStats?.deliveryRate ? `${(deliveryStats.deliveryRate * 100).toFixed(1)}%` : "0%", color: "text-yellow-400" },
    { label: "Active Campaigns", value: activeCampaigns, color: "text-orange-400" },
    { label: "Total Campaigns", value: totalCampaigns, color: "text-cyan-400" },
    { label: "Total Leads", value: leadsStats?.total?.toLocaleString() ?? "0", color: "text-pink-400" },
  ];

  const recentDeliveries = deliveryStats?.recentActivity ?? [];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-foreground">Overview</h2>
        <p className="text-sm text-muted-foreground mt-1">Real-time sending statistics for Danewbreed Sender Pro</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {statCards.map((card) => (
          <div key={card.label} className="bg-card border border-border rounded-lg p-4">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">{card.label}</p>
            <p className={`text-2xl font-bold mt-1 ${card.color}`}>{card.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-card border border-border rounded-lg p-4">
          <h3 className="text-sm font-medium text-foreground mb-4">Sent vs Failed by Channel</h3>
          {channelData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={channelData}>
                <XAxis dataKey="name" tick={{ fill: "#9ca3af", fontSize: 12 }} />
                <YAxis tick={{ fill: "#9ca3af", fontSize: 12 }} />
                <Tooltip contentStyle={{ background: "#1e2030", border: "1px solid #2d3148", color: "#e2e8f0" }} />
                <Bar dataKey="sent" name="Sent" fill="hsl(142, 71%, 45%)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="failed" name="Failed" fill="hsl(0, 72%, 51%)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">No delivery data yet</div>
          )}
        </div>

        <div className="bg-card border border-border rounded-lg p-4">
          <h3 className="text-sm font-medium text-foreground mb-4">Top Campaigns</h3>
          {deliveryStats?.byCampaign && (deliveryStats.byCampaign as any[]).length > 0 ? (
            <div className="space-y-2">
              {(deliveryStats.byCampaign as any[]).slice(0, 6).map((c: any) => (
                <div key={c.campaign_id} className="flex items-center justify-between py-1.5 border-b border-border last:border-0">
                  <span className="text-sm text-foreground truncate max-w-[60%]">{c.campaign_name}</span>
                  <div className="flex gap-3 text-xs">
                    <span className="text-green-400">{Number(c.sent).toLocaleString()} sent</span>
                    <span className="text-red-400">{Number(c.failed).toLocaleString()} failed</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">No campaign data yet</div>
          )}
        </div>
      </div>

      <div className="bg-card border border-border rounded-lg p-4">
        <h3 className="text-sm font-medium text-foreground mb-3">Recent Campaigns</h3>
        {campaigns && campaigns.length > 0 ? (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left">
                <th className="pb-2 text-muted-foreground font-medium">Name</th>
                <th className="pb-2 text-muted-foreground font-medium">Status</th>
                <th className="pb-2 text-muted-foreground font-medium">Type</th>
                <th className="pb-2 text-muted-foreground font-medium">Sent</th>
                <th className="pb-2 text-muted-foreground font-medium">Failed</th>
              </tr>
            </thead>
            <tbody>
              {campaigns.slice(0, 5).map(c => (
                <tr key={c.id} className="border-b border-border/50 last:border-0">
                  <td className="py-2 text-foreground">{c.name}</td>
                  <td className="py-2">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium status-badge-${c.status}`}>{c.status}</span>
                  </td>
                  <td className="py-2 text-muted-foreground">{c.type}</td>
                  <td className="py-2 text-green-400">{(c.totalSent ?? 0).toLocaleString()}</td>
                  <td className="py-2 text-red-400">{(c.totalFailed ?? 0).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p className="text-muted-foreground text-sm">No campaigns yet. Create one to get started.</p>
        )}
      </div>
    </div>
  );
}
