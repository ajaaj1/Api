import { useState, useRef, useEffect } from "react";
import { useListSmtps, useCreateSmtp, useImportSmtps, useDeleteSmtp, useTestSmtp, useClearUnverifiedSmtps, getListSmtpsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";

const PAGE_SIZE = 100;

type TestResult = {
  id: number; host: string; user: string; label?: string | null;
  success: boolean; usedPort: number; messageId?: string; response?: string; error?: string;
};
type JobState = {
  total: number; completed: number; done: boolean; passed: number; failed: number;
  nextCursor: number; failedIds: number[];
  results: TestResult[];
};

const MAX_VISIBLE_TEST_RESULTS = 100;

export default function SmtpManager() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: smtps, isLoading } = useListSmtps();
  const createSmtp = useCreateSmtp();
  const importSmtps = useImportSmtps();
  const deleteSmtp = useDeleteSmtp();
  const testSmtp = useTestSmtp();
  const clearUnverified = useClearUnverifiedSmtps();

  const importFileRef = useRef<HTMLInputElement>(null);
  const pollRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [addOpen, setAddOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [testOpen, setTestOpen] = useState<number | null>(null);
  const [testAllOpen, setTestAllOpen] = useState(false);
  const [testEmail, setTestEmail] = useState("");
  const [testAllEmail, setTestAllEmail] = useState("");
  const [importRaw, setImportRaw] = useState("");
  const [importProgress, setImportProgress] = useState<{ current: number; total: number; imported: number; failed: number } | null>(null);
  const [testingId, setTestingId] = useState<number | null>(null);
  const [testingAll, setTestingAll] = useState(false);
  const [job, setJob] = useState<JobState | null>(null);
  const [page, setPage] = useState(1);

  const [form, setForm] = useState({ label: "", host: "", port: "465", user: "", pass: "", secure: true });

  const refresh = () => qc.invalidateQueries({ queryKey: getListSmtpsQueryKey() });

  function stopPolling() {
    if (pollRef.current) { clearTimeout(pollRef.current); pollRef.current = null; }
  }

  useEffect(() => () => stopPolling(), []);

  function handleAdd() {
    createSmtp.mutate(
      { data: { label: form.label || undefined, host: form.host, port: parseInt(form.port), user: form.user, pass: form.pass, secure: form.secure } },
      {
        onSuccess: (res: any) => { refresh(); setAddOpen(false); setForm({ label: "", host: "", port: "465", user: "", pass: "", secure: true }); toast({ title: res?.verification?.success ? "SMTP verified" : "SMTP added; verification failed", description: res?.verification?.message, variant: res?.verification?.success ? "default" : "destructive" }); },
        onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
      }
    );
  }

  async function handleImport() {
    const rows = importRaw.replace(/^\uFEFF/, "").split(/\r?\n/).filter(line => line.trim());
    if (rows.length === 0 || importProgress) return;

    const CHUNK_SIZE = 500;
    const totalChunks = Math.ceil(rows.length / CHUNK_SIZE);
    let imported = 0;
    let failed = 0;
    const errors: string[] = [];
    setImportProgress({ current: 0, total: totalChunks, imported: 0, failed: 0 });

    for (let index = 0; index < totalChunks; index++) {
      const chunk = rows.slice(index * CHUNK_SIZE, (index + 1) * CHUNK_SIZE);
      try {
        const result = await importSmtps.mutateAsync({ data: { raw: chunk.join("\n") } });
        imported += result.imported;
        failed += result.failed;
        for (const error of result.errors ?? []) {
          if (errors.length < 12) errors.push(`Batch ${index + 1}: ${error}`);
        }
      } catch (error) {
        const data = (error as { data?: { imported?: number; failed?: number; total?: number; errors?: string[] } })?.data;
        const batchImported = Number(data?.imported) || 0;
        const batchTotal = Number(data?.total);
        const batchFailed = Number.isFinite(data?.failed)
          ? Number(data?.failed)
          : Math.max(0, chunk.length - batchImported);
        imported += batchImported;
        failed += batchFailed + (Number.isFinite(batchTotal) ? Math.max(0, chunk.length - batchTotal) : 0);
        failed += Math.max(0, rows.length - (index + 1) * CHUNK_SIZE);
        const message = error instanceof Error ? error.message : "The server could not process this upload.";
        if (errors.length < 12) errors.push(`Batch ${index + 1}: ${message}`);
        for (const detail of data?.errors ?? []) {
          if (errors.length < 12) errors.push(`Batch ${index + 1}: ${detail}`);
        }
        break;
      }
      setImportProgress({ current: index + 1, total: totalChunks, imported, failed });
    }

    setImportProgress(null);
    refresh();
    if (failed === 0) {
      setImportOpen(false);
      setImportRaw("");
    }
    toast({
      title: failed > 0 ? `Imported ${imported} SMTPs; ${failed} rows failed` : `Imported ${imported} SMTPs`,
      description: errors.length
        ? `${errors.slice(0, 3).join(" ")} The import text is still available so you can correct and retry it.`
        : undefined,
      variant: failed > 0 ? "destructive" : "default",
    });
  }

  function handleDelete(id: number) {
    if (!confirm("Delete this SMTP?")) return;
    deleteSmtp.mutate({ id }, { onSuccess: () => { refresh(); toast({ title: "Deleted" }); } });
  }

  function handleClearUnverified() {
    const nonVerified = smtps?.filter(s => s.status !== "verified").length ?? 0;
    if (nonVerified === 0) {
      toast({ title: "No non-verified SMTPs to delete" });
      return;
    }
    if (!confirm(`Delete ${nonVerified} non-verified SMTP(s)? This cannot be undone.`)) return;
    clearUnverified.mutate(undefined, {
      onSuccess: (r: any) => { refresh(); toast({ title: `Deleted ${r.deleted} non-verified SMTP(s)` }); },
      onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
    });
  }

  function handleTest() {
    if (!testOpen || !testEmail) return;
    setTestingId(testOpen);
    testSmtp.mutate(
      { id: testOpen, data: { toEmail: testEmail, fromName: "Newbreed Pro Sender" } },
      {
        onSuccess: (res) => {
          refresh();
          setTestingId(null);
          setTestOpen(null);
          setTestEmail("");
          const msg = (res as any).port && (res as any).port !== (smtps?.find(s => s.id === testOpen)?.port)
            ? `${res.message} — port auto-updated`
            : res.message;
          toast({ title: res.success ? "SMTP accepted the email" : "Test failed", description: msg, variant: res.success ? "default" : "destructive" });
        },
        onError: (e: any) => { setTestingId(null); toast({ title: "Error", description: e.message, variant: "destructive" }); },
      }
    );
  }

  async function handleTestAll(retryIds?: number[]) {
    if (!testAllEmail) return;
    stopPolling();
    setTestingAll(true);
    setJob({
      total: -1,
      completed: 0,
      done: false,
      passed: 0,
      failed: 0,
      nextCursor: 0,
      failedIds: [],
      results: [],
    });

    try {
      const startRes = await fetch("/api/smtp/test-all", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ toEmail: testAllEmail, ...(retryIds ? { ids: retryIds } : {}) }),
      });

      if (!startRes.ok) {
        const errText = await startRes.text();
        throw new Error(errText || `HTTP ${startRes.status}`);
      }

      const { jobId } = await startRes.json();
      if (typeof jobId !== "string" || !jobId) throw new Error("The SMTP test job did not return an ID");
      let consecutivePollErrors = 0;

      const pollJob = async (cursor: number): Promise<void> => {
        try {
          const pollRes = await fetch(
            `/api/smtp/test-all/job/${jobId}?after=${cursor}&limit=100`,
            { signal: AbortSignal.timeout(15000) },
          );
          if (!pollRes.ok) throw new Error(`Progress request failed (HTTP ${pollRes.status})`);
          const state: JobState & { fatalError?: string } = await pollRes.json();
          consecutivePollErrors = 0;
          const newResults = Array.isArray(state.results) ? state.results : [];
          setJob((current) => {
            const failedIds = new Set(current?.failedIds ?? []);
            newResults.forEach((result) => {
              if (!result.success) failedIds.add(result.id);
            });
            return {
              ...state,
              failedIds: [...failedIds],
              results: [...(current?.results ?? []), ...newResults].slice(-MAX_VISIBLE_TEST_RESULTS),
            };
          });

          if (state.fatalError) {
            stopPolling();
            setTestingAll(false);
            refresh();
            toast({ title: "Test error", description: state.fatalError, variant: "destructive" });
            return;
          }

          if (state.done && state.nextCursor >= state.completed) {
            stopPolling();
            setTestingAll(false);
            refresh();
            toast({
              title: `Test complete: ${state.passed}/${state.total} passed`,
              description: state.failed > 0
                ? `${state.failed} failed. Open a failed row for the exact reason.`
                : "All SMTPs accepted the email. Check the recipient inbox and spam folder.",
            });
            return;
          }

          pollRef.current = setTimeout(
            () => { void pollJob(state.nextCursor); },
            state.done ? 0 : 1000,
          );
        } catch (error) {
          consecutivePollErrors++;
          if (consecutivePollErrors >= 6) {
            stopPolling();
            setTestingAll(false);
            toast({
              title: "Lost connection to SMTP test progress",
              description: error instanceof Error ? error.message : "The background test may still be running.",
              variant: "destructive",
            });
            return;
          }
          const retryDelay = Math.min(1000 * (2 ** (consecutivePollErrors - 1)), 8000);
          pollRef.current = setTimeout(() => { void pollJob(cursor); }, retryDelay);
        }
      };

      void pollJob(0);
    } catch (e: any) {
      stopPolling();
      setTestingAll(false);
      toast({ title: "Test error", description: e.message, variant: "destructive" });
    }
  }

  function handleImportFileRead(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const input = e.currentTarget;
    const reader = new FileReader();
    reader.onload = (ev) => {
      input.value = "";
      const raw = ev.target?.result as string ?? "";
      if (!raw.trim()) {
        toast({ title: "The selected file is empty", description: file.name, variant: "destructive" });
        return;
      }
      setImportRaw(raw);
      toast({ title: `File loaded: ${file.name}`, description: "Review the contents, then choose Import." });
    };
    reader.onerror = () => {
      input.value = "";
      toast({ title: "Could not read this file", description: file.name, variant: "destructive" });
    };
    reader.readAsText(file);
    setImportOpen(true);
  }

  const IMPORT_HINT = `Supported formats (one per line):\n• MAIL: user@host.com, HOST: host.com, PORT: 465, USER: user, PASS: pass\n• host.com:587,user@host.com,password\n• mail.host.com|587|user@host.com|password`;

  const verifiedCount = smtps?.filter(s => s.status === "verified").length ?? 0;
  const failedCount = smtps?.filter(s => s.status === "failed").length ?? 0;
  const totalSmtps = smtps?.length ?? 0;
  const pagedSmtps = smtps?.slice(0, page * PAGE_SIZE) ?? [];
  const hasMore = totalSmtps > pagedSmtps.length;

  const progressPct = job && job.total > 0
    ? Math.round((job.completed / job.total) * 100)
    : 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">SMTP Servers</h2>
          <p className="text-sm text-muted-foreground mt-1">
            {totalSmtps} configured
            {verifiedCount > 0 && <span className="ml-2 text-green-400">{verifiedCount} verified</span>}
            {failedCount > 0 && <span className="ml-2 text-red-400">{failedCount} failed</span>}
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          {totalSmtps > 0 && (
            <Button variant="outline" onClick={() => { setJob(null); setTestAllOpen(true); }} className="text-xs">
              Test All ({totalSmtps})
            </Button>
          )}
          {(smtps?.filter(s => s.status !== "verified").length ?? 0) > 0 && (
            <Button variant="outline" onClick={handleClearUnverified} disabled={clearUnverified.isPending} className="text-xs text-red-400 border-red-500/40 hover:bg-red-500/10">
              Delete Non-Verified ({smtps?.filter(s => s.status !== "verified").length})
            </Button>
          )}
          <Button variant="outline" onClick={() => importFileRef.current?.click()}>Import File</Button>
          <input ref={importFileRef} type="file" accept=".txt,.csv,.conf,.text" className="hidden" onChange={handleImportFileRead} />
          <Button variant="outline" onClick={() => setImportOpen(true)}>Import SMTPs</Button>
          <Button onClick={() => setAddOpen(true)}>Add SMTP</Button>
        </div>
      </div>

      {/* SMTP Table — paginated */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-muted-foreground">Loading...</div>
        ) : smtps && smtps.length > 0 ? (
          <>
            <table className="w-full text-sm">
              <thead className="border-b border-border bg-muted/30">
                <tr>
                  <th className="text-left px-4 py-3 text-muted-foreground font-medium">Label / Host</th>
                  <th className="text-left px-4 py-3 text-muted-foreground font-medium">Port</th>
                  <th className="text-left px-4 py-3 text-muted-foreground font-medium">User</th>
                  <th className="text-left px-4 py-3 text-muted-foreground font-medium">Status</th>
                  <th className="text-right px-4 py-3 text-muted-foreground font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {pagedSmtps.map((smtp) => (
                  <tr key={smtp.id} className="border-b border-border/50 last:border-0 hover:bg-muted/20">
                    <td className="px-4 py-3">
                      <div className="font-medium text-foreground">{smtp.label || smtp.host}</div>
                      {smtp.label && <div className="text-xs text-muted-foreground">{smtp.host}</div>}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{smtp.port}</td>
                    <td className="px-4 py-3 text-muted-foreground font-mono text-xs">{smtp.user}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium status-badge-${smtp.status ?? "untested"}`}>
                        {smtp.status ?? "untested"}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex gap-2 justify-end">
                        <Button size="sm" variant="outline" onClick={() => { setTestOpen(smtp.id); setTestEmail(""); }}>Test</Button>
                        <Button size="sm" variant="destructive" onClick={() => handleDelete(smtp.id)}>Delete</Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {hasMore && (
              <div className="p-3 border-t border-border text-center">
                <button
                  onClick={() => setPage(p => p + 1)}
                  className="text-xs text-muted-foreground hover:text-foreground underline-offset-2 hover:underline transition-colors"
                >
                  Showing {pagedSmtps.length} of {totalSmtps} — load {Math.min(PAGE_SIZE, totalSmtps - pagedSmtps.length)} more
                </button>
              </div>
            )}
          </>
        ) : (
          <div className="p-12 text-center text-muted-foreground">
            <p className="text-base font-medium">No SMTPs configured</p>
            <p className="text-sm mt-1">Add individual servers or import a file in bulk</p>
          </div>
        )}
      </div>

      {/* Add SMTP Dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="bg-card border-border">
          <DialogHeader><DialogTitle>Add SMTP Server</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div><Label>Label (optional)</Label><Input className="mt-1" value={form.label} onChange={e => setForm(f => ({ ...f, label: e.target.value }))} placeholder="My SMTP" /></div>
            <div><Label>Host *</Label><Input className="mt-1" value={form.host} onChange={e => setForm(f => ({ ...f, host: e.target.value }))} placeholder="mail.example.com" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Port *</Label><Input className="mt-1" value={form.port} onChange={e => setForm(f => ({ ...f, port: e.target.value }))} placeholder="465" /></div>
              <div className="flex items-end gap-2 pb-0.5">
                <Switch checked={form.secure} onCheckedChange={v => setForm(f => ({ ...f, secure: v }))} />
                <Label>SSL/TLS</Label>
              </div>
            </div>
            <div><Label>Username *</Label><Input className="mt-1" value={form.user} onChange={e => setForm(f => ({ ...f, user: e.target.value }))} placeholder="user@mail.com" /></div>
            <div><Label>Password *</Label><Input className="mt-1" type="password" value={form.pass} onChange={e => setForm(f => ({ ...f, pass: e.target.value }))} placeholder="••••••••" /></div>
            <p className="text-xs text-muted-foreground">Port auto-fallback: if 465 fails, 587 is tried automatically (and vice versa) during testing.</p>
            <p className="text-xs text-muted-foreground">Saving checks the SMTP connection and credentials only. It does not send an email.</p>
            <Button className="w-full" onClick={handleAdd} disabled={createSmtp.isPending}>
              {createSmtp.isPending ? "Adding..." : "Add SMTP"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Import Dialog */}
      <Dialog open={importOpen} onOpenChange={setImportOpen}>
        <DialogContent className="bg-card border-border max-w-2xl">
          <DialogHeader><DialogTitle>Import SMTPs</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <p className="text-xs text-muted-foreground whitespace-pre-line">{IMPORT_HINT}</p>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" className="text-xs" onClick={() => importFileRef.current?.click()}>
              Load from file (large files are uploaded in batches)
              </Button>
              <span className="text-xs text-muted-foreground self-center">or paste below</span>
            </div>
            <Textarea
              className="font-mono text-xs h-48 resize-none"
              value={importRaw}
              onChange={e => setImportRaw(e.target.value)}
              placeholder="Paste SMTP credentials here, one per line..."
            />
            {importProgress && (
              <p className="text-xs text-muted-foreground">
                Batch {importProgress.current}/{importProgress.total} — {importProgress.imported.toLocaleString()} imported, {importProgress.failed.toLocaleString()} failed
              </p>
            )}
            <Button className="w-full" onClick={handleImport} disabled={!!importProgress || importSmtps.isPending || !importRaw.trim()}>
              {importProgress ? `Importing ${importProgress.current}/${importProgress.total}...` : importSmtps.isPending ? "Importing..." : "Import"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Test Single Dialog */}
      <Dialog open={testOpen !== null} onOpenChange={() => setTestOpen(null)}>
        <DialogContent className="bg-card border-border">
          <DialogHeader><DialogTitle>Test SMTP Delivery</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <p className="text-xs text-muted-foreground">
              Port auto-fallback is enabled — if the configured port fails, the alternative port (587↔465) will be tried automatically.
            </p>
            <div><Label>Send test email to</Label><Input className="mt-1" value={testEmail} onChange={e => setTestEmail(e.target.value)} placeholder="test@example.com" type="email" /></div>
            <Button className="w-full" onClick={handleTest} disabled={!testEmail || testingId !== null}>
              {testingId !== null ? "Sending..." : "Send Test Email"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Test All Dialog — polling-based live progress */}
      <Dialog
        open={testAllOpen}
        onOpenChange={v => {
          if (!v && testingAll) return; // block close while running
          setTestAllOpen(v);
          if (!v) { stopPolling(); setJob(null); }
        }}
      >
        <DialogContent className="bg-card border-border max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Test All SMTPs ({totalSmtps})</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <p className="text-xs text-muted-foreground">
              Tests up to 32 SMTPs at a time with short connection timeouts and port auto-fallback (587↔465).
              One test email is sent from each SMTP to the address below.
            </p>

            <div className="flex gap-2">
              <Input
                className="flex-1"
                value={testAllEmail}
                onChange={e => setTestAllEmail(e.target.value)}
                placeholder="Delivery test email address..."
                type="email"
                disabled={testingAll}
              />
              <Button
                onClick={() => { void handleTestAll(); }}
                disabled={!testAllEmail || testingAll}
                className="bg-green-600 hover:bg-green-700 text-white shrink-0"
              >
                {testingAll ? "Testing…" : "Start Test"}
              </Button>
            </div>

            {/* Live progress bar */}
            {job && !job.done && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>
                    Testing {job.completed} / {job.total}…
                    <span className="ml-2 animate-pulse">●</span>
                  </span>
                  <span className="font-mono font-medium">{progressPct}%</span>
                </div>
                <div className="h-2.5 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-green-500 rounded-full transition-all duration-700"
                    style={{ width: `${progressPct}%` }}
                  />
                </div>
                <div className="flex gap-4 text-xs">
                  <span className="text-green-400 font-medium">✓ {job.passed} passed</span>
                  <span className="text-red-400 font-medium">✗ {job.failed} failed</span>
                  <span className="text-muted-foreground">{Math.max(0, job.total - job.completed)} remaining</span>
                </div>
              </div>
            )}

            {/* Summary + Retry Failed once done */}
            {job?.done && (
              <div className="space-y-3">
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-muted/30 rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-foreground">{job.total}</div>
                    <div className="text-xs text-muted-foreground mt-1">Tested</div>
                  </div>
                  <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-green-400">{job.passed}</div>
                    <div className="text-xs text-muted-foreground mt-1">Passed</div>
                  </div>
                  <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-red-400">{job.failed}</div>
                    <div className="text-xs text-muted-foreground mt-1">Failed</div>
                  </div>
                </div>
                {job.failed > 0 && (
                  <Button
                    variant="outline"
                    onClick={() => handleTestAll(job.failedIds)}
                    disabled={testingAll}
                    className="w-full text-orange-400 border-orange-500/40 hover:bg-orange-500/10"
                  >
                    Retry Failed ({job.failed})
                  </Button>
                )}
              </div>
            )}

            {/* Results table — fills in live */}
            {job && job.results.length > 0 && (
              <div className="border border-border rounded-lg overflow-hidden">
                <div className="border-b border-border px-3 py-2 text-[11px] text-muted-foreground">
                  Showing the {job.results.length} most recent results. Completion totals include every SMTP.
                </div>
                <div className="max-h-64 overflow-y-auto">
                  <table className="w-full text-xs">
                    <thead className="bg-muted/30 border-b border-border sticky top-0">
                      <tr>
                        <th className="text-left px-3 py-2 text-muted-foreground font-medium">Host / Label</th>
                        <th className="text-left px-3 py-2 text-muted-foreground font-medium">User</th>
                        <th className="text-left px-3 py-2 text-muted-foreground font-medium">Port</th>
                        <th className="text-left px-3 py-2 text-muted-foreground font-medium">Result</th>
                      </tr>
                    </thead>
                    <tbody>
                      {job.results.map((r) => (
                        <tr key={r.id} className="border-b border-border/50 last:border-0">
                          <td className="px-3 py-2 text-foreground">{r.label || r.host}</td>
                          <td className="px-3 py-2 text-muted-foreground font-mono truncate max-w-[120px]">{r.user}</td>
                          <td className="px-3 py-2 text-muted-foreground">{r.usedPort}</td>
                          <td className="px-3 py-2">
                            {r.success
                               ? <span className="text-green-400 font-medium" title={r.response || r.messageId || "Accepted by SMTP relay"}>✓ Accepted</span>
                               : <span className="text-red-400" title={r.error || "SMTP test failed"}>✗ {r.error || "Failed"}</span>
                            }
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
