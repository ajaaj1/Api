import { useState } from "react";
import { CheckCircle2, CircleAlert, Mail, Pencil, Plus, Send, Server, Trash2 } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { getListSmtpsQueryKey, useCreateSmtp, useDeleteSmtp, useListSmtps, useTestSmtp, useUpdateSmtp } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";

type AccountForm = { label: string; host: string; port: string; user: string; pass: string; secure: boolean };
const blank: AccountForm = { label: "", host: "", port: "465", user: "", pass: "", secure: true };
const presets: Record<string, Partial<AccountForm>> = {
  custom: {},
  gmail: { host: "smtp.gmail.com", port: "465", secure: true },
  outlook: { host: "smtp-mail.outlook.com", port: "587", secure: false },
};

export default function DirectEmail() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: accounts, isLoading, isError, refetch } = useListSmtps();
  const createAccount = useCreateSmtp();
  const updateAccount = useUpdateSmtp();
  const deleteAccount = useDeleteSmtp();
  const testAccount = useTestSmtp();
  const [accountOpen, setAccountOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<AccountForm>(blank);
  const [preset, setPreset] = useState("custom");
  const [testId, setTestId] = useState<number | null>(null);
  const [testEmail, setTestEmail] = useState("");
  const [result, setResult] = useState<{ ok: boolean; message: string; details?: string | null } | null>(null);
  const refresh = () => qc.invalidateQueries({ queryKey: getListSmtpsQueryKey() });
  const change = (key: keyof AccountForm, value: string | boolean) => setForm((current) => ({ ...current, [key]: value }));

  function pickPreset(value: string) {
    setPreset(value);
    setForm((current) => ({ ...current, ...presets[value], label: value === "custom" ? current.label : value === "gmail" ? "Gmail mailbox" : "Outlook mailbox" }));
  }
  function openCreate() { setEditingId(null); setPreset("custom"); setForm(blank); setAccountOpen(true); }
  function openEdit(account: any) { setEditingId(account.id); setPreset("custom"); setForm({ label: account.label ?? "", host: account.host, port: String(account.port), user: account.user, pass: "", secure: account.secure ?? account.port === 465 }); setAccountOpen(true); }
  function saveAccount() {
    if (!form.host || !form.user || (!editingId && !form.pass)) { toast({ title: "Host, username and password are required", variant: "destructive" }); return; }
    const data: any = { label: form.label || undefined, host: form.host, port: Number(form.port), user: form.user, secure: form.secure };
    if (form.pass) data.pass = form.pass;
    const onSuccess = () => { refresh(); setAccountOpen(false); toast({ title: editingId ? "Mailbox updated" : "Mailbox added" }); };
    const onError = (error: any) => toast({ title: "Could not save mailbox", description: error.message, variant: "destructive" });
    if (editingId) updateAccount.mutate({ id: editingId, data }, { onSuccess, onError });
    else createAccount.mutate({ data: { ...data, pass: form.pass } }, { onSuccess, onError });
  }
  function removeAccount(id: number) {
    if (!confirm("Delete this mailbox account?")) return;
    deleteAccount.mutate({ id }, { onSuccess: () => { refresh(); toast({ title: "Mailbox deleted" }); }, onError: (error: any) => toast({ title: "Could not delete mailbox", description: error.message, variant: "destructive" }) });
  }
  function test() {
    if (!testId || !testEmail) return;
    testAccount.mutate({ id: testId, data: { toEmail: testEmail, fromName: "Danewbreed Sender Pro" } }, { onSuccess: (response) => { const value = response as any; setResult({ ok: value.success, message: value.message, details: value.details }); setTestId(null); refresh(); }, onError: (error: any) => setResult({ ok: false, message: error.message }) });
  }

  return (
    <div className="mx-auto max-w-6xl space-y-7" data-testid="page-direct-email">
      <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between"><div><div className="mb-3 flex items-center gap-2 text-xs font-medium uppercase tracking-[0.18em] text-primary"><Server className="h-4 w-4" /> Direct mailbox</div><h2 className="text-3xl font-semibold tracking-tight">Send from an email account</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">Use a mailbox you control with SMTP and an app password. Add custom servers, Gmail, or Outlook accounts, test them, then select them as a direct sender in email campaigns.</p></div><Button onClick={openCreate} data-testid="button-add-direct-account"><Plus className="mr-2 h-4 w-4" /> Add email account</Button></div>
      <div className="grid gap-4 lg:grid-cols-[1.35fr_0.65fr]"><div className="rounded-2xl border border-primary/20 bg-primary/5 p-5"><div className="flex gap-3"><CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-primary" /><div><div className="font-medium">Credentials stay provider-specific</div><p className="mt-1 text-sm leading-6 text-muted-foreground">Use an SMTP app password rather than your everyday mailbox password whenever the provider supports it. Danewbreed tests the connection by delivering a real message.</p></div></div></div><div className="rounded-2xl border border-border bg-[#f4ead3] p-5 text-[#5f4930]"><div className="text-xs font-semibold uppercase tracking-wider opacity-70">Available presets</div><div className="mt-3 flex gap-2 text-sm font-medium"><span>Custom</span><span className="opacity-40">/</span><span>Gmail</span><span className="opacity-40">/</span><span>Outlook</span></div></div></div>
      {result && <div className={`flex items-start gap-3 rounded-xl border p-4 ${result.ok ? "border-primary/30 bg-primary/5" : "border-destructive/30 bg-destructive/5"}`} data-testid="status-direct-email-result">{result.ok ? <CheckCircle2 className="h-5 w-5 text-primary" /> : <CircleAlert className="h-5 w-5 text-destructive" />}<div className="flex-1"><div className="font-medium">{result.ok ? "Mailbox accepted the test" : "Mailbox test failed"}</div><div className="mt-1 text-sm text-muted-foreground">{result.message}</div>{result.details && <div className="mt-1 text-xs text-muted-foreground">{result.details}</div>}</div><button className="text-xs underline" onClick={() => setResult(null)} data-testid="button-dismiss-direct-result">Dismiss</button></div>}
      <div className="overflow-hidden rounded-2xl border border-border bg-card"><div className="border-b border-border bg-muted/40 px-5 py-4"><div className="font-medium">Email accounts</div><div className="mt-1 text-xs text-muted-foreground">{accounts?.length ?? 0} account{accounts?.length === 1 ? "" : "s"} available for direct sending</div></div>{isLoading ? <div className="space-y-3 p-5"><div className="h-14 animate-pulse rounded-lg bg-muted" /><div className="h-14 animate-pulse rounded-lg bg-muted" /></div> : isError ? <div className="p-10 text-center"><CircleAlert className="mx-auto h-8 w-8 text-destructive" /><p className="mt-3 font-medium">Could not load mailbox accounts</p><Button variant="outline" className="mt-4" onClick={() => refetch()} data-testid="button-retry-direct">Retry</Button></div> : accounts && accounts.length > 0 ? <div className="divide-y divide-border">{accounts.map((account) => <div key={account.id} className="flex flex-col gap-4 px-5 py-5 md:flex-row md:items-center md:justify-between" data-testid={`row-direct-account-${account.id}`}><div className="flex items-center gap-4"><div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/20 text-[#925b17]"><Mail className="h-5 w-5" /></div><div><div className="font-medium">{account.label || account.host}</div><div className="mt-1 font-mono text-xs text-muted-foreground">{account.user} · {account.host}:{account.port}</div><span className={`mt-2 inline-flex rounded-full border px-2 py-0.5 text-xs font-medium ${account.status === "verified" ? "status-badge-verified" : account.status === "failed" ? "status-badge-failed" : "status-badge-untested"}`} data-testid={`status-direct-account-${account.id}`}>{account.status ?? "untested"}</span></div></div><div className="flex flex-wrap gap-2 md:justify-end"><Button size="sm" variant="outline" onClick={() => { setTestId(account.id); setTestEmail(""); }} data-testid={`button-test-direct-${account.id}`}><Send className="mr-1.5 h-3.5 w-3.5" /> Send test</Button><Button size="sm" variant="ghost" onClick={() => openEdit(account)} data-testid={`button-edit-direct-${account.id}`}><Pencil className="mr-1.5 h-3.5 w-3.5" /> Edit</Button><Button size="sm" variant="ghost" className="text-destructive hover:text-destructive" onClick={() => removeAccount(account.id)} data-testid={`button-delete-direct-${account.id}`}><Trash2 className="h-3.5 w-3.5" /></Button></div></div>)}</div> : <div className="p-12 text-center"><Mail className="mx-auto h-8 w-8 text-muted-foreground" /><p className="mt-3 font-medium">No mailbox accounts connected</p><p className="mt-1 text-sm text-muted-foreground">Add an SMTP account to make direct sending available.</p><Button className="mt-5" onClick={openCreate} data-testid="button-empty-add-direct">Add email account</Button></div>}</div>
      <div className="flex flex-col gap-3 rounded-xl border border-border bg-card p-4 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between"><span>Need a lead audience or a full content workflow?</span><Link href="/campaigns" className="font-medium text-primary hover:underline" data-testid="link-direct-campaigns">Open email campaigns</Link></div>

      <Dialog open={accountOpen} onOpenChange={setAccountOpen}><DialogContent className="max-w-lg"><DialogHeader><DialogTitle>{editingId ? "Edit email account" : "Add email account"}</DialogTitle></DialogHeader><div className="space-y-4 pt-2"><div><Label>Account preset</Label><div className="mt-2 grid grid-cols-3 gap-2">{(["custom", "gmail", "outlook"] as const).map((value) => <button key={value} type="button" onClick={() => pickPreset(value)} className={`rounded-lg border px-3 py-2 text-left text-sm capitalize transition-colors ${preset === value ? "border-primary bg-primary/10 text-primary" : "border-border hover:bg-muted"}`} data-testid={`button-preset-${value}`}><div className="font-medium">{value}</div><div className="mt-1 text-xs text-muted-foreground">{value === "custom" ? "Any SMTP host" : "App password"}</div></button>)}</div></div><div><Label>Label</Label><Input className="mt-1" value={form.label} onChange={(event) => change("label", event.target.value)} placeholder="Operations inbox" data-testid="input-direct-label" /></div><div><Label>SMTP host *</Label><Input className="mt-1 font-mono text-sm" value={form.host} onChange={(event) => change("host", event.target.value)} placeholder="smtp.example.com" data-testid="input-direct-host" /></div><div className="grid grid-cols-2 gap-3"><div><Label>Port *</Label><Input className="mt-1" type="number" value={form.port} onChange={(event) => change("port", event.target.value)} data-testid="input-direct-port" /></div><div className="flex items-end gap-2 pb-2"><Switch checked={form.secure} onCheckedChange={(value) => change("secure", value)} data-testid="switch-direct-secure" /><Label>SSL/TLS</Label></div></div><div><Label>Username *</Label><Input className="mt-1" type="email" value={form.user} onChange={(event) => change("user", event.target.value)} placeholder="you@company.com" data-testid="input-direct-user" /></div><div><Label>{editingId ? "New app password (optional)" : "App password *"}</Label><Input className="mt-1" type="password" value={form.pass} onChange={(event) => change("pass", event.target.value)} placeholder="Provider-generated app password" data-testid="input-direct-password" /></div><p className="rounded-lg border border-border bg-muted/40 p-3 text-xs leading-5 text-muted-foreground">Gmail and Outlook commonly require an app password or OAuth-approved SMTP password. Do not use a normal account password if the provider blocks it.</p><Button className="w-full" onClick={saveAccount} disabled={createAccount.isPending || updateAccount.isPending} data-testid="button-save-direct">{createAccount.isPending || updateAccount.isPending ? "Saving account..." : editingId ? "Save changes" : "Add account"}</Button></div></DialogContent></Dialog>
      <Dialog open={testId !== null} onOpenChange={() => setTestId(null)}><DialogContent className="max-w-md"><DialogHeader><DialogTitle>Test mailbox delivery</DialogTitle></DialogHeader><div className="space-y-4 pt-2"><p className="text-sm leading-6 text-muted-foreground">This sends a real test message using the saved SMTP credentials and updates the account status.</p><div><Label>Test recipient *</Label><Input className="mt-1" type="email" value={testEmail} onChange={(event) => setTestEmail(event.target.value)} placeholder="operator@example.com" data-testid="input-direct-test-to" /></div><Button className="w-full" onClick={test} disabled={!testEmail || testAccount.isPending} data-testid="button-submit-direct-test">{testAccount.isPending ? "Sending test..." : "Send test message"}</Button></div></DialogContent></Dialog>
    </div>
  );
}