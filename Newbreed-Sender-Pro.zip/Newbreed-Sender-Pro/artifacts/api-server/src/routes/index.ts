import { Router, type IRouter } from "express";
import healthRouter from "./health";
import smtpRouter from "./smtp";
import awsRouter from "./aws";
import sendgridRouter from "./sendgrid";
import resendRouter from "./resend";
import smsRouter from "./sms";
import leadsRouter from "./leads";
import campaignsRouter from "./campaigns";
import deliveriesRouter from "./deliveries";
import proxiesRouter from "./proxies";
import htmlRouter from "./html";
import warmupRouter from "./warmup";
import deliverabilityRouter from "./deliverability";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/smtp", smtpRouter);
router.use("/aws", awsRouter);
router.use("/sendgrid", sendgridRouter);
router.use("/resend", resendRouter);
router.use("/sms", smsRouter);
router.use("/leads", leadsRouter);
router.use("/campaigns", campaignsRouter);
router.use("/deliveries", deliveriesRouter);
router.use("/proxies", proxiesRouter);
router.use("/html", htmlRouter);
router.use("/warmup", warmupRouter);
router.use("/deliverability", deliverabilityRouter);

export default router;
