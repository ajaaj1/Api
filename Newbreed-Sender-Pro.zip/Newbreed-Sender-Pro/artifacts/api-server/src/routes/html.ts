import { Router } from "express";

const router = Router();

router.post("/debug", async (req, res) => {
  const { html } = req.body;
  if (!html) return res.status(400).json({ error: "html required" });

  const issues: string[] = [];
  const warnings: string[] = [];
  let fixed = html;

  // Check for doctype
  if (!html.includes("<!DOCTYPE") && !html.includes("<!doctype")) {
    issues.push("Missing <!DOCTYPE html> declaration");
    fixed = "<!DOCTYPE html>\n" + fixed;
  }

  // Check for html tag
  if (!html.includes("<html")) {
    issues.push("Missing <html> root element");
    warnings.push("Email clients may render without <html> tag but it's best practice to include it");
  }

  // Check for charset meta tag
  if (!html.includes('charset') && !html.includes('Content-Type')) {
    issues.push("Missing charset meta tag");
    const headMatch = fixed.match(/<head[^>]*>/i);
    if (headMatch) {
      fixed = fixed.replace(/<head[^>]*>/i, `${headMatch[0]}\n  <meta charset="UTF-8">`);
    }
  }

  // Check for viewport meta
  if (!html.includes('viewport')) {
    warnings.push("Missing viewport meta tag (recommended for mobile email clients)");
  }

  // Check for inline styles (email clients strip CSS)
  const styleSheets = html.match(/<link[^>]+stylesheet[^>]+>/gi);
  if (styleSheets && styleSheets.length > 0) {
    issues.push("External CSS stylesheets detected - email clients strip external CSS. Use inline styles.");
  }

  // Check for script tags
  const scripts = html.match(/<script[^>]*>/gi);
  if (scripts && scripts.length > 0) {
    issues.push("JavaScript <script> tags detected - email clients block JavaScript");
    fixed = fixed.replace(/<script[\s\S]*?<\/script>/gi, "<!-- scripts removed for email compatibility -->");
  }

  // Check for table-based layout (recommended for email)
  if (!html.includes('<table') && html.includes('<div')) {
    warnings.push("Consider using table-based layout for maximum email client compatibility");
  }

  // Check for images without alt text
  const imgsWithoutAlt = (html.match(/<img(?![^>]*alt=)[^>]*>/gi) || []).length;
  if (imgsWithoutAlt > 0) {
    warnings.push(`${imgsWithoutAlt} image(s) missing alt attribute`);
  }

  // Check for unsubscribe link
  if (!html.toLowerCase().includes('unsubscribe')) {
    warnings.push("No unsubscribe link found - required by CAN-SPAM and GDPR");
  }

  // Check for large images
  const base64Images = (html.match(/data:image\/[^;]+;base64,[A-Za-z0-9+/]+=*/g) || []);
  if (base64Images.length > 0) {
    warnings.push(`${base64Images.length} base64 embedded image(s) found - can increase email size and trigger spam filters`);
  }

  // Fix unclosed tags
  const unclosedB = (html.match(/<b(?:\s[^>]*)?>/gi) || []).length;
  const closedB = (html.match(/<\/b>/gi) || []).length;
  if (unclosedB !== closedB) {
    issues.push(`Mismatched <b> tags (${unclosedB} open, ${closedB} close)`);
  }

  // Check for broken links
  const links = html.match(/href="([^"]+)"/gi) || [];
  const brokenLinks = links.filter(l => {
    const url = l.replace(/href="/i, "").replace(/"$/, "");
    return url && !url.startsWith("http") && !url.startsWith("mailto:") && !url.startsWith("#") && !url.startsWith("{{");
  });
  if (brokenLinks.length > 0) {
    warnings.push(`Potentially broken links: ${brokenLinks.slice(0, 3).join(", ")}`);
  }

  res.json({ issues, warnings, fixed });
});

export default router;
