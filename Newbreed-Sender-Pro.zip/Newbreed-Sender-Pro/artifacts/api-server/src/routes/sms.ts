import { Router } from "express";
import { db, smsConfigsTable, awsConfigsTable, smtpsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { SNSClient, PublishCommand } from "@aws-sdk/client-sns";
import nodemailer from "nodemailer";
import { detectCarrierGateway, toSmsGatewayEmail } from "../carrier-lookup";
import { resolveTwilioSenderNumber, verifyTwilioAccount } from "../lib/twilio";

const router = Router();

// ─── Helpers ─────────────────────────────────────────────────────────────────

async function sendSmtpSms(smtpId: number, gatewayDomain: string, toNumber: string, message: string) {
  // "auto" = detect carrier from area code
  const resolvedDomain = gatewayDomain === "auto"
    ? detectCarrierGateway(toNumber).gateway
    : gatewayDomain;
  const to = toSmsGatewayEmail(toNumber, resolvedDomain);
  const [smtp] = await db.select().from(smtpsTable).where(eq(smtpsTable.id, smtpId));
  if (!smtp) throw new Error("SMTP config not found");
  const transporter = nodemailer.createTransport({
    host: smtp.host,
    port: smtp.port,
    secure: smtp.secure ?? true,
    auth: { user: smtp.user, pass: smtp.pass },
    tls: { rejectUnauthorized: false },
    connectionTimeout: 15000,
  });
  await transporter.sendMail({ from: smtp.user, to, subject: "", text: message });
  return to;
}

function safeSmsConfig(row: any) {
  return {
    ...row,
    apiKey: row.apiKey ? "***" + row.apiKey.slice(-4) : row.apiKey,
    authToken: row.authToken ? "***" + row.authToken.slice(-4) : row.authToken,
  };
}

async function autoVerifyTwilioConfig(id: number, cfg: any) {
  if (cfg.provider !== "twilio" || !cfg.accountSid) return null;
  const verification = await verifyTwilioAccount(cfg.accountSid, cfg.authToken, cfg.fromNumber);
  const updates: Record<string, any> = {
    status: verification.success ? "verified" : verification.incomplete ? "untested" : "failed",
  };
  if (verification.success && !cfg.fromNumber && verification.fromNumber) {
    updates.fromNumber = verification.fromNumber;
  }
  await db.update(smsConfigsTable).set(updates).where(eq(smsConfigsTable.id, id));
  return verification;
}

// ─── CRUD ────────────────────────────────────────────────────────────────────

router.get("/configs", async (_req, res) => {
  const rows = await db.select().from(smsConfigsTable).orderBy(smsConfigsTable.createdAt);
  res.json(rows.map(safeSmsConfig));
});

router.post("/configs", async (req, res) => {
  const { label, provider, apiKey, accountSid, authToken, fromNumber, awsConfigId, smtpId, gatewayDomain } = req.body;
  if (!provider) return res.status(400).json({ error: "provider required" });
  const [row] = await db.insert(smsConfigsTable).values({
    label, provider, apiKey, accountSid, authToken, fromNumber,
    awsConfigId: awsConfigId ?? null,
    smtpId: smtpId ?? null,
    gatewayDomain: gatewayDomain ?? null,
  }).returning();
  const verification = provider === "twilio" ? await autoVerifyTwilioConfig(row.id, row) : null;
  const [updated] = await db.select().from(smsConfigsTable).where(eq(smsConfigsTable.id, row.id));
  res.status(201).json({ ...safeSmsConfig(updated), ...(verification ? { verification } : {}) });
});

router.patch("/configs/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const { label, apiKey, accountSid, authToken, fromNumber, awsConfigId, smtpId, gatewayDomain } = req.body;
  const updates: Record<string, any> = {};
  if (label !== undefined) updates.label = label;
  if (apiKey !== undefined) updates.apiKey = apiKey;
  if (accountSid !== undefined) updates.accountSid = accountSid;
  if (authToken !== undefined) updates.authToken = authToken;
  if (fromNumber !== undefined) updates.fromNumber = fromNumber;
  if (awsConfigId !== undefined) updates.awsConfigId = awsConfigId;
  if (smtpId !== undefined) updates.smtpId = smtpId;
  if (gatewayDomain !== undefined) updates.gatewayDomain = gatewayDomain;
  const [row] = await db.update(smsConfigsTable).set(updates).where(eq(smsConfigsTable.id, id)).returning();
  if (!row) return res.status(404).json({ error: "Not found" });
  const verification = row.provider === "twilio" ? await autoVerifyTwilioConfig(row.id, row) : null;
  const [updated] = await db.select().from(smsConfigsTable).where(eq(smsConfigsTable.id, id));
  res.json({ ...safeSmsConfig(updated), ...(verification ? { verification } : {}) });
});

router.delete("/configs/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  await db.delete(smsConfigsTable).where(eq(smsConfigsTable.id, id));
  res.status(204).send();
});

// ─── Test ────────────────────────────────────────────────────────────────────

router.post("/configs/:id/test", async (req, res) => {
  const id = parseInt(req.params.id);
  const [cfg] = await db.select().from(smsConfigsTable).where(eq(smsConfigsTable.id, id));
  if (!cfg) return res.status(404).json({ error: "Not found" });

  const { toNumber, message } = req.body;
  if (!toNumber) return res.status(400).json({ error: "toNumber required" });

  try {
    if (cfg.provider === "twilio") {
      if (!cfg.accountSid || !cfg.authToken) return res.json({ success: false, message: "Twilio requires accountSid and authToken" });
      const fromNumber = await resolveTwilioSenderNumber(cfg.accountSid, cfg.authToken, cfg.fromNumber);
      if (!cfg.fromNumber) {
        await db.update(smsConfigsTable).set({ fromNumber }).where(eq(smsConfigsTable.id, id));
      }
      const url = `https://api.twilio.com/2010-04-01/Accounts/${cfg.accountSid}/Messages.json`;
      const body = new URLSearchParams({
        To: toNumber, From: fromNumber, Body: message || "Test SMS from Danewbreed Sender Pro",
      });
      const r = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: "Basic " + Buffer.from(`${cfg.accountSid}:${cfg.authToken}`).toString("base64"),
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body,
      });
      const data = await r.json() as any;
      if (r.ok) {
        await db.update(smsConfigsTable).set({ status: "verified" }).where(eq(smsConfigsTable.id, id));
        res.json({ success: true, message: `SMS sent via Twilio: ${data.sid}` });
      } else {
        await db.update(smsConfigsTable).set({ status: "failed" }).where(eq(smsConfigsTable.id, id));
        res.json({ success: false, message: data.message || "Twilio error" });
      }
    } else if (cfg.provider === "aws_sns") {
      const awsCfg = cfg.awsConfigId ? (await db.select().from(awsConfigsTable).where(eq(awsConfigsTable.id, cfg.awsConfigId)))[0] : null;
      if (!awsCfg) return res.json({ success: false, message: "AWS config not found" });
      const sns = new SNSClient({
        region: awsCfg.region,
        credentials: { accessKeyId: awsCfg.accessKeyId, secretAccessKey: awsCfg.secretAccessKey },
      });
      const result = await sns.send(new PublishCommand({ PhoneNumber: toNumber, Message: message || "Test SMS" }));
      await db.update(smsConfigsTable).set({ status: "verified" }).where(eq(smsConfigsTable.id, id));
      res.json({ success: true, message: `SMS sent via AWS SNS: ${result.MessageId}` });
    } else if (cfg.provider === "smtp_sms") {
      if (!cfg.smtpId || !cfg.gatewayDomain) return res.json({ success: false, message: "SMTP-to-SMS requires an SMTP server and gateway domain" });
      const to = await sendSmtpSms(cfg.smtpId, cfg.gatewayDomain, toNumber, message || "Test SMS from Danewbreed Sender Pro");
      await db.update(smsConfigsTable).set({ status: "verified" }).where(eq(smsConfigsTable.id, id));
      res.json({ success: true, message: `Test SMS sent via SMTP gateway to ${to}` });
    } else {
      res.json({ success: false, message: `Provider '${cfg.provider}' test not supported` });
    }
  } catch (e: any) {
    await db.update(smsConfigsTable).set({ status: "failed" }).where(eq(smsConfigsTable.id, id));
    res.json({ success: false, message: e.message });
  }
});

// ─── Send ─────────────────────────────────────────────────────────────────────

router.post("/send", async (req, res) => {
  const { configId, toNumber, message } = req.body;
  if (!configId || !toNumber || !message) return res.status(400).json({ error: "configId, toNumber, message required" });

  const [cfg] = await db.select().from(smsConfigsTable).where(eq(smsConfigsTable.id, configId));
  if (!cfg) return res.status(404).json({ error: "SMS config not found" });

  try {
    if (cfg.provider === "twilio") {
      const fromNumber = await resolveTwilioSenderNumber(cfg.accountSid || "", cfg.authToken, cfg.fromNumber);
      if (!cfg.fromNumber) {
        await db.update(smsConfigsTable).set({ fromNumber }).where(eq(smsConfigsTable.id, configId));
      }
      const url = `https://api.twilio.com/2010-04-01/Accounts/${cfg.accountSid}/Messages.json`;
      const body = new URLSearchParams({ To: toNumber, From: fromNumber, Body: message });
      const r = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: "Basic " + Buffer.from(`${cfg.accountSid}:${cfg.authToken}`).toString("base64"),
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body,
      });
      const data = await r.json() as any;
      if (r.ok) return res.json({ success: true, message: "SMS sent", messageId: data.sid });
      return res.json({ success: false, message: data.message, messageId: null });
    } else if (cfg.provider === "aws_sns") {
      const awsCfg = cfg.awsConfigId ? (await db.select().from(awsConfigsTable).where(eq(awsConfigsTable.id, cfg.awsConfigId)))[0] : null;
      if (!awsCfg) return res.json({ success: false, message: "AWS config not found", messageId: null });
      const sns = new SNSClient({
        region: awsCfg.region,
        credentials: { accessKeyId: awsCfg.accessKeyId, secretAccessKey: awsCfg.secretAccessKey },
      });
      const result = await sns.send(new PublishCommand({ PhoneNumber: toNumber, Message: message }));
      return res.json({ success: true, message: "SMS sent via AWS SNS", messageId: result.MessageId || null });
    } else if (cfg.provider === "smtp_sms") {
      if (!cfg.smtpId || !cfg.gatewayDomain) return res.json({ success: false, message: "SMTP-to-SMS config missing smtpId or gatewayDomain", messageId: null });
      const to = await sendSmtpSms(cfg.smtpId, cfg.gatewayDomain, toNumber, message);
      return res.json({ success: true, message: `Sent via SMTP gateway to ${to}`, messageId: null });
    }
    res.json({ success: false, message: `Provider '${cfg.provider}' send not implemented`, messageId: null });
  } catch (e: any) {
    res.json({ success: false, message: e.message, messageId: null });
  }
});

export default router;
