import { Router } from "express";
import { db, resendConfigsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { ReplitConnectors } from "@replit/connectors-sdk";
import { createCipheriv, createDecipheriv, createHash, randomBytes } from "node:crypto";

const router = Router();

type ResendResponse = {
  id?: string;
  message?: string;
  name?: string;
  statusCode?: number;
  data?: Array<{ name?: string; status?: string }>;
};
const RESEND_API_URL = "https://api.resend.com";
const ENCRYPTION_ALGORITHM = "aes-256-gcm";

function encryptionKey(): Buffer {
  const secret = process.env.SESSION_SECRET;
  if (!secret) throw new Error("SESSION_SECRET is required to use stored Resend API keys");
  return createHash("sha256").update(secret).digest();
}

function encryptApiKey(apiKey: string): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv(ENCRYPTION_ALGORITHM, encryptionKey(), iv);
  const ciphertext = Buffer.concat([cipher.update(apiKey, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `v1:${iv.toString("base64")}:${tag.toString("base64")}:${ciphertext.toString("base64")}`;
}

function decryptApiKey(value: string): string {
  const [version, ivValue, tagValue, ciphertextValue] = value.split(":");
  if (version !== "v1" || !ivValue || !tagValue || !ciphertextValue) {
    throw new Error("Stored Resend API key has an unsupported format");
  }
  const decipher = createDecipheriv(
    ENCRYPTION_ALGORITHM,
    encryptionKey(),
    Buffer.from(ivValue, "base64"),
  );
  decipher.setAuthTag(Buffer.from(tagValue, "base64"));
  return Buffer.concat([
    decipher.update(Buffer.from(ciphertextValue, "base64")),
    decipher.final(),
  ]).toString("utf8");
}

function publicConfig(row: typeof resendConfigsTable.$inferSelect) {
  const { apiKeyEncrypted: _apiKeyEncrypted, ...safe } = row;
  return { ...safe, apiKeyConfigured: Boolean(row.apiKeyEncrypted) };
}

async function resendRequest(
  path: string,
  init: { method: string; headers?: Record<string, string>; body?: string },
  apiKey?: string,
): Promise<{ response: Response; body: ResendResponse }> {
  const response = apiKey
    ? await fetch(`${RESEND_API_URL}${path}`, {
      ...init,
      headers: { ...init.headers, Authorization: `Bearer ${apiKey}` },
    })
    : await new ReplitConnectors().proxy("resend", path, init);
  const text = await response.text();
  let body: ResendResponse = {};
  try {
    body = text ? JSON.parse(text) as ResendResponse : {};
  } catch {
    body = { message: text || response.statusText };
  }
  return { response, body };
}

function safeError(error: unknown): string {
  return error instanceof Error && error.message ? error.message : "Resend request failed";
}

async function verifyResendCredentials(apiKey: string, domain: string) {
  try {
    const { response, body } = await resendRequest(
      "/domains?limit=100",
      { method: "GET" },
      apiKey,
    );
    if (!response.ok) {
      const permissionHelp = response.status === 401 || response.status === 403
        ? " Check that the key is valid and has permission to read domains."
        : "";
      return {
        success: false,
        senderVerified: false,
        message: `${body.message || `Resend key check failed (${response.status})`}.${permissionHelp}`,
      };
    }

    const matchedDomain = body.data?.find(
      (item) => item.name?.toLowerCase() === domain.toLowerCase(),
    );
    const senderVerified = matchedDomain?.status?.toLowerCase() === "verified";
    return {
      success: true,
      senderVerified,
      message: senderVerified
        ? `Resend API key and ${domain} domain verified. No email was sent.`
        : `Resend API key is valid, but ${domain} is not verified on this account. No email was sent.`,
      details: matchedDomain?.status || "Configured domain not found in the Resend account",
    };
  } catch (error) {
    return { success: false, senderVerified: false, message: safeError(error) };
  }
}

function senderAddress(name: string | null | undefined, email: string) {
  return name ? `${name} <${email}>` : email;
}

function validateConfig(domain: string, fromEmail: string): string | null {
  const normalizedDomain = domain.trim().toLowerCase().replace(/^@/, "");
  const normalizedEmail = fromEmail.trim().toLowerCase();
  if (!normalizedDomain || !normalizedEmail.includes("@")) return "A sending domain and valid from email are required";
  if (!normalizedEmail.endsWith(`@${normalizedDomain}`)) {
    return `From email must use the configured domain (${normalizedDomain})`;
  }
  return null;
}

export async function sendViaResend(
  config: typeof resendConfigsTable.$inferSelect,
  input: { to: string; subject: string; body: string; isHtml?: boolean; fromEmail?: string; fromName?: string },
) {
  const fromEmail = input.fromEmail || config.fromEmail;
  const fromName = input.fromName || config.fromName || "Danewbreed Sender Pro";
  const validationError = validateConfig(config.domain, fromEmail);
  if (validationError) throw new Error(validationError);

  const payload = {
    from: senderAddress(fromName, fromEmail),
    to: [input.to],
    subject: input.subject,
    ...(input.isHtml ? { html: input.body } : { text: input.body }),
  };
  const apiKey = config.apiKeyEncrypted ? decryptApiKey(config.apiKeyEncrypted) : undefined;
  const { response, body } = await resendRequest("/emails", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  }, apiKey);
  if (!response.ok || !body.id) {
    throw new Error(body.message || `Resend request failed (${response.status})`);
  }
  return { id: body.id, status: response.status };
}

router.get("/", async (_req, res) => {
  const rows = await db.select().from(resendConfigsTable).orderBy(resendConfigsTable.createdAt);
  return res.json(rows.map(publicConfig));
});

router.post("/", async (req, res) => {
  const { label, domain, fromEmail, fromName, apiKey } = req.body;
  if (!domain || !fromEmail || !apiKey) return res.status(400).json({ error: "domain, fromEmail, and apiKey are required" });
  const validationError = validateConfig(domain, fromEmail);
  if (validationError) return res.status(400).json({ error: validationError });
  const normalizedApiKey = String(apiKey).trim();
  if (!normalizedApiKey) return res.status(400).json({ error: "apiKey is required" });
  const [row] = await db.insert(resendConfigsTable).values({
    label,
    domain: domain.trim().replace(/^@/, ""),
    fromEmail: fromEmail.trim(),
    fromName,
    apiKeyEncrypted: encryptApiKey(normalizedApiKey),
  }).returning();
  const verification = await verifyResendCredentials(normalizedApiKey, row.domain);
  const [updated] = await db.update(resendConfigsTable)
    .set({ status: verification.success && verification.senderVerified ? "verified" : "failed" })
    .where(eq(resendConfigsTable.id, row.id))
    .returning();
  return res.status(201).json({ ...publicConfig(updated), verification });
});

router.patch("/:id", async (req, res) => {
  const id = Number(req.params.id);
  const [current] = await db.select().from(resendConfigsTable).where(eq(resendConfigsTable.id, id));
  if (!current) return res.status(404).json({ error: "Not found" });
  const updates: Partial<typeof resendConfigsTable.$inferInsert> = {};
  if (req.body.label !== undefined) updates.label = req.body.label;
  if (req.body.domain !== undefined) updates.domain = String(req.body.domain).trim().replace(/^@/, "");
  if (req.body.fromEmail !== undefined) updates.fromEmail = String(req.body.fromEmail).trim();
  if (req.body.fromName !== undefined) updates.fromName = req.body.fromName;
  if (req.body.apiKey !== undefined) {
    const normalizedApiKey = String(req.body.apiKey).trim();
    if (!normalizedApiKey) return res.status(400).json({ error: "apiKey cannot be empty" });
    updates.apiKeyEncrypted = encryptApiKey(normalizedApiKey);
  }
  const validationError = validateConfig(updates.domain || current.domain, updates.fromEmail || current.fromEmail);
  if (validationError) return res.status(400).json({ error: validationError });
  const apiKey = updates.apiKeyEncrypted
    ? String(req.body.apiKey).trim()
    : current.apiKeyEncrypted
      ? decryptApiKey(current.apiKeyEncrypted)
      : "";
  if (!apiKey) return res.status(400).json({ error: "A Resend API key is required for verification" });
  const domain = updates.domain || current.domain;
  const [row] = await db.update(resendConfigsTable).set({ ...updates, status: "untested" }).where(eq(resendConfigsTable.id, id)).returning();
  const verification = await verifyResendCredentials(apiKey, domain);
  const [updated] = await db.update(resendConfigsTable)
    .set({ status: verification.success && verification.senderVerified ? "verified" : "failed" })
    .where(eq(resendConfigsTable.id, id))
    .returning();
  return res.json({ ...publicConfig(updated), verification });
});

router.delete("/:id", async (req, res) => {
  await db.delete(resendConfigsTable).where(eq(resendConfigsTable.id, Number(req.params.id)));
  return res.status(204).send();
});

router.post("/:id/verify", async (req, res) => {
  const id = Number(req.params.id);
  const [config] = await db.select().from(resendConfigsTable).where(eq(resendConfigsTable.id, id));
  if (!config) return res.status(404).json({ error: "Not found" });
  const to = String(req.body.to || "").trim();
  if (!to) return res.status(400).json({ error: "to is required" });

  try {
    const result = await sendViaResend(config, {
      to,
      subject: "Resend delivery test — Danewbreed Sender Pro",
      body: "This test confirms that the connected Resend sender accepted a message.",
    });
    await db.update(resendConfigsTable).set({ status: "verified" }).where(eq(resendConfigsTable.id, id));
    return res.json({ success: true, message: "Resend accepted the test email. Check the recipient inbox and spam folder.", messageId: result.id });
  } catch (error) {
    await db.update(resendConfigsTable).set({ status: "failed" }).where(eq(resendConfigsTable.id, id));
    return res.json({ success: false, message: safeError(error), messageId: null });
  }
});

router.post("/:id/send", async (req, res) => {
  const id = Number(req.params.id);
  const [config] = await db.select().from(resendConfigsTable).where(eq(resendConfigsTable.id, id));
  if (!config) return res.status(404).json({ error: "Not found" });
  const { to, fromEmail, fromName, subject, body, isHtml } = req.body;
  if (!to || !subject || !body) return res.status(400).json({ error: "to, subject, body required" });

  try {
    const result = await sendViaResend(config, { to, fromEmail, fromName, subject, body, isHtml });
    return res.json({ success: true, message: "Resend accepted the email", messageId: result.id });
  } catch (error) {
    return res.json({ success: false, message: safeError(error), messageId: null });
  }
});

export default router;