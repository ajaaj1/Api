import { Router } from "express";
import { db, proxiesTable } from "@workspace/db";
import { eq, inArray } from "drizzle-orm";
import * as net from "net";
import { DATABASE_UNAVAILABLE_CODE, DATABASE_UNAVAILABLE_MESSAGE, isDisabledDatabaseEndpoint } from "../lib/import-errors";

const router = Router();

function parseProxyLine(line: string): { host: string; port: number; username?: string; password?: string; protocol?: string } | null {
  line = line.trim();
  if (!line) return null;

  // CSV: host,port,username,password (username/password are optional)
  const csvParts = line.split(",").map(part => part.trim().replace(/^["']|["']$/g, ""));
  if (csvParts.length >= 2 && /^\d+$/.test(csvParts[1])) {
    return {
      host: csvParts[0],
      port: parseInt(csvParts[1], 10),
      username: csvParts[2] || undefined,
      password: csvParts[3] || undefined,
      protocol: "http",
    };
  }

  // Protocol://user:pass@host:port
  const withProtocol = line.match(/^(https?|socks[45]?):\/\/(?:([^:@]+):([^@]+)@)?([^:]+):(\d+)/i);
  if (withProtocol) {
    return {
      protocol: withProtocol[1],
      username: withProtocol[2],
      password: withProtocol[3],
      host: withProtocol[4],
      port: parseInt(withProtocol[5]),
    };
  }

  // host:port:user:pass or host:port
  const parts = line.split(":");
  if (parts.length >= 2) {
    return {
      host: parts[0],
      port: parseInt(parts[1]),
      username: parts[2] || undefined,
      password: parts[3] || undefined,
      protocol: "http",
    };
  }

  return null;
}

router.get("/", async (_req, res) => {
  const rows = await db.select().from(proxiesTable).orderBy(proxiesTable.createdAt);
  res.json(rows);
});

router.post("/", async (req, res) => {
  const { host, port, username, password, protocol } = req.body;
  if (!host || !port) return res.status(400).json({ error: "host and port required" });
  const [row] = await db.insert(proxiesTable).values({ host, port, username, password, protocol: protocol || "http" }).returning();
  res.status(201).json(row);
});

router.post("/import", async (req, res) => {
  const { raw } = req.body;
  if (typeof raw !== "string" || !raw.trim()) {
    res.status(400).json({ error: "Choose a non-empty proxy file or paste proxy rows." });
    return;
  }

  const lines = raw.replace(/^\uFEFF/, "").split(/\r?\n/);
  let imported = 0;
  let failed = 0;
  const errors: string[] = [];
  const parsedRows: Array<{ lineNumber: number; host: string; port: number; username?: string; password?: string; protocol?: string }> = [];
  const invalidCount = failed;
  const total = parsedRows.length + invalidCount;
  let firstContentLine = true;

  for (const [index, line] of lines.entries()) {
    if (!line.trim()) continue;
    const headerCells = line.split(",").map(cell => cell.trim().toLowerCase().replace(/^["']|["']$/g, ""));
    if (
      firstContentLine &&
      headerCells.some(cell => ["host", "ip", "address", "proxy"].includes(cell)) &&
      headerCells.some(cell => cell === "port")
    ) continue;
    firstContentLine = false;

    const parsed = parseProxyLine(line);
    if (parsed && parsed.host && Number.isInteger(parsed.port) && parsed.port > 0 && parsed.port <= 65535) {
      parsedRows.push({ lineNumber: index + 1, ...parsed });
    } else {
      failed++;
      if (errors.length < 20) errors.push(`Line ${index + 1}: invalid proxy row; use host,port,user,password or the shown URL format.`);
    }
  }

  const BATCH_SIZE = 500;
  for (let i = 0; i < parsedRows.length; i += BATCH_SIZE) {
    const batch = parsedRows.slice(i, i + BATCH_SIZE);
    try {
      const inserted = await db.insert(proxiesTable).values(batch.map(({ host, port, username, password, protocol }) => ({
        host,
        port,
        username,
        password,
        protocol: protocol || "http",
      }))).returning({ id: proxiesTable.id });
      imported += inserted.length;
    } catch (error) {
      if (isDisabledDatabaseEndpoint(error)) {
        req.log.warn({ batch: Math.floor(i / BATCH_SIZE) + 1 }, "Proxy import stopped because the database endpoint is disabled");
        failed += parsedRows.length - i;
        res.status(503).json({
          code: DATABASE_UNAVAILABLE_CODE,
          error: DATABASE_UNAVAILABLE_MESSAGE,
          imported,
          failed,
          total,
          ...(errors.length ? { errors } : {}),
        });
        return;
      }
      req.log.error({
        errorName: error instanceof Error ? error.name : "UnknownError",
        batch: Math.floor(i / BATCH_SIZE) + 1,
      }, "Proxy import batch failed");
      failed += batch.length;
      if (errors.length < 20) errors.push(`Batch ${Math.floor(i / BATCH_SIZE) + 1}: the proxies could not be saved.`);
    }
  }

  res.json({ imported, failed, total, ...(errors.length ? { errors } : {}) });
});

// ─── Test-all: fire-and-forget job queue + polling ───────────────────────────
type ProxyTestResult = { id: number; host: string; port: number; success: boolean; ms?: number; error?: string };
type ProxyJob = { total: number; done: boolean; passed: number; failed: number; results: ProxyTestResult[]; fatalError?: string };

const proxyJobs = new Map<string, ProxyJob>();
const newProxyJobId = () => Math.random().toString(36).slice(2);
const PROXY_BATCH = 10;

function testProxyTcp(host: string, port: number, timeoutMs = 8000): Promise<{ ok: boolean; ms: number }> {
  const start = Date.now();
  return new Promise((resolve) => {
    const socket = new net.Socket();
    const timer = setTimeout(() => { socket.destroy(); resolve({ ok: false, ms: Date.now() - start }); }, timeoutMs);
    socket.connect(port, host, () => {
      clearTimeout(timer);
      socket.destroy();
      resolve({ ok: true, ms: Date.now() - start });
    });
    socket.on("error", () => { clearTimeout(timer); resolve({ ok: false, ms: Date.now() - start }); });
  });
}

router.post("/test-all", (req, res) => {
  const requestedIds = Array.isArray(req.body?.ids)
    ? req.body.ids
      .map((id: unknown) => typeof id === "number" ? id : Number(id))
      .filter((id: number) => Number.isInteger(id))
    : null;
  const jobId = newProxyJobId();
  const job: ProxyJob = { total: -1, done: false, passed: 0, failed: 0, results: [] };
  proxyJobs.set(jobId, job);

  res.json({ jobId });

  setImmediate(async () => {
    try {
      const query = db.select().from(proxiesTable);
      const proxies = await (requestedIds && requestedIds.length > 0
        ? query.where(inArray(proxiesTable.id, requestedIds))
        : query
      ).orderBy(proxiesTable.createdAt);
      job.total = proxies.length;

      for (let i = 0; i < proxies.length; i += PROXY_BATCH) {
        const batch = proxies.slice(i, i + PROXY_BATCH);
        const settled = await Promise.allSettled(
          batch.map(async (p) => {
            const { ok, ms } = await testProxyTcp(p.host, p.port);
            try {
              await db.update(proxiesTable).set({ status: ok ? "active" : "failed" }).where(eq(proxiesTable.id, p.id));
            } catch {}
            return { id: p.id, host: p.host, port: p.port, success: ok, ms };
          })
        );

        for (let j = 0; j < settled.length; j++) {
          const r = settled[j];
          const p = batch[j];
          const data: ProxyTestResult = r.status === "fulfilled"
            ? r.value
            : { id: p.id, host: p.host, port: p.port, success: false, error: String((r as any).reason) };
          if (data.success) job.passed++; else job.failed++;
          job.results.push(data);
        }
      }
    } catch (e: any) {
      job.fatalError = String(e?.message ?? e);
    }
    job.done = true;
    setTimeout(() => proxyJobs.delete(jobId), 10 * 60 * 1000);
  });
});

router.get("/test-all/job/:jobId", (req, res) => {
  const job = proxyJobs.get(req.params.jobId);
  if (!job) return res.status(404).json({ error: "Job not found" });
  res.json(job);
});

router.delete("/clear-failed", async (_req, res) => {
  const deleted = await db.delete(proxiesTable)
    .where(eq(proxiesTable.status, "failed"))
    .returning({ id: proxiesTable.id });
  res.json({ deleted: deleted.length });
});

router.delete("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  await db.delete(proxiesTable).where(eq(proxiesTable.id, id));
  res.status(204).send();
});

router.post("/:id/test", async (req, res) => {
  const id = parseInt(req.params.id);
  const [proxy] = await db.select().from(proxiesTable).where(eq(proxiesTable.id, id));
  if (!proxy) return res.status(404).json({ error: "Not found" });

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);
    const r = await fetch("https://api.ipify.org?format=json", { signal: controller.signal });
    clearTimeout(timeout);
    if (r.ok) {
      await db.update(proxiesTable).set({ status: "active" }).where(eq(proxiesTable.id, id));
      res.json({ success: true, message: `Proxy connection successful (${proxy.host}:${proxy.port})` });
    } else {
      res.json({ success: false, message: "Proxy test failed", details: `HTTP ${r.status}` });
    }
  } catch (e: any) {
    await db.update(proxiesTable).set({ status: "failed" }).where(eq(proxiesTable.id, id));
    res.json({ success: false, message: "Proxy connection failed", details: e.message });
  }
});

export default router;
