import { Router } from "express";
import { db, warmupPlansTable, warmupDailyLogsTable, smtpsTable, awsConfigsTable, sendgridConfigsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";

const router = Router();

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

export function calcDailyLimit(plan: { startVolume: number; endVolume: number; durationDays: number; startDate: Date | string }): number {
  const start = new Date(plan.startDate);
  const today = new Date();
  start.setHours(0, 0, 0, 0);
  today.setHours(0, 0, 0, 0);
  const dayN = Math.floor((today.getTime() - start.getTime()) / 86400000) + 1;
  const clampedDay = Math.min(Math.max(dayN, 1), plan.durationDays);
  if (plan.durationDays <= 1) return plan.endVolume;
  return Math.round(plan.startVolume + (plan.endVolume - plan.startVolume) * (clampedDay - 1) / (plan.durationDays - 1));
}

export async function getWarmupCapForSmtp(smtpId: number): Promise<{ planId: number; limit: number; usedToday: number } | null> {
  const plans = await db.select().from(warmupPlansTable).where(and(eq(warmupPlansTable.smtpId, smtpId), eq(warmupPlansTable.status, "active")));
  if (!plans.length) return null;
  const plan = plans[0];
  const limit = calcDailyLimit(plan);
  const today = todayStr();
  const logs = await db.select().from(warmupDailyLogsTable).where(and(eq(warmupDailyLogsTable.warmupPlanId, plan.id), eq(warmupDailyLogsTable.date, today)));
  return { planId: plan.id, limit, usedToday: logs[0]?.sentCount ?? 0 };
}

export async function recordWarmupSend(planId: number): Promise<void> {
  const today = todayStr();
  const existing = await db.select().from(warmupDailyLogsTable).where(and(eq(warmupDailyLogsTable.warmupPlanId, planId), eq(warmupDailyLogsTable.date, today)));
  if (existing.length) {
    await db.update(warmupDailyLogsTable).set({ sentCount: existing[0].sentCount + 1 }).where(eq(warmupDailyLogsTable.id, existing[0].id));
  } else {
    await db.insert(warmupDailyLogsTable).values({ warmupPlanId: planId, date: today, sentCount: 1 });
  }
}

router.get("/", async (_req, res) => {
  const plans = await db.select().from(warmupPlansTable).orderBy(warmupPlansTable.createdAt);
  const today = todayStr();

  const enriched = await Promise.all(plans.map(async (plan) => {
    const dailyLimit = calcDailyLimit(plan);
    const log = (await db.select().from(warmupDailyLogsTable).where(and(eq(warmupDailyLogsTable.warmupPlanId, plan.id), eq(warmupDailyLogsTable.date, today))))[0];
    const start = new Date(plan.startDate);
    start.setHours(0, 0, 0, 0);
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    const currentDay = Math.min(Math.max(Math.floor((now.getTime() - start.getTime()) / 86400000) + 1, 1), plan.durationDays);
    return { ...plan, dailyLimit, usedToday: log?.sentCount ?? 0, currentDay };
  }));

  res.json(enriched);
});

router.post("/", async (req, res) => {
  const { name, smtpId, awsConfigId, sendgridConfigId, startDate, durationDays, startVolume, endVolume } = req.body;
  if (!name || !durationDays || !startVolume || !endVolume) return res.status(400).json({ error: "name, durationDays, startVolume, endVolume required" });
  const [plan] = await db.insert(warmupPlansTable).values({
    name,
    smtpId: smtpId || null,
    awsConfigId: awsConfigId || null,
    sendgridConfigId: sendgridConfigId || null,
    startDate: startDate ? new Date(startDate) : new Date(),
    durationDays: parseInt(durationDays),
    startVolume: parseInt(startVolume),
    endVolume: parseInt(endVolume),
    status: "active",
  }).returning();
  res.status(201).json(plan);
});

router.put("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const { name, status, durationDays, startVolume, endVolume, startDate } = req.body;
  const updates: any = {};
  if (name !== undefined) updates.name = name;
  if (status !== undefined) updates.status = status;
  if (durationDays !== undefined) updates.durationDays = parseInt(durationDays);
  if (startVolume !== undefined) updates.startVolume = parseInt(startVolume);
  if (endVolume !== undefined) updates.endVolume = parseInt(endVolume);
  if (startDate !== undefined) updates.startDate = new Date(startDate);
  const [plan] = await db.update(warmupPlansTable).set(updates).where(eq(warmupPlansTable.id, id)).returning();
  if (!plan) return res.status(404).json({ error: "Plan not found" });
  res.json(plan);
});

router.delete("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  await db.delete(warmupDailyLogsTable).where(eq(warmupDailyLogsTable.warmupPlanId, id));
  await db.delete(warmupPlansTable).where(eq(warmupPlansTable.id, id));
  res.json({ ok: true });
});

router.get("/:id/history", async (req, res) => {
  const id = parseInt(req.params.id);
  const logs = await db.select().from(warmupDailyLogsTable).where(eq(warmupDailyLogsTable.warmupPlanId, id));
  logs.sort((a, b) => a.date.localeCompare(b.date));
  res.json(logs);
});

export default router;
