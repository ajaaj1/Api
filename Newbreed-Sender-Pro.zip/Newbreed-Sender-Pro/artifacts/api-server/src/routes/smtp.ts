import { Router } from "express";
import { db, smtpsTable } from "@workspace/db";
import { eq, inArray, ne } from "drizzle-orm";
import nodemailer from "nodemailer";
import { DATABASE_UNAVAILABLE_CODE, DATABASE_UNAVAILABLE_MESSAGE, isDisabledDatabaseEndpoint } from "../lib/import-errors";

const router = Router();

// ─── In-memory test job store ─────────────────────────────────────────────────
type TestResult = {
  id: number;
  host: string;
  user: string;
  label?: string | null;
  success: boolean;
  usedPort: number;
  error?: string;
};
type TestJob = {
  total: number;
  completed: number;
  done: boolean;
  passed: number;
  failed: number;
  failedIds: number[];
  results: TestResult[];
  fatalError?: string;
};
const testJobs = new Map<string, TestJob>();

function newJobId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

function safeErrorMessage(error: unknown): string {
  try {
    if (error instanceof Error && error.message) return error.message;
    if (typeof error === "string" && error) return error;
    const message = (error as { message?: unknown } | null)?.message;
    return typeof message === "string" && message ? message : "Unknown SMTP error";
  } catch {
    return "Unknown SMTP error";
  }
}

function safeStringList(value: unknown): string[] {
  return Array.isArray(value)
    ? value.filter((item): item is string => typeof item === "string")
    : [];
}

// ─── SMTP parsing ─────────────────────────────────────────────────────────────
function parseSmtpLine(line: string): { host: string; port: number; user: string; pass: string; label?: string } | null {
  line = line.trim();
  if (!line) return null;

  if (line.toUpperCase().includes("HOST:")) {
    const host = line.match(/HOST:\s*([^\s,]+)/i)?.[1];
    const port = line.match(/PORT:\s*(\d+)/i)?.[1];
    const user = line.match(/(?:USER|MAIL):\s*([^\s,]+)/i)?.[1];
    const pass = line.match(/PASS:\s*([^\s,]+)/i)?.[1];
    if (host && port && user && pass) {
      return { host, port: parseInt(port), user, pass };
    }
  }

  const csv = line.split(",").map(value => value.trim().replace(/^["']|["']$/g, ""));
  if (csv.length >= 3) {
    const hostPort = csv[0].split(":");
    const port = Number.parseInt(hostPort[1] ?? "", 10);
    if (hostPort.length === 2 && hostPort[0].trim() && Number.isInteger(port) && port > 0 && port <= 65535 && csv[1] && csv[2]) {
      return { host: hostPort[0].trim(), port, user: csv[1], pass: csv[2] };
    }
  }

  const pipe = line.split("|");
  if (pipe.length >= 4) {
    return { host: pipe[0].trim(), port: parseInt(pipe[1]), user: pipe[2].trim(), pass: pipe[3].trim() };
  }

  return null;
}

// ─── SMTP send helper ─────────────────────────────────────────────────────────
async function trySmtpSend(
  host: string, port: number, user: string, pass: string,
  toEmail: string, fromName: string
): Promise<{
  success: boolean;
  usedPort: number;
  messageId?: string;
  response?: string;
  accepted?: string[];
  rejected?: string[];
  error?: string;
}> {
  const altPort = port === 587 ? 465 : port === 465 ? 587 : null;

  async function attempt(p: number): Promise<{
    messageId?: string;
    response?: string;
    accepted: string[];
    rejected: string[];
  }> {
    const secure = p === 465;
    const transporter = nodemailer.createTransport({
      host,
      port: p,
      secure,
      auth: { user, pass },
      tls: { rejectUnauthorized: false },
      connectionTimeout: 5000,
      greetingTimeout: 3000,
      socketTimeout: 6000,
    });
    try {
      await transporter.verify();
      const info = await transporter.sendMail({
        from: `"${fromName || "Newbreed Pro Sender"}" <${user}>`,
        to: toEmail,
        subject: "SMTP Delivery Test - Danewbreed Sender Pro",
        text: "This is a test email from Danewbreed Sender Pro to verify SMTP delivery.",
        html: "<p>This is a test email from <b>Danewbreed Sender Pro</b> to verify SMTP delivery.</p>",
      });
      const accepted = safeStringList(info.accepted);
      const rejected = safeStringList(info.rejected);
      if (accepted.length === 0 || rejected.length > 0) {
        throw new Error(
          rejected.length > 0
            ? `SMTP rejected recipient: ${rejected.join(", ")}`
            : "SMTP connection succeeded but the server did not accept the recipient"
        );
      }
      return {
        messageId: typeof info.messageId === "string" ? info.messageId : undefined,
        response: typeof info.response === "string" ? info.response : undefined,
        accepted,
        rejected,
      };
    } finally {
      try { transporter.close(); } catch {}
    }
  }

  try {
    return { success: true, usedPort: port, ...(await attempt(port)) };
  } catch (e: any) {
    const errMsg = safeErrorMessage(e);
    if (altPort) {
      try {
        return { success: true, usedPort: altPort, ...(await attempt(altPort)) };
      } catch (e2: any) {
        return { success: false, usedPort: port, error: `Port ${port}: ${errMsg} | Port ${altPort}: ${safeErrorMessage(e2)}` };
      }
    }
    return { success: false, usedPort: port, error: errMsg };
  }
}

async function verifySmtpCredentials(config: {
  host: string;
  port: number;
  user: string;
  pass: string;
  secure?: boolean | null;
}) {
  const transporter = nodemailer.createTransport({
    host: config.host,
    port: config.port,
    secure: config.secure ?? config.port === 465,
    auth: { user: config.user, pass: config.pass },
    tls: { rejectUnauthorized: false },
    connectionTimeout: 12000,
    greetingTimeout: 8000,
  });
  try {
    await transporter.verify();
    return { success: true, message: "SMTP connection and credentials verified. No email was sent." };
  } catch (error) {
    return { success: false, message: safeErrorMessage(error) };
  } finally {
    transporter.close();
  }
}

// ─── Routes ───────────────────────────────────────────────────────────────────

router.get("/", async (_req, res) => {
  const rows = await db.select().from(smtpsTable).orderBy(smtpsTable.createdAt);
  res.json(rows);
});

router.post("/", async (req, res) => {
  const { label, host, port, user, pass, secure } = req.body;
  if (!host || !port || !user || !pass) return res.status(400).json({ error: "Missing required fields" });
  const [row] = await db.insert(smtpsTable).values({ label, host, port, user, pass, secure: secure ?? true }).returning();
  const verification = await verifySmtpCredentials(row);
  const [updated] = await db.update(smtpsTable).set({
    status: verification.success ? "verified" : "failed",
    lastTestedAt: new Date(),
  }).where(eq(smtpsTable.id, row.id)).returning();
  res.status(201).json({ ...updated, verification });
});

router.post("/import", async (req, res) => {
  const { raw } = req.body;
  if (typeof raw !== "string" || !raw.trim()) {
    res.status(400).json({ error: "Choose a non-empty SMTP file or paste SMTP rows." });
    return;
  }

  const lines = raw.replace(/^\uFEFF/, "").split(/\r?\n/);
  let imported = 0;
  let failed = 0;
  const errors: string[] = [];
  const parsedRows: Array<{ lineNumber: number; host: string; port: number; user: string; pass: string }> = [];

  let firstContentLine = true;
  for (const [index, line] of lines.entries()) {
    if (!line.trim()) continue;
    const firstCells = line.split(",").map(cell => cell.trim().toLowerCase().replace(/^["']|["']$/g, ""));
    if (
      firstContentLine &&
      firstCells.some(cell => ["host", "smtp_host", "server", "smtp_host_name"].includes(cell)) &&
      firstCells.some(cell => ["port", "smtp_port"].includes(cell))
    ) continue;
    firstContentLine = false;

    const parsed = parseSmtpLine(line);
    if (parsed) {
      parsedRows.push({ lineNumber: index + 1, ...parsed });
    } else {
      failed++;
      if (errors.length < 20) errors.push(`Line ${index + 1}: unsupported format; check the examples and required host, port, username, and password.`);
    }
  }

  const BATCH_SIZE = 500;
  const invalidCount = failed;
  const total = parsedRows.length + invalidCount;
  for (let i = 0; i < parsedRows.length; i += BATCH_SIZE) {
    const batch = parsedRows.slice(i, i + BATCH_SIZE);
    try {
      const inserted = await db
        .insert(smtpsTable)
        .values(batch.map(({ host, port, user, pass }) => ({ host, port, user, pass })))
        .onConflictDoNothing()
        .returning({ id: smtpsTable.id });
      imported += inserted.length;
      failed += batch.length - inserted.length;
    } catch (error) {
      if (isDisabledDatabaseEndpoint(error)) {
        req.log.warn({ batch: Math.floor(i / BATCH_SIZE) + 1 }, "SMTP import stopped because the database endpoint is disabled");
        failed += parsedRows.length - i;
        res.status(503).json({
          code: DATABASE_UNAVAILABLE_CODE,
          error: DATABASE_UNAVAILABLE_MESSAGE,
          imported,
          failed,
          total,
          ...(errors.length ? { errors } : {}),
        });
        return;
      }
      req.log.error({
        errorName: error instanceof Error ? error.name : "UnknownError",
        batch: Math.floor(i / BATCH_SIZE) + 1,
      }, "SMTP import batch failed");
      failed += batch.length;
      if (errors.length < 20) errors.push(`Batch ${Math.floor(i / BATCH_SIZE) + 1}: the SMTPs could not be saved.`);
    }
  }

  res.json({ imported, failed, total, errors });
});

// ─── Test-all: fire-and-forget job queue with polling ────────────────────────
// The POST handler does ZERO async work — it returns {jobId} in under 1ms.
// All DB queries and SMTP tests run in the background.
// Frontend polls GET /test-all/job/:jobId every second for live progress.
const TEST_CONCURRENCY = 32;
const MAX_RESULTS_PER_POLL = 100;

router.post("/test-all", (req, res): void => {
  const { toEmail } = req.body;
  if (typeof toEmail !== "string" || !toEmail.trim()) {
    res.status(400).json({ error: "toEmail required" });
    return;
  }

  let ids: number[] | undefined;
  if (req.body.ids !== undefined) {
    if (!Array.isArray(req.body.ids)) {
      res.status(400).json({ error: "ids must be an array of SMTP IDs" });
      return;
    }
    const parsedIds = [...new Set((req.body.ids as unknown[]).map((value) => Number(value)))];
    if (parsedIds.some((id) => !Number.isInteger(id) || id <= 0)) {
      res.status(400).json({ error: "ids must contain valid SMTP IDs" });
      return;
    }
    if (parsedIds.length === 0) {
      res.status(400).json({ error: "No SMTPs were selected to test" });
      return;
    }
    ids = parsedIds;
  }

  const jobId = newJobId();
  const job: TestJob = {
    total: 0,
    completed: 0,
    done: false,
    passed: 0,
    failed: 0,
    failedIds: [],
    results: [],
  };
  testJobs.set(jobId, job);

  res.json({ jobId });

  setImmediate(async () => {
    try {
      const smtps = ids
        ? await db.select().from(smtpsTable).where(inArray(smtpsTable.id, ids)).orderBy(smtpsTable.createdAt)
        : await db.select().from(smtpsTable).orderBy(smtpsTable.createdAt);
      job.total = smtps.length;

      let nextIndex = 0;
      const worker = async () => {
        while (true) {
          const index = nextIndex++;
          if (index >= smtps.length) return;

          const smtp = smtps[index];
          let data: TestResult;
          try {
            const result = await trySmtpSend(smtp.host, smtp.port, smtp.user, smtp.pass, toEmail, "Newbreed Pro Sender");
            try {
              await db.update(smtpsTable).set({
                status: result.success ? "verified" : "failed",
                ...(result.success ? { port: result.usedPort } : {}),
                lastTestedAt: new Date(),
              }).where(eq(smtpsTable.id, smtp.id));
            } catch {}

            data = {
              id: smtp.id,
              host: smtp.host,
              user: smtp.user,
              label: typeof smtp.label === "string" ? smtp.label : null,
              success: !!result.success,
              usedPort: Number(result.usedPort),
              ...(result.error ? { error: result.error.slice(0, 500) } : {}),
            };
          } catch (error) {
            data = {
              id: smtp.id,
              host: smtp.host,
              user: smtp.user,
              label: smtp.label ?? null,
              success: false,
              usedPort: smtp.port,
              error: safeErrorMessage(error).slice(0, 500),
            };
          }

          job.results.push(data);
          job.completed++;
          if (data.success) job.passed++; else job.failed++;
          if (!data.success) job.failedIds.push(data.id);
        }
      };

      await Promise.all(
        Array.from({ length: Math.min(TEST_CONCURRENCY, smtps.length) }, () => worker()),
      );
    } catch (e: any) {
      job.fatalError = safeErrorMessage(e);
    }

    job.done = true;
    const cleanupTimer = setTimeout(() => testJobs.delete(jobId), 30 * 60 * 1000);
    cleanupTimer.unref?.();
  });
});

// Keep this before /:id so Express does not treat "test-all" as an id.
router.get("/test-all/job/:jobId", (req, res): void => {
  const job = testJobs.get(req.params.jobId);
  if (!job) {
    res.status(404).json({ error: "Job not found or expired" });
    return;
  }

  const rawAfter = Array.isArray(req.query.after) ? req.query.after[0] : req.query.after;
  const rawLimit = Array.isArray(req.query.limit) ? req.query.limit[0] : req.query.limit;
  const requestedAfter = rawAfter === undefined ? 0 : Number(rawAfter);
  const requestedLimit = rawLimit === undefined ? MAX_RESULTS_PER_POLL : Number(rawLimit);
  if (!Number.isInteger(requestedAfter) || requestedAfter < 0) {
    res.status(400).json({ error: "after must be a non-negative integer" });
    return;
  }
  if (!Number.isInteger(requestedLimit) || requestedLimit < 1) {
    res.status(400).json({ error: "limit must be a positive integer" });
    return;
  }

  const cursor = Math.min(requestedAfter, job.results.length);
  const limit = Math.min(requestedLimit, MAX_RESULTS_PER_POLL);
  const results = job.results.slice(cursor, cursor + limit);
  res.json({
    total: Number(job.total),
    completed: Number(job.completed),
    done: !!job.done,
    passed: Number(job.passed),
    failed: Number(job.failed),
    nextCursor: cursor + results.length,
    ...(job.fatalError ? { fatalError: safeErrorMessage(job.fatalError) } : {}),
    results: results.map((result) => ({
      id: Number(result.id),
      host: String(result.host),
      user: String(result.user),
      label: result.label == null ? null : String(result.label),
      success: !!result.success,
      usedPort: Number(result.usedPort),
      ...(result.error ? { error: safeErrorMessage(result.error) } : {}),
    })),
  });
});

router.delete("/clear-unverified", async (_req, res) => {
  const result = await db.delete(smtpsTable).where(ne(smtpsTable.status, "verified")).returning();
  res.json({ deleted: result.length });
});

// ─── Single SMTP routes (keep after /test-all to avoid route collision) ───────

router.get("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });
  const [row] = await db.select().from(smtpsTable).where(eq(smtpsTable.id, id));
  if (!row) return res.status(404).json({ error: "Not found" });
  res.json(row);
});

router.patch("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });
  const { label, host, port, user, pass, secure } = req.body;
  const [row] = await db.update(smtpsTable).set({ label, host, port, user, pass, secure }).where(eq(smtpsTable.id, id)).returning();
  if (!row) return res.status(404).json({ error: "Not found" });
  const verification = await verifySmtpCredentials(row);
  const [updated] = await db.update(smtpsTable).set({
    status: verification.success ? "verified" : "failed",
    lastTestedAt: new Date(),
  }).where(eq(smtpsTable.id, id)).returning();
  res.json({ ...updated, verification });
});

router.delete("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });
  await db.delete(smtpsTable).where(eq(smtpsTable.id, id));
  res.status(204).send();
});

router.post("/:id/test", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });
  const [smtp] = await db.select().from(smtpsTable).where(eq(smtpsTable.id, id));
  if (!smtp) return res.status(404).json({ error: "Not found" });

  const { toEmail, fromName } = req.body;
  if (!toEmail) return res.status(400).json({ error: "toEmail required" });

  const result = await trySmtpSend(smtp.host, smtp.port, smtp.user, smtp.pass, toEmail, fromName || "Newbreed Pro Sender");

  if (result.success) {
    await db.update(smtpsTable).set({
      status: "verified",
      port: result.usedPort,
      lastTestedAt: new Date()
    }).where(eq(smtpsTable.id, id));
    const portNote = result.usedPort !== smtp.port ? ` (switched to port ${result.usedPort})` : "";
    res.json({
      success: true,
      message: `SMTP accepted the test email${portNote}. Check the recipient inbox and spam folder.`,
      port: result.usedPort,
      messageId: result.messageId,
      response: result.response,
      accepted: result.accepted,
      rejected: result.rejected,
    });
  } else {
    await db.update(smtpsTable).set({ status: "failed", lastTestedAt: new Date() }).where(eq(smtpsTable.id, id));
    res.json({ success: false, message: "SMTP test failed", details: result.error });
  }
});

export default router;
