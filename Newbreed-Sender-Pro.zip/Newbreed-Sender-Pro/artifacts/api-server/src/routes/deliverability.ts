import { Router } from "express";

const router = Router();

// ─── Spam keyword lists ────────────────────────────────────────────────────

const HIGH_SPAM_WORDS = [
  "100% free", "act now", "apply now", "as seen on",
  "avoid bankruptcy", "bonus", "buy direct", "buy now",
  "cash bonus", "casino", "click here", "collect",
  "congratulations", "dear friend", "direct email", "earn extra cash",
  "earn money", "eliminate debt", "extra cash", "fast cash",
  "for free", "free access", "free bonus", "free gift",
  "free info", "free investment", "free leads", "free money",
  "free offer", "free preview", "free quote", "free sample",
  "free trial", "get it now", "get paid", "guaranteed",
  "have been selected", "hidden", "home based", "incredible deal",
  "internet marketing", "join millions", "limited time",
  "lose weight", "lowest price", "luxury", "make money",
  "make $", "million dollars", "miracle", "money back",
  "money making", "no catch", "no cost", "no credit check",
  "no experience", "no fees", "no gimmick", "no hidden",
  "no interest", "no investment", "no obligation", "no purchase necessary",
  "no questions asked", "no strings attached", "now only",
  "offer expires", "once in a lifetime", "one hundred percent free",
  "only $", "open immediately", "opportunity", "order now",
  "order today", "pennies a day", "please read", "potential earnings",
  "prize", "profit", "pure profit", "remove", "risk free",
  "save big", "save up to", "special promotion", "stock alert",
  "subscribe", "they're giving it away", "thousands", "unbelievable",
  "unconditional", "unlimited", "unsecured credit", "urgent",
  "vacation", "viagra", "winner", "winning", "work at home",
  "work from home", "you are a winner", "you have been selected",
  "you're a winner", "zero cost",
];

const SUBJECT_SPAM_WORDS = [
  "free", "urgent", "winner", "guaranteed", "congratulations",
  "claim", "act now", "limited", "exclusive", "cash",
  "prize", "offer", "deal", "earn", "income",
];

const SHORTENER_DOMAINS = [
  "bit.ly", "tinyurl.com", "goo.gl", "ow.ly", "t.co",
  "rebrand.ly", "shorte.st", "adf.ly", "tiny.cc", "is.gd",
  "buff.ly", "dlvr.it", "ht.ly", "su.pr",
];

// ─── Scoring engine ────────────────────────────────────────────────────────

interface Finding {
  severity: "error" | "warning" | "info";
  category: string;
  message: string;
  detail?: string;
}

function htmlToText(html: string): string {
  return html
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "")
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/\s+/g, " ")
    .trim();
}

function checkDeliverability(html: string, subject: string, fromEmail: string): {
  score: number;
  grade: string;
  findings: Finding[];
  stats: Record<string, string | number>;
} {
  const findings: Finding[] = [];
  const text = htmlToText(html);
  const lowerHtml = html.toLowerCase();
  const lowerText = text.toLowerCase();
  const lowerSubject = (subject || "").toLowerCase();

  // ── Subject line checks ──────────────────────────────────────────────────
  if (!subject || subject.trim().length === 0) {
    findings.push({ severity: "error", category: "Subject Line", message: "Subject line is empty — emails without subjects have very high spam rates" });
  } else {
    if (subject.length > 78) {
      findings.push({ severity: "warning", category: "Subject Line", message: `Subject is too long (${subject.length} chars) — keep under 50 characters for best open rates`, detail: "Many clients truncate at 50–70 chars" });
    } else if (subject.length > 50) {
      findings.push({ severity: "info", category: "Subject Line", message: `Subject is ${subject.length} characters — under 50 is ideal for mobile` });
    }

    const allCapsWords = subject.match(/\b[A-Z]{3,}\b/g) || [];
    if (allCapsWords.length >= 3) {
      findings.push({ severity: "error", category: "Subject Line", message: `Subject contains ${allCapsWords.length} ALL-CAPS words — major spam trigger`, detail: allCapsWords.join(", ") });
    } else if (allCapsWords.length > 0) {
      findings.push({ severity: "warning", category: "Subject Line", message: `Subject has ALL-CAPS word(s): ${allCapsWords.join(", ")}` });
    }

    const exclCount = (subject.match(/!/g) || []).length;
    const qMarkCount = (subject.match(/\?/g) || []).length;
    if (exclCount >= 3 || qMarkCount >= 3) {
      findings.push({ severity: "error", category: "Subject Line", message: `Excessive punctuation in subject (${exclCount} !, ${qMarkCount} ?) — strong spam indicator` });
    } else if (exclCount >= 2) {
      findings.push({ severity: "warning", category: "Subject Line", message: `Multiple exclamation marks in subject (${exclCount}) — avoid for better deliverability` });
    }

    const hitSpamWords = SUBJECT_SPAM_WORDS.filter(w => lowerSubject.includes(w));
    if (hitSpamWords.length > 0) {
      findings.push({ severity: "warning", category: "Subject Line", message: `Subject contains spam-flagged words: ${hitSpamWords.slice(0, 5).join(", ")}`, detail: hitSpamWords.length > 5 ? `+${hitSpamWords.length - 5} more` : undefined });
    }

    if (/^(re:|fwd:|fw:)/i.test(subject.trim())) {
      findings.push({ severity: "warning", category: "Subject Line", message: 'Subject starts with "Re:" or "Fwd:" — a common spam tactic to fake replies' });
    }

    const dollarSigns = (subject.match(/\$/g) || []).length;
    if (dollarSigns > 0) {
      findings.push({ severity: "warning", category: "Subject Line", message: `Dollar sign ($) in subject — common spam trigger` });
    }
  }

  // ── Body spam words ──────────────────────────────────────────────────────
  const hitBodySpam = HIGH_SPAM_WORDS.filter(w => lowerText.includes(w.toLowerCase()));
  if (hitBodySpam.length >= 5) {
    findings.push({ severity: "error", category: "Spam Content", message: `High spam word density: ${hitBodySpam.length} flagged phrases in body`, detail: hitBodySpam.slice(0, 8).join(", ") + (hitBodySpam.length > 8 ? `… (+${hitBodySpam.length - 8} more)` : "") });
  } else if (hitBodySpam.length >= 2) {
    findings.push({ severity: "warning", category: "Spam Content", message: `${hitBodySpam.length} spam-flagged phrases detected in body`, detail: hitBodySpam.join(", ") });
  } else if (hitBodySpam.length === 1) {
    findings.push({ severity: "info", category: "Spam Content", message: `1 mildly flagged phrase: "${hitBodySpam[0]}"` });
  }

  // ── Unsubscribe check ────────────────────────────────────────────────────
  const hasUnsub = /unsubscribe|opt.?out|remove me|manage preferences|email preferences/i.test(html);
  if (!hasUnsub) {
    findings.push({ severity: "error", category: "Legal Compliance", message: "No unsubscribe link found — required by CAN-SPAM and GDPR", detail: 'Add an unsubscribe link, e.g. <a href="{{unsubscribe_url}}">Unsubscribe</a>' });
  }

  // ── Images check ─────────────────────────────────────────────────────────
  const imgTags = html.match(/<img[^>]*>/gi) || [];
  const textLength = text.length;
  const htmlLength = html.length;

  if (imgTags.length > 0) {
    const imgsWithoutAlt = imgTags.filter(t => !/alt\s*=\s*["'][^"']+["']/i.test(t)).length;
    if (imgsWithoutAlt > 0) {
      findings.push({ severity: "warning", category: "Images", message: `${imgsWithoutAlt} image(s) missing alt text — hurts accessibility and spam scoring` });
    }

    // Image-to-text ratio: text should be at least 20% of content
    if (textLength < 100 && imgTags.length >= 1) {
      findings.push({ severity: "error", category: "Images", message: "Email is nearly all images with very little text — high spam risk and renders blank in many clients" });
    } else if (textLength < 200 && imgTags.length >= 3) {
      findings.push({ severity: "warning", category: "Images", message: `Low text-to-image ratio: ${imgTags.length} images but only ~${textLength} characters of text` });
    }

    const externalImgs = imgTags.filter(t => /src\s*=\s*["']https?:\/\//i.test(t)).length;
    if (externalImgs > 5) {
      findings.push({ severity: "info", category: "Images", message: `${externalImgs} externally hosted images — ensure they are on a reputable CDN` });
    }
  } else {
    findings.push({ severity: "info", category: "Images", message: "No images — text-only email has best deliverability but may look plain" });
  }

  // ── HTML size ────────────────────────────────────────────────────────────
  const sizeKb = Math.round(htmlLength / 1024);
  if (sizeKb > 100) {
    findings.push({ severity: "error", category: "HTML Structure", message: `HTML is very large (${sizeKb} KB) — Gmail clips emails over 102KB`, detail: "Split content or reduce inline styles/images" });
  } else if (sizeKb > 60) {
    findings.push({ severity: "warning", category: "HTML Structure", message: `HTML is ${sizeKb} KB — approaching Gmail's 102KB clip threshold` });
  }

  // ── DOCTYPE ──────────────────────────────────────────────────────────────
  if (!html.trim().toLowerCase().startsWith("<!doctype")) {
    findings.push({ severity: "warning", category: "HTML Structure", message: "Missing DOCTYPE declaration — may cause rendering issues in Outlook and older clients" });
  }

  // ── Inline styles (not external CSS) ────────────────────────────────────
  const externalStylesheets = html.match(/<link[^>]+rel=["']stylesheet["'][^>]*>/gi) || [];
  if (externalStylesheets.length > 0) {
    findings.push({ severity: "error", category: "HTML Structure", message: `${externalStylesheets.length} external stylesheet(s) found — email clients strip <link> tags; use inline styles`, detail: "CSS must be inlined for reliable rendering across clients" });
  }

  // ── JavaScript ───────────────────────────────────────────────────────────
  const scripts = html.match(/<script[^>]*>/gi) || [];
  if (scripts.length > 0) {
    findings.push({ severity: "error", category: "HTML Structure", message: `${scripts.length} <script> tag(s) detected — JavaScript is stripped by all email clients and is a major spam trigger` });
  }

  // ── URL / link checks ────────────────────────────────────────────────────
  const links = html.match(/href\s*=\s*["'](https?:\/\/[^"'\s>]+)["']/gi) || [];
  const hitShorteners = links.filter(l => SHORTENER_DOMAINS.some(d => l.includes(d)));
  if (hitShorteners.length > 0) {
    findings.push({ severity: "error", category: "Links", message: `${hitShorteners.length} URL shortener(s) detected (bit.ly, tinyurl, etc.) — blacklisted by most spam filters`, detail: "Use full, branded URLs instead" });
  }

  // ── From email format ────────────────────────────────────────────────────
  if (fromEmail) {
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fromEmail)) {
      findings.push({ severity: "error", category: "Sender", message: `From email "${fromEmail}" appears invalid` });
    } else {
      const fromDomain = fromEmail.split("@")[1] || "";
      if (/gmail\.com|yahoo\.com|hotmail\.com|outlook\.com|aol\.com/i.test(fromDomain)) {
        findings.push({ severity: "warning", category: "Sender", message: `Sending bulk email from a personal address (@${fromDomain}) will be rejected or filtered — use a business domain` });
      }
    }
  }

  // ── Plain text recommendation ────────────────────────────────────────────
  findings.push({ severity: "info", category: "Best Practice", message: "Consider adding a plain-text version alongside HTML — improves deliverability and reduces spam score" });

  // ── Positive signals ─────────────────────────────────────────────────────
  if (hasUnsub) {
    findings.push({ severity: "info", category: "Best Practice", message: "✓ Unsubscribe link present — good for CAN-SPAM / GDPR compliance" });
  }
  if (textLength > 300) {
    findings.push({ severity: "info", category: "Best Practice", message: `✓ Good text content (${textLength} characters) — solid text-to-HTML ratio` });
  }

  // ── Score calculation ────────────────────────────────────────────────────
  // Start at 100, deduct for errors/warnings
  let score = 100;
  const errors = findings.filter(f => f.severity === "error");
  const warnings = findings.filter(f => f.severity === "warning");
  score -= errors.length * 15;
  score -= warnings.length * 5;
  score = Math.max(0, Math.min(100, score));

  let grade: string;
  if (score >= 90) grade = "A";
  else if (score >= 80) grade = "B";
  else if (score >= 65) grade = "C";
  else if (score >= 50) grade = "D";
  else grade = "F";

  return {
    score,
    grade,
    findings,
    stats: {
      htmlSize: `${sizeKb} KB`,
      textLength,
      imageCount: imgTags.length,
      linkCount: links.length,
      spamWords: hitBodySpam.length,
      errors: errors.length,
      warnings: warnings.length,
    },
  };
}

// ─── Routes ────────────────────────────────────────────────────────────────

router.post("/check", (req, res) => {
  const { html = "", subject = "", fromEmail = "" } = req.body ?? {};
  if (typeof html !== "string") {
    res.status(400).json({ error: "html must be a string" });
    return;
  }
  const result = checkDeliverability(html, subject, fromEmail);
  res.json(result);
});

export default router;
