import { Router } from "express";
import { db, deliveriesTable } from "@workspace/db";
import { eq, count, sql } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res) => {
  const page = parseInt(req.query.page as string) || 1;
  const limit = Math.min(parseInt(req.query.limit as string) || 50, 200);
  const offset = (page - 1) * limit;
  const campaignId = req.query.campaignId ? parseInt(req.query.campaignId as string) : undefined;
  const status = req.query.status as string;

  let query = db.select().from(deliveriesTable) as any;
  let countQuery = db.select({ count: count() }).from(deliveriesTable) as any;

  const conditions = [];
  if (campaignId) conditions.push(eq(deliveriesTable.campaignId, campaignId));
  if (status) conditions.push(eq(deliveriesTable.status, status));

  if (conditions.length > 0) {
    const where = conditions.reduce((a, b) => sql`${a} AND ${b}`);
    query = query.where(where);
    countQuery = countQuery.where(where);
  }

  const [totalRow] = await countQuery;
  const data = await query.limit(limit).offset(offset).orderBy(sql`${deliveriesTable.createdAt} DESC`);

  res.json({ data, total: Number(totalRow.count), page, limit });
});

router.get("/stats", async (_req, res) => {
  const [sent] = await db.select({ count: count() }).from(deliveriesTable).where(eq(deliveriesTable.status, "sent"));
  const [failed] = await db.select({ count: count() }).from(deliveriesTable).where(eq(deliveriesTable.status, "failed"));
  const [pending] = await db.select({ count: count() }).from(deliveriesTable).where(eq(deliveriesTable.status, "pending"));
  const total = Number(sent.count) + Number(failed.count) + Number(pending.count);
  const deliveryRate = total > 0 ? Number(sent.count) / total : 0;

  const byChannelRaw = await db.execute(sql`
    SELECT channel, status, COUNT(*) as cnt FROM deliveries GROUP BY channel, status
  `);
  const byChannel: Record<string, any> = {};
  for (const row of byChannelRaw.rows as any[]) {
    if (!byChannel[row.channel]) byChannel[row.channel] = { sent: 0, failed: 0, pending: 0 };
    byChannel[row.channel][row.status] = parseInt(row.cnt);
  }

  const byCampaign = await db.execute(sql`
    SELECT campaign_id, campaign_name,
      COUNT(*) FILTER (WHERE status='sent') as sent,
      COUNT(*) FILTER (WHERE status='failed') as failed
    FROM deliveries WHERE campaign_id IS NOT NULL
    GROUP BY campaign_id, campaign_name
    ORDER BY sent DESC LIMIT 10
  `);

  const recentActivity = await db.execute(sql`
    SELECT DATE_TRUNC('hour', created_at) as hour,
      COUNT(*) FILTER (WHERE status='sent') as sent,
      COUNT(*) FILTER (WHERE status='failed') as failed
    FROM deliveries
    WHERE created_at > NOW() - INTERVAL '24 hours'
    GROUP BY hour ORDER BY hour ASC
  `);

  res.json({
    totalSent: Number(sent.count),
    totalFailed: Number(failed.count),
    totalPending: Number(pending.count),
    deliveryRate,
    byChannel,
    byCampaign: byCampaign.rows,
    recentActivity: recentActivity.rows,
  });
});

export default router;
