import { Router } from "express";
import { db, leadsTable, leadFoldersTable } from "@workspace/db";
import { eq, count, and, inArray } from "drizzle-orm";
import { parse as parseCsv } from "csv-parse/sync";
import { DATABASE_UNAVAILABLE_CODE, DATABASE_UNAVAILABLE_MESSAGE, isDisabledDatabaseEndpoint } from "../lib/import-errors";

const router = Router();

type ParsedLead = {
  value: string;
  type: string;
  firstName?: string;
  lastName?: string;
  extra?: string;
};

const normalizeColumn = (value: string) => value.toLowerCase().replace(/[^a-z0-9]/g, "");

function parseLeads(content: string, type: string, format: string): {
  rows: ParsedLead[];
  invalidCount: number;
  errors: string[];
} {
  const text = content.replace(/^\uFEFF/, "");
  const firstLine = text.split(/\r?\n/).find(line => line.trim()) ?? "";
  const isCsv = format === "csv" || (format === "auto" && firstLine.includes(","));
  const records: string[][] = isCsv
    ? parseCsv(text, {
        bom: true,
        skip_empty_lines: true,
        trim: true,
        relax_column_count: true,
      }) as string[][]
    : text.split(/\r?\n/).filter(line => line.trim()).map(line => [line.trim()]);

  const valueHeaders = type === "sms"
    ? ["phone", "phonenumber", "mobilenumber", "mobile", "number", "contact", "contactvalue", "value"]
    : ["email", "emailaddress", "emailid", "mail", "contact", "contactvalue", "address", "value"];
  const firstHeaders = records[0]?.map(normalizeColumn) ?? [];
  const valueIndex = firstHeaders.findIndex(header => valueHeaders.includes(header));
  const hasHeader = valueIndex >= 0;
  const firstNameIndex = hasHeader
    ? firstHeaders.findIndex(header => ["firstname", "givenname", "first"].includes(header))
    : 1;
  const lastNameIndex = hasHeader
    ? firstHeaders.findIndex(header => ["lastname", "surname", "familyname", "last"].includes(header))
    : 2;
  const start = hasHeader ? 1 : 0;
  const rows: ParsedLead[] = [];
  const errors: string[] = [];
  let invalidCount = 0;

  for (let index = start; index < records.length; index++) {
    const record = records[index];
    const rawValue = record[hasHeader ? valueIndex : 0] ?? "";
    const value = rawValue.trim();
    if (!value) {
      invalidCount++;
      if (errors.length < 20) errors.push(`Row ${index + 1}: missing ${type === "sms" ? "phone number" : "email address"}.`);
      continue;
    }

    const usedIndexes = new Set([hasHeader ? valueIndex : 0, firstNameIndex, lastNameIndex]);
    const extra = record.filter((_cell, columnIndex) => !usedIndexes.has(columnIndex) && record[columnIndex]?.trim())
      .join(",")
      .trim();

    rows.push({
      value: type === "email" ? value.toLowerCase() : value,
      type,
      firstName: firstNameIndex >= 0 ? record[firstNameIndex]?.trim() || undefined : undefined,
      lastName: lastNameIndex >= 0 ? record[lastNameIndex]?.trim() || undefined : undefined,
      extra: extra || undefined,
    });
  }

  return { rows, invalidCount, errors };
}

// ─── Folders ────────────────────────────────────────────────────────────────

router.get("/folders", async (_req, res) => {
  const folders = await db.select().from(leadFoldersTable).orderBy(leadFoldersTable.createdAt);
  const withCounts = await Promise.all(
    folders.map(async (folder) => {
      const [row] = await db.select({ count: count() }).from(leadsTable).where(eq(leadsTable.folderId, folder.id));
      return { ...folder, leadCount: Number(row.count) };
    })
  );
  res.json(withCounts);
});

router.post("/folders", async (req, res) => {
  const { name, type } = req.body;
  if (!name) return res.status(400).json({ error: "name required" });
  const [row] = await db.insert(leadFoldersTable).values({ name, type: type || "email" }).returning();
  res.status(201).json({ ...row, leadCount: 0 });
});

router.patch("/folders/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const { name } = req.body;
  if (!name) return res.status(400).json({ error: "name required" });
  const [row] = await db.update(leadFoldersTable).set({ name }).where(eq(leadFoldersTable.id, id)).returning();
  if (!row) return res.status(404).json({ error: "Not found" });
  res.json(row);
});

router.delete("/folders/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  await db.delete(leadsTable).where(eq(leadsTable.folderId, id));
  await db.delete(leadFoldersTable).where(eq(leadFoldersTable.id, id));
  res.status(204).send();
});

// ─── Leads ──────────────────────────────────────────────────────────────────

router.get("/", async (req, res) => {
  const page = parseInt(req.query.page as string) || 1;
  const limit = Math.min(parseInt(req.query.limit as string) || 100, 1000);
  const offset = (page - 1) * limit;
  const type = req.query.type as string;
  const folderId = req.query.folderId ? parseInt(req.query.folderId as string) : undefined;
  const status = req.query.status as string;

  const conditions: any[] = [];
  if (type && type !== "all") conditions.push(eq(leadsTable.type, type));
  if (folderId !== undefined) conditions.push(eq(leadsTable.folderId, folderId));
  if (status && status !== "all") conditions.push(eq(leadsTable.status, status));

  const whereClause = conditions.length > 0 ? and(...conditions) : undefined;
  const [totalRow] = await db.select({ count: count() }).from(leadsTable).where(whereClause);
  const data = await db.select().from(leadsTable).where(whereClause).limit(limit).offset(offset).orderBy(leadsTable.createdAt);

  res.json({ data, total: Number(totalRow.count), page, limit });
});

// ─── Chunked bulk upload ─────────────────────────────────────────────────────
// Accepts { content, type, format, folderId } — content can be any size.
// Uses batch duplicate-check (inArray) + bulk INSERT instead of per-row queries,
// making imports of 100k+ leads fast without browser / server timeout issues.
router.post("/upload", async (req, res) => {
  const { content, type, format = "auto", folderId } = req.body;
  if (typeof content !== "string" || !content.trim()) {
    res.status(400).json({ error: "Choose a non-empty TXT or CSV file." });
    return;
  }
  if (type !== "email" && type !== "sms") {
    res.status(400).json({ error: "Choose Email or SMS before uploading." });
    return;
  }
  if (format !== "auto" && format !== "csv" && format !== "txt") {
    res.status(400).json({ error: "Unsupported file format. Use TXT or CSV." });
    return;
  }
  if (folderId !== undefined && (!Number.isInteger(Number(folderId)) || Number(folderId) < 1)) {
    res.status(400).json({ error: "The selected folder is invalid. Refresh the page and try again." });
    return;
  }

  let parsed: ReturnType<typeof parseLeads>;
  try {
    parsed = parseLeads(content, type, format);
  } catch {
    res.status(400).json({ error: "Could not read this CSV. Check that quotes and columns are valid, then try again." });
    return;
  }

  let imported = 0;
  let duplicates = 0;
  let failed = parsed.invalidCount;
  const errors = [...parsed.errors];
  const folderIdVal = folderId === undefined ? null : Number(folderId);
  const CHUNK_SIZE = 500;

  for (let i = 0; i < parsed.rows.length; i += CHUNK_SIZE) {
    const chunk = parsed.rows.slice(i, i + CHUNK_SIZE);
    const uniqueInChunk = new Map<string, ParsedLead>();
    for (const lead of chunk) {
      const key = type === "email" ? lead.value.toLowerCase() : lead.value;
      if (uniqueInChunk.has(key)) duplicates++;
      else uniqueInChunk.set(key, lead);
    }
    const uniqueLeads = [...uniqueInChunk.values()];
    const chunkValues = uniqueLeads.map(lead => lead.value);

    try {
      const existing = await db
        .select({ value: leadsTable.value })
        .from(leadsTable)
        .where(and(inArray(leadsTable.value, chunkValues), eq(leadsTable.type, type)));

      const existingSet = new Set(existing.map(row => type === "email" ? row.value.toLowerCase() : row.value));
      const newLeads = uniqueLeads.filter(lead => !existingSet.has(type === "email" ? lead.value.toLowerCase() : lead.value));
      duplicates += uniqueLeads.length - newLeads.length;

      if (newLeads.length > 0) {
        await db.insert(leadsTable).values(
          newLeads.map(lead => ({
            value: lead.value,
            type: lead.type,
            firstName: lead.firstName ?? null,
            lastName: lead.lastName ?? null,
            extra: lead.extra ?? null,
            folderId: folderIdVal,
          })),
        );
        imported += newLeads.length;
      }
    } catch (error) {
      if (isDisabledDatabaseEndpoint(error)) {
        req.log.warn({ batch: Math.floor(i / CHUNK_SIZE) + 1 }, "Lead import stopped because the database endpoint is disabled");
        const total = parsed.rows.length + parsed.invalidCount;
        res.status(503).json({
          code: DATABASE_UNAVAILABLE_CODE,
          error: DATABASE_UNAVAILABLE_MESSAGE,
          imported,
          duplicates,
          failed: Math.max(0, total - imported - duplicates),
          total,
          ...(errors.length ? { errors } : {}),
        });
        return;
      }
      failed += uniqueLeads.length;
      req.log.error({
        errorName: error instanceof Error ? error.name : "UnknownError",
        batch: Math.floor(i / CHUNK_SIZE) + 1,
      }, "Lead import batch failed");
      if (errors.length < 20) {
        errors.push(`Batch ${Math.floor(i / CHUNK_SIZE) + 1}: the database could not save these rows. Retry this file.`);
      }
    }
  }

  res.json({
    imported,
    duplicates,
    failed,
    total: parsed.rows.length + parsed.invalidCount,
    ...(errors.length ? { errors } : {}),
  });
});

router.get("/stats", async (_req, res) => {
  const [emailRow] = await db.select({ count: count() }).from(leadsTable).where(eq(leadsTable.type, "email"));
  const [smsRow] = await db.select({ count: count() }).from(leadsTable).where(eq(leadsTable.type, "sms"));
  const [bouncedRow] = await db.select({ count: count() }).from(leadsTable).where(eq(leadsTable.status, "bounced"));
  const [unsubRow] = await db.select({ count: count() }).from(leadsTable).where(eq(leadsTable.status, "unsubscribed"));
  const totalEmail = Number(emailRow.count);
  const totalSms = Number(smsRow.count);
  const totalBounced = Number(bouncedRow.count);
  const totalUnsubscribed = Number(unsubRow.count);
  res.json({ totalEmail, totalSms, total: totalEmail + totalSms, totalBounced, totalUnsubscribed });
});

router.post("/:id/unsubscribe", async (req, res) => {
  const id = parseInt(req.params.id);
  const [row] = await db.update(leadsTable)
    .set({ status: "unsubscribed", unsubscribedAt: new Date() })
    .where(eq(leadsTable.id, id))
    .returning();
  if (!row) return res.status(404).json({ error: "Not found" });
  res.json(row);
});

router.post("/:id/reactivate", async (req, res) => {
  const id = parseInt(req.params.id);
  const [row] = await db.update(leadsTable)
    .set({ status: "active", bouncedAt: null, unsubscribedAt: null })
    .where(eq(leadsTable.id, id))
    .returning();
  if (!row) return res.status(404).json({ error: "Not found" });
  res.json(row);
});

router.post("/bulk-unsubscribe", async (req, res) => {
  const { values } = req.body;
  if (!Array.isArray(values) || values.length === 0) return res.status(400).json({ error: "values array required" });
  let updated = 0;
  for (const value of values) {
    const result = await db.update(leadsTable)
      .set({ status: "unsubscribed", unsubscribedAt: new Date() })
      .where(eq(leadsTable.value, value));
    updated += result.rowCount ?? 0;
  }
  res.json({ updated });
});

router.delete("/", async (_req, res) => {
  await db.delete(leadsTable);
  res.status(204).send();
});

router.delete("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  await db.delete(leadsTable).where(eq(leadsTable.id, id));
  res.status(204).send();
});

export default router;
