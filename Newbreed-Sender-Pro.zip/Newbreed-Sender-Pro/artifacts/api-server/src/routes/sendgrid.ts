import { Router } from "express";
import { db, sendgridConfigsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import sgMail from "@sendgrid/mail";

const router = Router();

async function verifySendgridCredentials(apiKey: string, fromEmail?: string | null) {
  try {
    const response = await fetch("https://api.sendgrid.com/v3/user/profile", {
      headers: { Authorization: `Bearer ${apiKey}` },
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    const profile = await response.json() as any;

    const senderResponse = await fetch("https://api.sendgrid.com/v3/verified_senders", {
      headers: { Authorization: `Bearer ${apiKey}` },
    });
    const senderData = senderResponse.ok ? await senderResponse.json() as any : { results: [] };
    const senderVerified = fromEmail
      ? (senderData.results || []).some((s: any) => s.from_email === fromEmail && s.verified)
      : false;

    return {
      success: true,
      senderVerified,
      message: `SendGrid API key verified for ${profile.username || "account"}`,
      details: `Username: ${profile.username || "unknown"}, Email: ${profile.email || "unknown"}`,
    };
  } catch (error: any) {
    return {
      success: false,
      senderVerified: false,
      message: "SendGrid verification failed",
      details: error?.message || "Invalid SendGrid API key",
    };
  }
}

function safeSendgridConfig(row: any) {
  return { ...row, apiKey: row.apiKey ? "SG.***" + row.apiKey.slice(-4) : "" };
}

router.get("/", async (_req, res) => {
  const rows = await db.select().from(sendgridConfigsTable).orderBy(sendgridConfigsTable.createdAt);
  const safe = rows.map(safeSendgridConfig);
  res.json(safe);
});

router.post("/", async (req, res) => {
  const { label, apiKey, fromEmail, fromName } = req.body;
  if (!apiKey) return res.status(400).json({ error: "apiKey required" });
  const [row] = await db.insert(sendgridConfigsTable).values({ label, apiKey, fromEmail, fromName }).returning();
  const verification = await verifySendgridCredentials(apiKey, fromEmail);
  const [updated] = await db.update(sendgridConfigsTable).set({ status: verification.success ? "verified" : "failed" }).where(eq(sendgridConfigsTable.id, row.id)).returning();
  res.status(201).json({ ...safeSendgridConfig(updated), verification });
});

router.patch("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const { label, apiKey, fromEmail, fromName } = req.body;
  const updates: Record<string, any> = {};
  if (label !== undefined) updates.label = label;
  if (apiKey !== undefined) updates.apiKey = apiKey;
  if (fromEmail !== undefined) updates.fromEmail = fromEmail;
  if (fromName !== undefined) updates.fromName = fromName;
  const [row] = await db.update(sendgridConfigsTable).set(updates).where(eq(sendgridConfigsTable.id, id)).returning();
  if (!row) return res.status(404).json({ error: "Not found" });
  const verification = await verifySendgridCredentials(row.apiKey, row.fromEmail);
  const [updated] = await db.update(sendgridConfigsTable).set({ status: verification.success ? "verified" : "failed" }).where(eq(sendgridConfigsTable.id, id)).returning();
  res.json({ ...safeSendgridConfig(updated), verification });
});

router.delete("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  await db.delete(sendgridConfigsTable).where(eq(sendgridConfigsTable.id, id));
  res.status(204).send();
});

router.post("/:id/verify", async (req, res) => {
  const id = parseInt(req.params.id);
  const [cfg] = await db.select().from(sendgridConfigsTable).where(eq(sendgridConfigsTable.id, id));
  if (!cfg) return res.status(404).json({ error: "Not found" });

  try {
    const verification = await verifySendgridCredentials(cfg.apiKey, cfg.fromEmail);
    await db.update(sendgridConfigsTable).set({ status: verification.success ? "verified" : "failed" }).where(eq(sendgridConfigsTable.id, id));
    res.json(verification);
  } catch (e: any) {
    await db.update(sendgridConfigsTable).set({ status: "failed" }).where(eq(sendgridConfigsTable.id, id));
    res.json({ success: false, message: "SendGrid verification failed", senderVerified: false, details: e.message });
  }
});

router.post("/:id/send", async (req, res) => {
  const id = parseInt(req.params.id);
  const [cfg] = await db.select().from(sendgridConfigsTable).where(eq(sendgridConfigsTable.id, id));
  if (!cfg) return res.status(404).json({ error: "Not found" });

  const { to, fromEmail, fromName, subject, body, isHtml, attachments } = req.body;
  if (!to || !subject || !body) return res.status(400).json({ error: "to, subject, body required" });

  const senderEmail = fromEmail || cfg.fromEmail;
  const senderName = fromName || cfg.fromName || "Newbreed Pro Sender";

  if (!senderEmail) return res.status(400).json({ error: "Sender email required" });

  try {
    sgMail.setApiKey(cfg.apiKey);
    const msg: any = {
      to,
      from: { email: senderEmail, name: senderName },
      subject,
      ...(isHtml ? { html: body } : { text: body }),
    };

    if (attachments && Array.isArray(attachments)) {
      msg.attachments = attachments.map((a: any) => ({
        content: a.content,
        filename: a.filename,
        type: a.contentType || "application/octet-stream",
        disposition: "attachment",
      }));
    }

    const [result] = await sgMail.send(msg);
    res.json({ success: true, message: "Email sent", messageId: result.headers["x-message-id"] || null });
  } catch (e: any) {
    res.json({ success: false, message: e.message, messageId: null });
  }
});

export default router;
