import { Router } from "express";
import { db, campaignsTable, leadsTable, deliveriesTable, smtpsTable, awsConfigsTable, sendgridConfigsTable, resendConfigsTable, smsConfigsTable, leadFoldersTable } from "@workspace/db";
import { eq, count, and, isNotNull, ne } from "drizzle-orm";
import { SNSClient, PublishCommand } from "@aws-sdk/client-sns";
import { detectCarrierGateway, toSmsGatewayEmail } from "../carrier-lookup";
import { resolveTwilioSenderNumber } from "../lib/twilio";
import { getWarmupCapForSmtp, recordWarmupSend } from "./warmup";

import nodemailer from "nodemailer";
import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";
import sgMail from "@sendgrid/mail";
import { sendViaResend } from "./resend";

const BOUNCE_PATTERNS = [
  /user unknown/i, /no such user/i, /mailbox not found/i, /does not exist/i,
  /invalid address/i, /address rejected/i, /recipient rejected/i,
  /undeliverable/i, /permanent.{0,20}fail/i, /bounce/i,
  /550/i, /551/i, /553/i, /5\.1\.[123]/i,
];

function isBounceError(msg: string) {
  return BOUNCE_PATTERNS.some(p => p.test(msg));
}

const router = Router();
export const runningCampaigns = new Set<number>();

function recipientKey(value: string) {
  return value.trim().toLowerCase();
}

async function sendWithSmtp(smtp: any, fromName: string, fromEmail: string, to: string, subject: string, body: string, isHtml: boolean) {
  // Use port-based secure detection — port 465 = implicit SSL, everything else = STARTTLS.
  // This mirrors the test logic so campaigns always succeed for the same SMTPs that pass testing.
  const port = smtp.port as number;
  const secure = port === 465;

  async function trySend(p: number, s: boolean): Promise<void> {
    const transporter = nodemailer.createTransport({
      host: smtp.host,
      port: p,
      secure: s,
      auth: { user: smtp.user, pass: smtp.pass },
      tls: { rejectUnauthorized: false },
      connectionTimeout: 15000,
      greetingTimeout: 10000,
    });
    try {
      const info = await transporter.sendMail({
        from: `"${fromName}" <${fromEmail || smtp.user}>`,
        to,
        subject,
        ...(isHtml ? { html: body } : { text: body }),
      });
      const accepted = Array.isArray(info.accepted) ? info.accepted : [];
      const rejected = Array.isArray(info.rejected) ? info.rejected : [];
      if (accepted.length === 0 || rejected.length > 0) {
        throw new Error(
          rejected.length > 0
            ? `SMTP rejected recipient: ${rejected.join(", ")}`
            : "SMTP server did not accept the recipient"
        );
      }
    } finally {
      try { transporter.close(); } catch {}
    }
  }

  try {
    await trySend(port, secure);
  } catch (e: any) {
    // Try the alternate port once before giving up
    const altPort = port === 587 ? 465 : port === 465 ? 587 : null;
    if (altPort) {
      await trySend(altPort, altPort === 465);
    } else {
      throw e;
    }
  }
}

async function sendWithAws(awsCfg: any, fromName: string, fromEmail: string, to: string, subject: string, body: string, isHtml: boolean) {
  const client = new SESClient({
    region: awsCfg.region,
    credentials: { accessKeyId: awsCfg.accessKeyId, secretAccessKey: awsCfg.secretAccessKey },
  });
  await client.send(new SendEmailCommand({
    Source: `"${fromName}" <${fromEmail}>`,
    Destination: { ToAddresses: [to] },
    Message: {
      Subject: { Data: subject, Charset: "UTF-8" },
      Body: isHtml ? { Html: { Data: body, Charset: "UTF-8" } } : { Text: { Data: body, Charset: "UTF-8" } },
    },
  }));
}

async function sendWithSendgrid(sgCfg: any, fromName: string, fromEmail: string, to: string, subject: string, body: string, isHtml: boolean) {
  sgMail.setApiKey(sgCfg.apiKey);
  await sgMail.send({
    from: { email: fromEmail, name: fromName },
    to,
    subject,
    ...(isHtml ? { html: body } : { text: body }),
  });
}

export async function triggerCampaign(id: number): Promise<void> {
  if (runningCampaigns.has(id)) return;

  const [campaign] = await db.select().from(campaignsTable).where(eq(campaignsTable.id, id));
  if (!campaign) return;

  await db.update(campaignsTable).set({ status: "sending", startedAt: new Date(), updatedAt: new Date() }).where(eq(campaignsTable.id, id));
  runningCampaigns.add(id);

  try {
    // Build lead filter — folder takes priority, then fallback to leadType; always skip bounced/unsubscribed
    const conditions: any[] = [ne(leadsTable.status, "bounced"), ne(leadsTable.status, "unsubscribed")];
    if (campaign.leadFolderId) {
      conditions.push(eq(leadsTable.folderId, campaign.leadFolderId));
    } else if (campaign.leadType) {
      conditions.push(eq(leadsTable.type, campaign.leadType));
    }
    const allLeads = await db.select().from(leadsTable).where(and(...conditions));
    const previousDeliveries = await db.select({
      recipient: deliveriesTable.recipient,
      status: deliveriesTable.status,
    }).from(deliveriesTable).where(eq(deliveriesTable.campaignId, id));
    const sentRecipients = new Set(
      previousDeliveries
        .filter((delivery) => delivery.status === "sent")
        .map((delivery) => recipientKey(delivery.recipient)),
    );
    const leads = allLeads.filter((lead) => !sentRecipients.has(recipientKey(lead.value)));

    const smtpList = campaign.rotateSmtps ? await db.select().from(smtpsTable).where(eq(smtpsTable.status, "verified")) : [];
    let smtpIndex = 0;
    let sent = sentRecipients.size;
    let failed = previousDeliveries.filter((delivery) => delivery.status === "failed").length;

    // Calculate inter-send delay from rate (0 = unlimited, use 100ms default)
    const rate = campaign.sendRatePerMinute ?? 0;
    const delayMs = rate > 0 ? Math.round(60000 / rate) : 100;

    for (const lead of leads) {
      if (!runningCampaigns.has(id)) break;

      const currentCampaign = (await db.select().from(campaignsTable).where(eq(campaignsTable.id, id)))[0];
      if (currentCampaign?.status === "paused") break;
      if (sentRecipients.has(recipientKey(lead.value))) continue;

      try {
        const fromName = campaign.fromName || "Newbreed Pro Sender";
        const fromEmail = campaign.fromEmail || "";
        const senderType = campaign.senderType;
        let deliveryMessageId: string | undefined;

        if (senderType === "smtp" || (!senderType && campaign.smtpId)) {
          let smtp: any;
          if (campaign.rotateSmtps && smtpList.length > 0) {
            smtp = smtpList[smtpIndex % smtpList.length];
            smtpIndex++;
          } else if (campaign.smtpId) {
            smtp = (await db.select().from(smtpsTable).where(eq(smtpsTable.id, campaign.smtpId)))[0];
          }
          if (!smtp) {
            throw new Error(
              campaign.rotateSmtps
                ? "No verified SMTPs are available for rotation"
                : "No SMTP server is selected for this campaign"
            );
          }
          // Warmup cap: check if this SMTP has an active warmup plan
          const warmupCap = await getWarmupCapForSmtp(smtp.id);
          if (warmupCap && warmupCap.usedToday >= warmupCap.limit) {
            // Daily warmup limit reached — skip remaining leads for today
            break;
          }
          await sendWithSmtp(smtp, fromName, fromEmail || smtp.user, lead.value, campaign.subject || "", campaign.body || "", campaign.isHtml || false);
          if (warmupCap) await recordWarmupSend(warmupCap.planId);
        } else if (senderType === "aws" || campaign.awsConfigId) {
          const awsCfg = (await db.select().from(awsConfigsTable).where(eq(awsConfigsTable.id, campaign.awsConfigId!)))[0];
          if (!awsCfg) throw new Error("AWS sender configuration is missing");
          await sendWithAws(awsCfg, fromName, fromEmail || awsCfg.fromEmail || "", lead.value, campaign.subject || "", campaign.body || "", campaign.isHtml || false);
        } else if (senderType === "sendgrid" || campaign.sendgridConfigId) {
          const sgCfg = (await db.select().from(sendgridConfigsTable).where(eq(sendgridConfigsTable.id, campaign.sendgridConfigId!)))[0];
          if (!sgCfg) throw new Error("SendGrid sender configuration is missing");
          await sendWithSendgrid(sgCfg, fromName, fromEmail || sgCfg.fromEmail || "", lead.value, campaign.subject || "", campaign.body || "", campaign.isHtml || false);
        } else if (senderType === "resend" || campaign.resendConfigId) {
          const resendCfg = (await db.select().from(resendConfigsTable).where(eq(resendConfigsTable.id, campaign.resendConfigId!)))[0];
          if (!resendCfg) throw new Error("Resend sender configuration is missing");
          const result = await sendViaResend(resendCfg, {
            to: lead.value,
            fromEmail: fromEmail || resendCfg.fromEmail,
            fromName: fromName || resendCfg.fromName || undefined,
            subject: campaign.subject || "",
            body: campaign.body || "",
            isHtml: campaign.isHtml || false,
          });
          deliveryMessageId = result.id;
        } else if (senderType === "sms" && campaign.smsConfigId) {
          const smsCfg = (await db.select().from(smsConfigsTable).where(eq(smsConfigsTable.id, campaign.smsConfigId)))[0];
          if (smsCfg) {
            if (smsCfg.provider === "twilio") {
              const fromNumber = await resolveTwilioSenderNumber(smsCfg.accountSid || "", smsCfg.authToken, smsCfg.fromNumber);
              if (!smsCfg.fromNumber) {
                await db.update(smsConfigsTable).set({ fromNumber }).where(eq(smsConfigsTable.id, smsCfg.id));
              }
              const url = `https://api.twilio.com/2010-04-01/Accounts/${smsCfg.accountSid}/Messages.json`;
              const body = new URLSearchParams({ To: lead.value, From: fromNumber, Body: campaign.body || "" });
              const r = await fetch(url, {
                method: "POST",
                headers: {
                  Authorization: "Basic " + Buffer.from(`${smsCfg.accountSid}:${smsCfg.authToken}`).toString("base64"),
                  "Content-Type": "application/x-www-form-urlencoded",
                },
                body,
              });
              if (!r.ok) {
                const err = await r.json() as any;
                throw new Error(err.message || "Twilio error");
              }
            } else if (smsCfg.provider === "aws_sns") {
              const awsCfg = smsCfg.awsConfigId ? (await db.select().from(awsConfigsTable).where(eq(awsConfigsTable.id, smsCfg.awsConfigId)))[0] : null;
              if (!awsCfg) throw new Error("AWS config not found for SMS");
              const sns = new SNSClient({
                region: awsCfg.region,
                credentials: { accessKeyId: awsCfg.accessKeyId, secretAccessKey: awsCfg.secretAccessKey },
              });
              await sns.send(new PublishCommand({ PhoneNumber: lead.value, Message: campaign.body || "" }));
            } else if (smsCfg.provider === "smtp_sms") {
              if (!smsCfg.smtpId || !smsCfg.gatewayDomain) throw new Error("SMTP-to-SMS config missing smtpId or gatewayDomain");
              const resolvedDomain = smsCfg.gatewayDomain === "auto"
                ? detectCarrierGateway(lead.value).gateway
                : smsCfg.gatewayDomain;
              const toGateway = toSmsGatewayEmail(lead.value, resolvedDomain);
              const [smtp] = await db.select().from(smtpsTable).where(eq(smtpsTable.id, smsCfg.smtpId));
              if (!smtp) throw new Error("SMTP not found for SMTP-to-SMS");
              await sendWithSmtp(smtp, "", smtp.user, toGateway, "", campaign.body || "", false);
            }
          }
        } else {
          throw new Error("Campaign has no valid sender configured");
        }

        await db.insert(deliveriesTable).values({
          campaignId: id, campaignName: campaign.name, recipient: lead.value,
          status: "sent", channel: campaign.type || "email", subject: campaign.subject,
          messageId: deliveryMessageId,
        });
        sentRecipients.add(recipientKey(lead.value));
        sent++;
      } catch (e: any) {
        const errMsg = e.message || "";
        await db.insert(deliveriesTable).values({
          campaignId: id, campaignName: campaign.name, recipient: lead.value,
          status: "failed", channel: campaign.type || "email", subject: campaign.subject,
          error: errMsg,
        });
        // Auto-mark lead as bounced if error looks like a hard bounce
        if (isBounceError(errMsg)) {
          await db.update(leadsTable)
            .set({ status: "bounced", bouncedAt: new Date() })
            .where(eq(leadsTable.id, lead.id));
        }
        failed++;
      }

      await db.update(campaignsTable).set({ totalSent: sent, totalFailed: failed, updatedAt: new Date() }).where(eq(campaignsTable.id, id));
      await new Promise(r => setTimeout(r, delayMs));
    }

    await db.update(campaignsTable).set({
      status: "completed", finishedAt: new Date(), totalSent: sent, totalFailed: failed, updatedAt: new Date()
    }).where(eq(campaignsTable.id, id));
  } catch (e: any) {
    await db.update(campaignsTable).set({ status: "failed", updatedAt: new Date() }).where(eq(campaignsTable.id, id));
  } finally {
    runningCampaigns.delete(id);
  }
}

router.get("/scheduled", async (_req, res) => {
  const rows = await db.select().from(campaignsTable)
    .where(and(eq(campaignsTable.status, "scheduled"), isNotNull(campaignsTable.scheduledAt)));
  res.json(rows);
});

router.get("/", async (_req, res) => {
  const rows = await db.select().from(campaignsTable).orderBy(campaignsTable.createdAt);
  res.json(rows);
});

router.post("/", async (req, res) => {
  const {
    name, type, subject, body, isHtml, fromName, fromEmail, senderType,
    smtpId, awsConfigId, sendgridConfigId, resendConfigId, smsConfigId, rotateSmtps, useProxy,
    attachments, leadType, leadFolderId, sendRatePerMinute, scheduledAt
  } = req.body;
  if (!name || !body) return res.status(400).json({ error: "name and body required" });

  // Count leads for the target audience
  let totalLeads = 0;
  if (leadFolderId) {
    const [r] = await db.select({ count: count() }).from(leadsTable).where(eq(leadsTable.folderId, parseInt(leadFolderId)));
    totalLeads = Number(r.count);
  } else {
    const [r] = await db.select({ count: count() }).from(leadsTable).where(eq(leadsTable.type, leadType || "email"));
    totalLeads = Number(r.count);
  }

  const [row] = await db.insert(campaignsTable).values({
    name, type: type || "email", subject, body, isHtml: isHtml || false,
    fromName: fromName || "Newbreed Pro Sender",
    fromEmail, senderType, smtpId, awsConfigId, sendgridConfigId, resendConfigId, smsConfigId,
    rotateSmtps: rotateSmtps || false, useProxy: useProxy || false,
    attachments: attachments ? JSON.stringify(attachments) : null,
    leadType: leadType || "email",
    leadFolderId: leadFolderId ? parseInt(leadFolderId) : null,
    sendRatePerMinute: sendRatePerMinute ? parseInt(sendRatePerMinute) : 0,
    totalLeads,
    scheduledAt: scheduledAt ? new Date(scheduledAt) : null,
  }).returning();

  res.status(201).json(row);
});

router.get("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const [row] = await db.select().from(campaignsTable).where(eq(campaignsTable.id, id));
  if (!row) return res.status(404).json({ error: "Not found" });
  res.json(row);
});

router.patch("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const allowed = ["name", "subject", "body", "isHtml", "fromName", "fromEmail", "senderType",
    "smtpId", "awsConfigId", "sendgridConfigId", "resendConfigId", "smsConfigId", "rotateSmtps", "useProxy",
    "attachments", "leadType", "leadFolderId", "sendRatePerMinute", "scheduledAt"];
  const updates: Record<string, any> = { updatedAt: new Date() };
  for (const key of allowed) {
    if (req.body[key] !== undefined) updates[key] = req.body[key];
  }
  if (updates.scheduledAt) updates.scheduledAt = new Date(updates.scheduledAt);
  if (updates.leadFolderId !== undefined) updates.leadFolderId = updates.leadFolderId ? parseInt(updates.leadFolderId) : null;

  // Editing a completed/failed campaign resets it to draft so it can be sent again
  const [current] = await db.select({ status: campaignsTable.status }).from(campaignsTable).where(eq(campaignsTable.id, id));
  if (current && (current.status === "completed" || current.status === "failed")) {
    updates.status = "draft";
    updates.totalSent = 0;
    updates.totalFailed = 0;
    updates.startedAt = null;
    updates.finishedAt = null;
  }

  const [row] = await db.update(campaignsTable).set(updates).where(eq(campaignsTable.id, id)).returning();
  if (!row) return res.status(404).json({ error: "Not found" });
  res.json(row);
});

router.get("/:id/analytics", async (req, res) => {
  const id = parseInt(req.params.id);
  const [campaign] = await db.select().from(campaignsTable).where(eq(campaignsTable.id, id));
  if (!campaign) return res.status(404).json({ error: "Not found" });

  // Determine time bucket: minute if started < 2 hours ago, else hour
  const startedAt = campaign.startedAt ?? campaign.createdAt;
  const ageHours = (Date.now() - new Date(startedAt).getTime()) / 3600000;
  const bucket = ageHours < 2 ? "minute" : "hour";

  const timeline = await db.execute(sql`
    SELECT
      DATE_TRUNC(${bucket}, created_at) as ts,
      COUNT(*) FILTER (WHERE status = 'sent') as sent,
      COUNT(*) FILTER (WHERE status = 'failed') as failed
    FROM deliveries
    WHERE campaign_id = ${id}
    GROUP BY ts
    ORDER BY ts ASC
  `);

  const totals = await db.execute(sql`
    SELECT
      COUNT(*) FILTER (WHERE status = 'sent') as sent,
      COUNT(*) FILTER (WHERE status = 'failed') as failed,
      COUNT(*) FILTER (WHERE status = 'pending') as pending,
      MIN(created_at) as first_sent,
      MAX(created_at) as last_sent
    FROM deliveries WHERE campaign_id = ${id}
  `);

  const recentFailures = await db.execute(sql`
    SELECT recipient, error, created_at
    FROM deliveries
    WHERE campaign_id = ${id} AND status = 'failed'
    ORDER BY created_at DESC LIMIT 20
  `);

  const t = totals.rows[0] as any;
  const totalSent = parseInt(t?.sent ?? 0);
  const totalFailed = parseInt(t?.failed ?? 0);
  const total = totalSent + totalFailed;
  const deliveryRate = total > 0 ? totalSent / total : 0;

  let avgPerMinute = 0;
  if (t?.first_sent && t?.last_sent) {
    const ms = new Date(t.last_sent).getTime() - new Date(t.first_sent).getTime();
    avgPerMinute = ms > 0 ? totalSent / (ms / 60000) : totalSent;
  }

  res.json({
    campaign: { id: campaign.id, name: campaign.name, status: campaign.status, sendRatePerMinute: campaign.sendRatePerMinute },
    timeline: timeline.rows.map((r: any) => ({
      ts: r.ts,
      sent: parseInt(r.sent ?? 0),
      failed: parseInt(r.failed ?? 0),
    })),
    summary: {
      totalSent, totalFailed, total,
      deliveryRate: Math.round(deliveryRate * 100),
      avgPerMinute: Math.round(avgPerMinute * 10) / 10,
      firstSent: t?.first_sent ?? null,
      lastSent: t?.last_sent ?? null,
    },
    recentFailures: recentFailures.rows,
  });
});

router.delete("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  await db.delete(campaignsTable).where(eq(campaignsTable.id, id));
  res.status(204).send();
});

router.post("/:id/send", async (req, res) => {
  const id = parseInt(req.params.id);
  const [campaign] = await db.select().from(campaignsTable).where(eq(campaignsTable.id, id));
  if (!campaign) return res.status(404).json({ error: "Not found" });
  if (runningCampaigns.has(id)) return res.status(400).json({ error: "Campaign already running" });

  await db.update(campaignsTable).set({ status: "sending", startedAt: new Date(), updatedAt: new Date() }).where(eq(campaignsTable.id, id));
  const updated = (await db.select().from(campaignsTable).where(eq(campaignsTable.id, id)))[0];
  res.json(updated);

  triggerCampaign(id).catch(() => {});
});

router.post("/:id/pause", async (req, res) => {
  const id = parseInt(req.params.id);
  runningCampaigns.delete(id);
  const [row] = await db.update(campaignsTable).set({ status: "paused", updatedAt: new Date() }).where(eq(campaignsTable.id, id)).returning();
  if (!row) return res.status(404).json({ error: "Not found" });
  res.json(row);
});

router.post("/:id/schedule", async (req, res) => {
  const id = parseInt(req.params.id);
  const { scheduledAt } = req.body;
  if (!scheduledAt) return res.status(400).json({ error: "scheduledAt is required" });

  const scheduledDate = new Date(scheduledAt);
  if (isNaN(scheduledDate.getTime())) return res.status(400).json({ error: "Invalid date format" });
  if (scheduledDate <= new Date()) return res.status(400).json({ error: "Scheduled time must be in the future" });

  const [row] = await db.update(campaignsTable)
    .set({ status: "scheduled", scheduledAt: scheduledDate, updatedAt: new Date() })
    .where(eq(campaignsTable.id, id))
    .returning();
  if (!row) return res.status(404).json({ error: "Not found" });
  res.json(row);
});

router.post("/:id/unschedule", async (req, res) => {
  const id = parseInt(req.params.id);
  const [row] = await db.update(campaignsTable)
    .set({ status: "draft", scheduledAt: null, updatedAt: new Date() })
    .where(eq(campaignsTable.id, id))
    .returning();
  if (!row) return res.status(404).json({ error: "Not found" });
  res.json(row);
});

router.post("/:id/restart", async (req, res) => {
  const id = parseInt(req.params.id);
  if (runningCampaigns.has(id)) return res.status(400).json({ error: "Campaign is already running — pause it first" });
  const [campaign] = await db.select().from(campaignsTable).where(eq(campaignsTable.id, id));
  if (!campaign) return res.status(404).json({ error: "Not found" });

  await db.update(campaignsTable).set({
    status: "sending",
    startedAt: new Date(), finishedAt: null, updatedAt: new Date(),
  }).where(eq(campaignsTable.id, id));

  const updated = (await db.select().from(campaignsTable).where(eq(campaignsTable.id, id)))[0];
  res.json(updated);
  triggerCampaign(id).catch(() => {});
});

export default router;
