import { Router } from "express";
import { db, awsConfigsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { SESClient, SendEmailCommand, GetSendQuotaCommand, ListVerifiedEmailAddressesCommand } from "@aws-sdk/client-ses";

const router = Router();
const AWS_REGIONS = [
  "af-south-1", "ap-east-1", "ap-northeast-1", "ap-northeast-2", "ap-northeast-3",
  "ap-south-1", "ap-south-2", "ap-southeast-1", "ap-southeast-2", "ap-southeast-3", "ap-southeast-4",
  "ca-central-1", "ca-west-1", "eu-central-1", "eu-central-2", "eu-north-1", "eu-south-1", "eu-south-2",
  "eu-west-1", "eu-west-2", "eu-west-3", "il-central-1", "me-central-1", "me-south-1", "sa-east-1",
  "us-east-1", "us-east-2", "us-west-1", "us-west-2",
];

type AwsVerification = {
  success: boolean;
  senderVerified: boolean;
  message: string;
  details: string;
  region?: string;
};

function getSesClient(cfg: { region: string; accessKeyId: string; secretAccessKey: string }) {
  return new SESClient({
    region: cfg.region,
    credentials: {
      accessKeyId: cfg.accessKeyId,
      secretAccessKey: cfg.secretAccessKey,
    },
  });
}

async function verifyAwsCredentials(cfg: { region: string; accessKeyId: string; secretAccessKey: string; fromEmail?: string | null }): Promise<AwsVerification> {
  const regions = cfg.region === "auto" ? AWS_REGIONS : [cfg.region];
  let lastError = "AWS verification failed";

  for (let index = 0; index < regions.length; index += 6) {
    const batch = regions.slice(index, index + 6);
    const results = await Promise.all(batch.map(async (region) => {
      const client = getSesClient({ ...cfg, region });
      try {
        const quota = await client.send(new GetSendQuotaCommand({}));
        const verified = await client.send(new ListVerifiedEmailAddressesCommand({}));
        const verifiedEmails = verified.VerifiedEmailAddresses || [];
        return {
          success: true as const,
          region,
          senderVerified: cfg.fromEmail ? verifiedEmails.includes(cfg.fromEmail) : false,
          message: `AWS SES credentials verified in ${region}. Quota: ${quota.Max24HourSend}/day.`,
          details: `Verified emails: ${verifiedEmails.join(", ") || "none"}`,
        };
      } catch (error: any) {
        lastError = error?.message || lastError;
        return null;
      } finally {
        client.destroy();
      }
    }));
    const match = results.find((result) => result !== null);
    if (match) return match;
  }

  return { success: false, senderVerified: false, message: "AWS verification failed", details: lastError };
}

function safeAwsConfig(row: any) {
  return { ...row, secretAccessKey: row.secretAccessKey ? "***" + row.secretAccessKey.slice(-4) : "" };
}

router.get("/", async (_req, res) => {
  const rows = await db.select().from(awsConfigsTable).orderBy(awsConfigsTable.createdAt);
  const safe = rows.map(safeAwsConfig);
  res.json(safe);
});

router.post("/", async (req, res) => {
  const { label, region, accessKeyId, secretAccessKey, fromEmail, fromName } = req.body;
  if (!region || !accessKeyId || !secretAccessKey) return res.status(400).json({ error: "region, accessKeyId, secretAccessKey required" });
  const storedRegion = region === "auto" ? "us-east-1" : region;
  const [row] = await db.insert(awsConfigsTable).values({ label, region: storedRegion, accessKeyId, secretAccessKey, fromEmail, fromName }).returning();
  const verification = await verifyAwsCredentials({ region, accessKeyId, secretAccessKey, fromEmail });
  const [updated] = await db.update(awsConfigsTable)
    .set({ status: verification.success ? "verified" : "failed", ...(verification.region ? { region: verification.region } : {}) })
    .where(eq(awsConfigsTable.id, row.id))
    .returning();
  res.status(201).json({ ...safeAwsConfig(updated), verification });
});

router.patch("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const { label, region, accessKeyId, secretAccessKey, fromEmail, fromName } = req.body;
  const updates: Record<string, any> = {};
  if (label !== undefined) updates.label = label;
  if (region !== undefined) updates.region = region;
  if (accessKeyId !== undefined) updates.accessKeyId = accessKeyId;
  if (secretAccessKey !== undefined) updates.secretAccessKey = secretAccessKey;
  if (fromEmail !== undefined) updates.fromEmail = fromEmail;
  if (fromName !== undefined) updates.fromName = fromName;
  const [row] = await db.update(awsConfigsTable).set(updates).where(eq(awsConfigsTable.id, id)).returning();
  if (!row) return res.status(404).json({ error: "Not found" });
  const verification = await verifyAwsCredentials(row);
  const [updated] = await db.update(awsConfigsTable).set({
    status: verification.success ? "verified" : "failed",
    ...(verification.region ? { region: verification.region } : {}),
  }).where(eq(awsConfigsTable.id, id)).returning();
  res.json({ ...safeAwsConfig(updated), verification });
});

router.delete("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  await db.delete(awsConfigsTable).where(eq(awsConfigsTable.id, id));
  res.status(204).send();
});

router.post("/:id/verify", async (req, res) => {
  const id = parseInt(req.params.id);
  const [cfg] = await db.select().from(awsConfigsTable).where(eq(awsConfigsTable.id, id));
  if (!cfg) return res.status(404).json({ error: "Not found" });

  try {
    const verification = await verifyAwsCredentials(cfg);
    if (verification.success) {
      await db.update(awsConfigsTable).set({ status: "verified", region: verification.region }).where(eq(awsConfigsTable.id, id));
    } else {
      await db.update(awsConfigsTable).set({ status: "failed" }).where(eq(awsConfigsTable.id, id));
    }
    res.json(verification);
  } catch (e: any) {
    await db.update(awsConfigsTable).set({ status: "failed" }).where(eq(awsConfigsTable.id, id));
    res.json({ success: false, message: "AWS verification failed", senderVerified: false, details: e.message });
  }
});

router.post("/:id/send", async (req, res) => {
  const id = parseInt(req.params.id);
  const [cfg] = await db.select().from(awsConfigsTable).where(eq(awsConfigsTable.id, id));
  if (!cfg) return res.status(404).json({ error: "Not found" });

  const { to, fromEmail, fromName, subject, body, isHtml } = req.body;
  if (!to || !subject || !body) return res.status(400).json({ error: "to, subject, body required" });

  const senderEmail = fromEmail || cfg.fromEmail;
  const senderName = fromName || cfg.fromName || "Newbreed Pro Sender";

  if (!senderEmail) return res.status(400).json({ error: "Sender email required" });

  try {
    const client = getSesClient(cfg);
    const cmd = new SendEmailCommand({
      Source: `"${senderName}" <${senderEmail}>`,
      Destination: { ToAddresses: [to] },
      Message: {
        Subject: { Data: subject, Charset: "UTF-8" },
        Body: isHtml
          ? { Html: { Data: body, Charset: "UTF-8" } }
          : { Text: { Data: body, Charset: "UTF-8" } },
      },
    });
    const result = await client.send(cmd);
    res.json({ success: true, message: "Email sent", messageId: result.MessageId });
  } catch (e: any) {
    res.json({ success: false, message: e.message, messageId: null });
  }
});

export default router;
