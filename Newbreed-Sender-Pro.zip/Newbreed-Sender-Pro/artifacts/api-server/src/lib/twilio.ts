type TwilioResponse = Record<string, any>;

function authHeader(accountSid: string, authToken: string) {
  return "Basic " + Buffer.from(`${accountSid}:${authToken}`).toString("base64");
}

async function getTwilioResource(accountSid: string, authToken: string, path: string): Promise<TwilioResponse> {
  const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${accountSid}${path}`, {
    headers: { Authorization: authHeader(accountSid, authToken) },
  });
  const data = await response.json().catch(() => ({})) as TwilioResponse;
  if (!response.ok) {
    throw new Error(data.message || `Twilio returned HTTP ${response.status}`);
  }
  return data;
}

export async function findTwilioSendingNumber(accountSid: string, authToken: string): Promise<string | undefined> {
  const incoming = await getTwilioResource(accountSid, authToken, "/IncomingPhoneNumbers.json?PageSize=20");
  return incoming.incoming_phone_numbers
    ?.find((number: any) => number.phone_number && number.capabilities?.sms === true)
    ?.phone_number;
}

export async function verifyTwilioAccount(
  accountSid: string,
  authToken?: string | null,
  configuredFromNumber?: string | null,
) {
  if (!accountSid) {
    return { success: false, senderVerified: false, message: "Twilio Account SID is required" };
  }
  if (!authToken) {
    return {
      success: false,
      senderVerified: false,
      incomplete: true,
      message: "Twilio account saved. Add an Auth Token to verify the account and enable sending.",
    };
  }

  try {
    const account = await getTwilioResource(accountSid, authToken, ".json");
    let availableNumber: string | undefined;
    try {
      availableNumber = await findTwilioSendingNumber(accountSid, authToken);
    } catch {
      // Credential verification succeeded even if number discovery is unavailable.
    }

    const senderVerified = configuredFromNumber
      ? Boolean(availableNumber === configuredFromNumber)
      : Boolean(availableNumber);
    const selectedNumber = configuredFromNumber || availableNumber;
    const accountName = account.friendly_name ? ` for ${account.friendly_name}` : "";
    const numberMessage = selectedNumber
      ? ` Sending number: ${selectedNumber}.`
      : " No Twilio number with SMS capability was found; add one before sending.";

    return {
      success: true,
      senderVerified,
      fromNumber: selectedNumber,
      message: `Twilio account verified${accountName}.${numberMessage}`,
      details: account.status ? `Account status: ${account.status}` : undefined,
    };
  } catch (error: any) {
    return {
      success: false,
      senderVerified: false,
      message: "Twilio verification failed",
      details: error?.message || "Invalid Twilio credentials",
    };
  }
}

export async function resolveTwilioSenderNumber(
  accountSid: string,
  authToken?: string | null,
  configuredFromNumber?: string | null,
) {
  if (configuredFromNumber) return configuredFromNumber;
  if (!accountSid || !authToken) {
    throw new Error("Twilio Account SID and Auth Token are required when no sending number is configured");
  }
  const number = await findTwilioSendingNumber(accountSid, authToken);
  if (!number) {
    throw new Error("No Twilio SMS-capable number was found. Add or enable an SMS-capable Twilio number.");
  }
  return number;
}