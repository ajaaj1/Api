export const DATABASE_UNAVAILABLE_CODE = "DATABASE_UNAVAILABLE";

export const DATABASE_UNAVAILABLE_MESSAGE =
  "The database endpoint is disabled. In Replit, enable the database for this environment (Production for the published app, Development for preview), then retry. Successfully imported earlier batches remain saved.";

export function isDisabledDatabaseEndpoint(error: unknown): boolean {
  let current: unknown = error;
  const visited = new Set<unknown>();

  for (let depth = 0; depth < 6 && current && !visited.has(current); depth++) {
    visited.add(current);
    if (current instanceof Error) {
      if (/endpoint has been disabled/i.test(current.message)) return true;
      current = (current as Error & { cause?: unknown }).cause;
      continue;
    }
    if (typeof current === "object" && "message" in current) {
      const message = (current as { message?: unknown }).message;
      if (typeof message === "string" && /endpoint has been disabled/i.test(message)) return true;
      current = "cause" in current ? (current as { cause?: unknown }).cause : undefined;
      continue;
    }
    if (typeof current === "string") return /endpoint has been disabled/i.test(current);
    break;
  }

  return false;
}
