import cron from "node-cron";
import { db, campaignsTable } from "@workspace/db";
import { eq, and, lte, isNotNull } from "drizzle-orm";
import { logger } from "./lib/logger";

const runningCampaigns = new Set<number>();

export function setRunningCampaigns(set: Set<number>) {
  for (const id of set) runningCampaigns.add(id);
}

export function getRunningCampaigns(): Set<number> {
  return runningCampaigns;
}

let schedulerStarted = false;

export function startScheduler(triggerCampaign: (id: number) => Promise<void>) {
  if (schedulerStarted) return;
  schedulerStarted = true;

  cron.schedule("* * * * *", async () => {
    try {
      const now = new Date();
      const due = await db
        .select()
        .from(campaignsTable)
        .where(
          and(
            eq(campaignsTable.status, "scheduled"),
            isNotNull(campaignsTable.scheduledAt),
            lte(campaignsTable.scheduledAt, now)
          )
        );

      for (const campaign of due) {
        if (runningCampaigns.has(campaign.id)) continue;
        logger.info({ campaignId: campaign.id, name: campaign.name }, "Scheduler: triggering scheduled campaign");
        triggerCampaign(campaign.id).catch((e) => {
          logger.error({ err: e, campaignId: campaign.id }, "Scheduler: campaign failed");
        });
      }
    } catch (e) {
      logger.error({ err: e }, "Scheduler: error checking scheduled campaigns");
    }
  });

  logger.info("Campaign scheduler started (runs every minute)");
}
