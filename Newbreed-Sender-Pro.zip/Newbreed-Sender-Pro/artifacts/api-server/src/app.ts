import express, { type ErrorRequestHandler, type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import { DATABASE_UNAVAILABLE_CODE, DATABASE_UNAVAILABLE_MESSAGE, isDisabledDatabaseEndpoint } from "./lib/import-errors";
import { startScheduler } from "./scheduler";
import { triggerCampaign } from "./routes/campaigns";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return { id: req.id, method: req.method, url: req.url?.split("?")[0] };
      },
      res(res) {
        return { statusCode: res.statusCode };
      },
    },
  }),
);
app.use(cors());
// No body size limit — supports unlimited SMTP/lead file imports
app.use(express.json({ limit: "500mb" }));
app.use(express.urlencoded({ extended: true, limit: "500mb" }));

app.use("/api", router);

const apiErrorHandler: ErrorRequestHandler = (error, req, res, next) => {
  if (res.headersSent) {
    next(error);
    return;
  }

  const apiError = error as { status?: number; statusCode?: number; type?: string; name?: string };
  if (isDisabledDatabaseEndpoint(error)) {
    req.log.warn({ method: req.method, path: req.path }, "Database endpoint unavailable");
    res.status(503).json({ code: DATABASE_UNAVAILABLE_CODE, error: DATABASE_UNAVAILABLE_MESSAGE });
    return;
  }

  if (apiError.type === "entity.too.large") {
    res.status(413).json({ code: "UPLOAD_TOO_LARGE", error: "This upload is too large for one request. Retry with a smaller file." });
    return;
  }

  if (apiError.type === "entity.parse.failed") {
    res.status(400).json({ code: "INVALID_JSON", error: "The upload request could not be read. Please choose the file again and retry." });
    return;
  }

  const status = apiError.status ?? apiError.statusCode;
  if (status && status >= 400 && status < 500) {
    res.status(status).json({ code: "INVALID_REQUEST", error: "The server could not read this request. Please check the file and retry." });
    return;
  }

  req.log.error({ errorName: apiError.name ?? "Error", method: req.method, path: req.path }, "Unhandled API request error");
  res.status(500).json({ code: "SERVER_ERROR", error: "The server could not complete this request. Please retry." });
};

app.use(apiErrorHandler);

startScheduler(triggerCampaign);

export default app;
