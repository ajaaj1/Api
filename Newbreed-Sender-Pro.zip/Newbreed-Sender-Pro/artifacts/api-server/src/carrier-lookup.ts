// US area code → SMS gateway domain
// Based on predominant carrier assignment per area code.
// Due to number portability this is an approximation — accurate for ~70-80% of unported numbers.
// Falls back to the user-configured default gateway for unrecognized area codes.

const AREA_CODE_TO_GATEWAY: Record<string, string> = {
  // ── AT&T (txt.att.net) ─────────────────────────────────────────────────
  // Texas
  "214": "txt.att.net", "469": "txt.att.net", "972": "txt.att.net",
  "713": "txt.att.net", "832": "txt.att.net", "281": "txt.att.net",
  "210": "txt.att.net", "726": "txt.att.net",
  "817": "txt.att.net", "682": "txt.att.net",
  "512": "txt.att.net", "737": "txt.att.net",
  "915": "txt.att.net", "806": "txt.att.net", "325": "txt.att.net",
  "903": "txt.att.net", "936": "txt.att.net", "409": "txt.att.net",
  // Southeast
  "404": "txt.att.net", "678": "txt.att.net", "770": "txt.att.net",
  "615": "txt.att.net", "629": "txt.att.net",
  "901": "txt.att.net", "731": "txt.att.net",
  "502": "txt.att.net",
  "205": "txt.att.net", "256": "txt.att.net", "334": "txt.att.net",
  "601": "txt.att.net", "662": "txt.att.net", "769": "txt.att.net",
  "504": "txt.att.net", "985": "txt.att.net", "337": "txt.att.net",
  "870": "txt.att.net", "501": "txt.att.net",
  "803": "txt.att.net", "843": "txt.att.net", "864": "txt.att.net",
  "704": "txt.att.net", "980": "txt.att.net",
  // Midwest
  "312": "txt.att.net", "773": "txt.att.net", "872": "txt.att.net",
  "630": "txt.att.net", "331": "txt.att.net", "847": "txt.att.net",
  "317": "txt.att.net", "463": "txt.att.net",
  "816": "txt.att.net", "975": "txt.att.net",
  "402": "txt.att.net", "531": "txt.att.net",
  "405": "txt.att.net", "580": "txt.att.net", "918": "txt.att.net",
  "316": "txt.att.net", "785": "txt.att.net",
  "414": "txt.att.net", "262": "txt.att.net",
  // Mountain / Southwest
  "520": "txt.att.net", "928": "txt.att.net",
  "505": "txt.att.net", "575": "txt.att.net",

  // ── Verizon (vtext.com) ────────────────────────────────────────────────
  // New York / New Jersey
  "212": "vtext.com", "646": "vtext.com", "332": "vtext.com",
  "718": "vtext.com", "347": "vtext.com", "929": "vtext.com",
  "917": "vtext.com",
  "201": "vtext.com", "973": "vtext.com", "862": "vtext.com",
  "908": "vtext.com", "732": "vtext.com", "848": "vtext.com",
  "609": "vtext.com", "856": "vtext.com",
  "516": "vtext.com", "631": "vtext.com", "934": "vtext.com",
  "914": "vtext.com", "845": "vtext.com", "838": "vtext.com",
  // Pennsylvania
  "215": "vtext.com", "267": "vtext.com", "445": "vtext.com",
  "412": "vtext.com",
  "717": "vtext.com", "570": "vtext.com", "814": "vtext.com",
  // DC / Virginia / Maryland
  "202": "vtext.com",
  "703": "vtext.com", "571": "vtext.com",
  "804": "vtext.com", "757": "vtext.com", "434": "vtext.com",
  "301": "vtext.com", "240": "vtext.com", "410": "vtext.com",
  "443": "vtext.com", "667": "vtext.com",
  // New England
  "617": "vtext.com", "857": "vtext.com",
  "781": "vtext.com", "339": "vtext.com", "508": "vtext.com",
  "413": "vtext.com", "774": "vtext.com",
  "401": "vtext.com",
  "860": "vtext.com", "959": "vtext.com", "203": "vtext.com",
  "207": "vtext.com",
  "603": "vtext.com",
  "802": "vtext.com",
  // Mid-Atlantic / Southeast
  "302": "vtext.com",
  "910": "vtext.com", "919": "vtext.com", "984": "vtext.com",
  "561": "vtext.com", "772": "vtext.com",
  // Midwest
  "248": "vtext.com", "947": "vtext.com",
  "614": "vtext.com", "380": "vtext.com",
  "216": "vtext.com", "440": "vtext.com", "234": "vtext.com",
  "513": "vtext.com", "937": "vtext.com",
  "419": "vtext.com", "567": "vtext.com",
  "260": "vtext.com",
  // West Coast
  "310": "vtext.com", "424": "vtext.com",
  "323": "vtext.com",
  "949": "vtext.com", "714": "vtext.com", "657": "vtext.com",
  "951": "vtext.com",
  "909": "vtext.com",

  // ── T-Mobile (tmomail.net) ─────────────────────────────────────────────
  // Pacific Northwest
  "206": "tmomail.net", "253": "tmomail.net", "425": "tmomail.net",
  "360": "tmomail.net", "564": "tmomail.net",
  "509": "tmomail.net",
  "503": "tmomail.net", "971": "tmomail.net",
  "541": "tmomail.net", "458": "tmomail.net",
  // Bay Area / California
  "415": "tmomail.net", "628": "tmomail.net",
  "510": "tmomail.net", "341": "tmomail.net",
  "408": "tmomail.net", "669": "tmomail.net",
  "650": "tmomail.net",
  "707": "tmomail.net",
  "530": "tmomail.net",
  "916": "tmomail.net", "279": "tmomail.net",
  "559": "tmomail.net",
  "661": "tmomail.net",
  "805": "tmomail.net", "820": "tmomail.net",
  "619": "tmomail.net", "858": "tmomail.net",
  "760": "tmomail.net", "442": "tmomail.net",
  // Southwest
  "602": "tmomail.net", "480": "tmomail.net", "623": "tmomail.net",
  "303": "tmomail.net", "720": "tmomail.net",
  "719": "tmomail.net",
  "970": "tmomail.net",
  "385": "tmomail.net", "801": "tmomail.net",
  "307": "tmomail.net",
  "406": "tmomail.net",
  "208": "tmomail.net", "986": "tmomail.net",
  "702": "tmomail.net", "725": "tmomail.net",
  "775": "tmomail.net",
  "907": "tmomail.net",
  "808": "tmomail.net",
  // Midwest
  "612": "tmomail.net", "952": "tmomail.net",
  "651": "tmomail.net", "763": "tmomail.net",
  "314": "tmomail.net", "636": "tmomail.net",
  "573": "tmomail.net",
  "608": "tmomail.net",
  "701": "tmomail.net",
  "605": "tmomail.net",
  "515": "tmomail.net", "319": "tmomail.net", "712": "tmomail.net",

  // ── Sprint / T-Mobile legacy (messaging.sprintpcs.com) ─────────────────
  "913": "messaging.sprintpcs.com",   // Overland Park KS (Sprint HQ)
  "904": "messaging.sprintpcs.com",   // Jacksonville FL
  "407": "messaging.sprintpcs.com", "321": "messaging.sprintpcs.com",
  "813": "messaging.sprintpcs.com", "727": "messaging.sprintpcs.com",
  "954": "messaging.sprintpcs.com", "754": "messaging.sprintpcs.com",
  "305": "messaging.sprintpcs.com", "786": "messaging.sprintpcs.com",
  "352": "messaging.sprintpcs.com", "386": "messaging.sprintpcs.com",
  "850": "messaging.sprintpcs.com",
  "941": "messaging.sprintpcs.com",
  "239": "messaging.sprintpcs.com",
  "865": "messaging.sprintpcs.com",
  "423": "messaging.sprintpcs.com",
  "920": "messaging.sprintpcs.com",
  "715": "messaging.sprintpcs.com",
  "574": "messaging.sprintpcs.com", "219": "messaging.sprintpcs.com",
  "304": "messaging.sprintpcs.com", "681": "messaging.sprintpcs.com",
  "270": "messaging.sprintpcs.com", "364": "messaging.sprintpcs.com",
  "859": "messaging.sprintpcs.com",
  "740": "messaging.sprintpcs.com", "330": "messaging.sprintpcs.com",
  "724": "messaging.sprintpcs.com",
  "518": "messaging.sprintpcs.com", "315": "messaging.sprintpcs.com",
  "585": "messaging.sprintpcs.com", "716": "messaging.sprintpcs.com",
  "607": "messaging.sprintpcs.com",
};

const FALLBACK_GATEWAY = "txt.att.net";

/**
 * Detect the likely SMS carrier gateway for a US phone number based on area code.
 * Returns { gateway, carrier, confidence } where confidence is "area-code" or "fallback".
 */
export function detectCarrierGateway(phoneNumber: string, fallback?: string): {
  gateway: string;
  carrier: string;
  confidence: "area-code" | "fallback";
} {
  const digits = phoneNumber.replace(/\D/g, "");
  const local = digits.startsWith("1") && digits.length === 11 ? digits.slice(1) : digits;
  const areaCode = local.slice(0, 3);

  const gateway = AREA_CODE_TO_GATEWAY[areaCode] ?? fallback ?? FALLBACK_GATEWAY;
  const isKnown = areaCode in AREA_CODE_TO_GATEWAY;

  const GATEWAY_NAMES: Record<string, string> = {
    "txt.att.net": "AT&T",
    "vtext.com": "Verizon",
    "tmomail.net": "T-Mobile",
    "messaging.sprintpcs.com": "Sprint",
    "mms.cricketwireless.net": "Cricket",
    "sms.myboostmobile.com": "Boost",
    "mymetropcs.com": "Metro PCS",
    "email.uscc.net": "US Cellular",
    "msg.fi.google.com": "Google Fi",
    "text.republicwireless.com": "Republic Wireless",
  };

  return {
    gateway,
    carrier: GATEWAY_NAMES[gateway] ?? gateway,
    confidence: isKnown ? "area-code" : "fallback",
  };
}

/**
 * Format a phone number + gateway domain into a carrier email-to-SMS address.
 * e.g. "+1 (555) 867-5309" + "txt.att.net" → "5558675309@txt.att.net"
 */
export function toSmsGatewayEmail(phoneNumber: string, gatewayDomain: string): string {
  const digits = phoneNumber.replace(/\D/g, "");
  const local = digits.startsWith("1") && digits.length === 11 ? digits.slice(1) : digits;
  return `${local}@${gatewayDomain}`;
}
