---
name: Resend connector behavior
description: The attached Resend connection is send-only and cannot be used for domain metadata queries.
---

Treat the connected Resend credential as a send-only API path. Domain verification must be represented by the sender identity configured in the app and confirmed with a real send response; listing domains through the connection returns a restricted-api-key error.

**Why:** The workspace's attached Resend API key is intentionally restricted to sending emails.

**How to apply:** Use the Replit connector proxy/SDK for `/emails`, avoid relying on `/domains`, and distinguish provider acceptance from final inbox delivery.