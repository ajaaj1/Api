---
name: SMTP acceptance versus delivery
description: SMTP test results must distinguish relay acceptance from inbox delivery.
---

An SMTP `sendMail` success means the relay accepted the message, not that the recipient's inbox received it. Surface the relay response/message ID and tell users to check spam; classify rejected recipients as failures.

**Why:** Providers can accept a message and later filter, quarantine, bounce, or reject it downstream, so “passed” alone creates false confidence.

**How to apply:** Keep SMTP connection/auth failures, recipient rejection, relay acceptance, and final mailbox delivery as separate states in UI copy and logs.