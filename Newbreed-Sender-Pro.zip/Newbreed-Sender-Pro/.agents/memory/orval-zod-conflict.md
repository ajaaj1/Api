---
name: Orval zod codegen duplicate export conflict
description: When any OpenAPI request body type gets a generated name, it appears in both generated/api.ts (zod schema) and generated/types/ (TS interface), causing TS2308 on barrel re-export.
---

## The Rule
When adding new POST endpoints with named request bodies to the OpenAPI spec, the orval zod generator creates a naming conflict between `generated/api.ts` (zod const export) and `generated/types/` (TypeScript interface export). This causes TS2308 in `lib/api-zod/src/index.ts`.

## Fix Applied
Two changes were made together:

1. **`lib/api-spec/orval.config.ts`** — removed the `schemas` option from the zod output config:
   ```ts
   // REMOVED: schemas: { path: "generated/types", type: "typescript" },
   ```

2. **`lib/api-spec/package.json` codegen script** — added a post-orval patch that overwrites index.ts:
   ```json
   "codegen": "orval --config ./orval.config.ts && node -e \"require('fs').writeFileSync('../api-zod/src/index.ts', \\\"export * from './generated/api';\\\\n\\\")\" && pnpm -w run typecheck:libs"
   ```
   This is needed because orval regenerates `lib/api-zod/src/index.ts` on every run and restores the conflicting `export * from './generated/types'` line.

## Why
- Orval with `schemas: { path: "generated/types", type: "typescript" }` generates TS interfaces in a separate directory
- Those TS interfaces share the same name as zod const schemas in `generated/api.ts`
- TypeScript TS2308 fires when both are re-exported via `export *` from the same barrel
- The `types/` directory is redundant because consumers can use `z.infer<typeof schema>` for TypeScript types

## How to Apply
Any time a new named request body is added to the OpenAPI spec (inline schema in a requestBody), this conflict will naturally be prevented by the codegen script patch. No further action needed.
